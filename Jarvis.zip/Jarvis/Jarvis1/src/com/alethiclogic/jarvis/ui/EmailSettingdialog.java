package com.alethiclogic.jarvis.ui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class EmailSettingdialog extends JDialog implements ActionListener
{
private JPanel mainpanel=new JPanel();
private JPanel centerpanel=new JPanel(new GridLayout());
private JPanel centerpanelwest=new JPanel();
private JPanel centerpaneleast=new JPanel();
private JLabel smtphost=new JLabel("SMTP Host");
private JLabel smtpport=new JLabel("SMTP Port");
private JLabel smtpusername=new JLabel("SMTP User Name");
private JLabel smtppassword=new JLabel("SMTP Password");
private JLabel defaultfromaddress=new JLabel("Default From Address");
private JLabel defaulttoaddress=new JLabel("Default To Address");
private JLabel defaultsubject=new JLabel("Default Subject Line");
private JTextField text_smtphost=new JTextField();
private JTextField text_smtpport=new JTextField();
private JTextField text_smtpusername=new JTextField();
private JPasswordField text_smtppassword=new JPasswordField();
private JTextField text_defaultfromaddress=new JTextField();
private JTextField text_defaulttoaddress=new JTextField();
private JTextField text_defaultsubject=new JTextField();
private JButton insert=new JButton("Insert");
private String burl;

	public EmailSettingdialog()
	{
		burl=applicationpanel.getBase();
		init();
		
		
	}
	
	public void init()
	{
mainpanel.setPreferredSize(new Dimension(500,320));
centerpanel.setPreferredSize(new Dimension(500,320));
centerpanelwest.setPreferredSize(new Dimension(250, 160));
centerpaneleast.setPreferredSize(new Dimension(250, 160));

smtphost.setPreferredSize(new Dimension(200, 30));
smtpport.setPreferredSize(new Dimension(200, 30));
smtpusername.setPreferredSize(new Dimension(200, 30));
smtppassword.setPreferredSize(new Dimension(200, 30));
defaultfromaddress.setPreferredSize(new Dimension(200, 30));
defaulttoaddress.setPreferredSize(new Dimension(200, 30));
defaultsubject.setPreferredSize(new Dimension(200, 30));


text_smtphost.setPreferredSize(new Dimension(200, 30));
text_smtpport.setPreferredSize(new Dimension(200, 30));
text_smtpusername.setPreferredSize(new Dimension(200, 30));
text_smtppassword.setPreferredSize(new Dimension(200, 30));
text_defaultfromaddress.setPreferredSize(new Dimension(200, 30));
text_defaulttoaddress.setPreferredSize(new Dimension(200, 30));
text_defaultsubject.setPreferredSize(new Dimension(200, 30));
insert.setPreferredSize(new Dimension(200, 30));

insert.addActionListener(this);
//mainpanel.setBorder(BorderFactory.createRaisedBevelBorder());
//centerpanel.setBorder(BorderFactory.createRaisedBevelBorder());
//centerpanelwest.setBorder(BorderFactory.createRaisedBevelBorder());
//centerpaneleast.setBorder(BorderFactory.createRaisedBevelBorder());

centerpanelwest.add(smtphost);
centerpanelwest.add(smtpport);
centerpanelwest.add(smtpusername);
centerpanelwest.add(smtppassword);
centerpanelwest.add(defaultfromaddress);
centerpanelwest.add(defaulttoaddress);
centerpanelwest.add(defaultsubject);
centerpaneleast.add(text_smtphost);
centerpaneleast.add(text_smtpport);
centerpaneleast.add(text_smtpusername);
centerpaneleast.add(text_smtppassword);
centerpaneleast.add(text_defaultfromaddress);
centerpaneleast.add(text_defaulttoaddress);
centerpaneleast.add(text_defaultsubject);
centerpaneleast.add(insert);




centerpanel.add(centerpanelwest);
centerpanel.add(centerpaneleast);


		
		mainpanel.add(centerpanel);		
		this.add(mainpanel);
		this.setSize(500,320);
		this.setVisible(true);
		this.setTitle("Email Settings");
		this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
	}

	private void clear()
	{
	text_smtphost.setText("");
	text_smtpport.setText("");
	text_smtpusername.setText("");
	text_smtpusername.setText("");
	text_smtppassword.setText("");
	text_defaultfromaddress.setText("");
	text_defaulttoaddress.setText("");
	text_defaultsubject.setText("");
	
	}
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{

		if(e.getSource().equals(insert))
		{
			File file = new File("Jarvis.props");
			Properties properties = new Properties();

			String smtphost= text_smtphost.getText();
			String smtpport= text_smtpport.getText();
			String smtpusername= text_smtpusername.getText();
			String smtppassword= text_smtppassword.getText();
			String defaultfromaddress= text_defaultfromaddress.getText();
			String defaulttoaddress= text_defaulttoaddress.getText();
			String defaultsubject= text_defaultsubject.getText();
			
			try
			{
		
				properties.load(new FileInputStream(file));
				
				FileOutputStream fileOutputStream = new FileOutputStream(file);
				
				properties.put("smtphost",smtphost);
				properties.put("smtpport",smtpport );
				properties.put("smtpusername",smtpusername);
				properties.put("smtppassword",smtppassword);
				properties.put("defaultfromaddress",defaultfromaddress);
				properties.put("defaulttoaddress",defaulttoaddress);
				properties.put("defaultsubject",defaultsubject);
				properties.save(fileOutputStream, "Jarvis Properties");
				
				fileOutputStream.close();
			}
			catch (Exception exception)
			{
				JOptionPane.showMessageDialog(null, "<HTML><BODY>There has been an error saving the settings.<br>Please try again later.<br>or Contact administrator</BODY></HTML>");
				exception.printStackTrace();
			}
			clear();
		}

		
		}
	
}
