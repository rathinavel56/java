package com.alethiclogic.jarvis.ui;

public class subscriptionstoryarcentity 
{
	private String issue_code;
	private String storyarc_name;
	private String release_date;
	public String getIssue_code() {
		return issue_code;
	}
	public void setIssue_code(String issue_code) {
		this.issue_code = issue_code;
	}
	public String getStoryarc_name() {
		return storyarc_name;
	}
	public void setStoryarc_name(String storyarc_name) {
		this.storyarc_name = storyarc_name;
	}
	public String getRelease_date() {
		return release_date;
	}
	public void setRelease_date(String release_date) {
		this.release_date = release_date;
	}
	public Object[] getSubscriptionStoryArc()
	{
		Object[] temp=new Object[3];
		temp[0]=issue_code;
		temp[1]=storyarc_name;
		temp[2]=release_date;
		return temp;
	}

}
