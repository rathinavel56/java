package com.alethiclogic.jarvis.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import org.jfree.layout.CenterLayout;
public class applicationpanel extends JPanel  implements ActionListener
{
	
	private  JPanel westpanel; 
	private  JPanel centerpanel; 
	private JButton customerbutton;
	private JButton stockdetailsbutton;
	private JButton cataloguebutton;
	private JButton emailbutton;
	
	
	private static  String base;
	private static  String smtphost;
	private static  String smtpport;
	private static  String smtpusername;
	private static  String smtppassword;
	private static  String defaultformaddress;
	private static  String defaulttoaddress;
	private static  String defaultsubjectline;
	
	public applicationpanel()
	{
		properties();
		init();
	
	}
	public void init()
	{
	 setLayout(new BorderLayout());
	 westpanel=new JPanel()
	 {
		 protected void paintComponent(Graphics g)
		 {
			 Graphics2D graphics2d = (Graphics2D)g;
			 
			 GradientPaint paint = new GradientPaint(0, 0, Color.BLACK, 150, 1100, new Color(26, 10, 173));
			 graphics2d.setPaint(paint);
			 graphics2d.fillRect(0, 0, 160, 600);
		 };
	 };
	 centerpanel=new JPanel(new GridLayout());

	 customerbutton=new JButton("Customers");
	 stockdetailsbutton=new JButton("Stock");
	 cataloguebutton=new JButton("Catalogue");
	 emailbutton=new JButton("Email");
	 
	 
	 
	 westpanel.setPreferredSize(new Dimension(150,600));
	 customerbutton.setPreferredSize(new Dimension(125,50));
	 stockdetailsbutton.setPreferredSize(new Dimension(125,50));
	 cataloguebutton.setPreferredSize(new Dimension(125,50));
	 emailbutton.setPreferredSize(new Dimension(125,50));
	 
	 
	 westpanel.setBorder(BorderFactory.createLineBorder(new Color(236,233,216)));
	 //westpanel.setBorder(BorderFactory.createDashedBorder(new Color(255,255,255)));
	 //westpanel.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));
	 customerbutton.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
	 stockdetailsbutton.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
	 cataloguebutton.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
	 emailbutton.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
	 

	 
	 westpanel.add(customerbutton);
	 westpanel.add(stockdetailsbutton);
	 westpanel.add(cataloguebutton);
	 westpanel.add(emailbutton);
	 
	 
	 
	 customerbutton.addActionListener(this);
	 stockdetailsbutton.addActionListener(this);
	 cataloguebutton.addActionListener(this);
	 emailbutton.addActionListener(this);
	 centerpanel.add(new customerDetailsPanel());
	 add(westpanel,BorderLayout.WEST);
	 add(centerpanel,BorderLayout.CENTER);
	 
	 
	}
	
	@Override
	public void actionPerformed(ActionEvent e)
	{
	if(e.getSource().equals(customerbutton))
	{
	
		centerpanel.removeAll();
		centerpanel.add(new customerDetailsPanel());
		centerpanel.updateUI();
	}
	else if(e.getSource().equals(stockdetailsbutton))
	{
	
		centerpanel.removeAll();
		centerpanel.add(new stockpanel());
		centerpanel.updateUI();
	}
	else  if(e.getSource().equals(cataloguebutton))
	{
	
		centerpanel.removeAll();
	    centerpanel.add(new catalogue());
		centerpanel.updateUI();
	}
	else  if(e.getSource().equals(emailbutton))
	{
		new Emaildialog();
	}
	}
public void properties()
{
	File file = new File("Jarvis.props");
	if(!file.exists())
	{
		initProps(file);
	}
	else
	{
		Properties properties = new Properties();
		try
		{
			properties.load(new FileInputStream(file));
			base = properties.getProperty("base");
			smtphost = properties.getProperty("Smtphost");
			smtpport = properties.getProperty("Smtpport");
			smtpusername = properties.getProperty("Smtpusername");
			smtppassword = properties.getProperty("Smtppassword");
			defaultformaddress = properties.getProperty("Defaultformaddress");
			defaulttoaddress = properties.getProperty("Defaulttoaddress");
			defaultsubjectline = properties.getProperty("Defaultsubjectline");
					
			if (base == null || smtphost == null)
			{
				initProps(file);
			}
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
		}
	}
}

private void initProps(File file)
{
	JPanel basePanel = new JPanel(new GridLayout(8,2));
	
	basePanel.setPreferredSize(new Dimension(500,300));
	
	JTextField basefield = new JTextField();
	JTextField smtphField = new JTextField();
	JTextField smtportField = new JTextField();
	JTextField smtpusernameField = new JTextField();
	JPasswordField smtppasswordField = new JPasswordField();
	JTextField defaultfromaddressField = new JTextField();
	JTextField defaulttoaddressField = new JTextField();
	JTextField defaultsubjectlineField = new JTextField();
	
	basePanel.add(new JLabel("Base Url"));
	basePanel.add(basefield);
	
	basePanel.add(new JLabel("SMTP Host"));
	basePanel.add(smtphField);
	
	basePanel.add(new JLabel("SMTP Port"));
	basePanel.add(smtportField);
	
	basePanel.add(new JLabel("SMTP UserName"));
	basePanel.add(smtpusernameField);
	
	basePanel.add(new JLabel("SMTP Password"));
	basePanel.add(smtppasswordField);
	
	basePanel.add(new JLabel("Default From Address"));
	basePanel.add(defaultfromaddressField);
	
	basePanel.add(new JLabel("Default To Address"));
	basePanel.add(defaulttoaddressField);
	
	basePanel.add(new JLabel("Default Subject Line "));
	basePanel.add(defaultsubjectlineField);
	
	
	if (JOptionPane.showConfirmDialog(null, basePanel, "Base URL link:eg:www.Jarvis.com/", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION)
	{
		 base = basefield.getText();
		 smtphost =smtphField.getText();
		 smtpport =smtportField.getText();
		 smtpusername =smtpusernameField.getText();
		 smtppassword =smtppasswordField.getText();
		 defaultformaddress =defaultfromaddressField.getText();
		 defaulttoaddress =defaulttoaddressField.getText();
		 defaultsubjectline =defaultsubjectlineField.getText();
			 
	}

	if (base == null || base.replaceAll(" ", "").isEmpty() )
	{
		JOptionPane
				.showMessageDialog(null,
						"Unable to open application. Please contact administrator");
		System.exit(0);
	}

	Properties properties = new Properties();
	try
	{
		FileOutputStream fileOutputStream = new FileOutputStream(file);
		properties.put("base", base);
		properties.put("Smtphost", smtphost);
		properties.put("Smtpport", smtpport);
		properties.put("Smtpusername", smtpusername);
		properties.put("Smtppassword", smtppassword);
		properties.put("Defaultformaddress", defaultformaddress);
		properties.put("Defaulttoaddress", defaulttoaddress);
		properties.put("Defaultsubjectline", defaultsubjectline);
			
		properties.save(fileOutputStream, "Jarvis Properties");
		
		fileOutputStream.close();
	}
	catch (Exception exception)
	{
		JOptionPane.showMessageDialog(null, "Unable to open application. Please contact administrator");
		exception.printStackTrace();
	}
}

	/**
	 * @return the base
	 */
public static String getBase() 
{
		return base;
}
public static String getsmtphost() 
{
		return smtphost;
}
	
public static String getsmtpport() 
{
		return smtpport;
}
	
public static String getsmtpusername() 
{
		return smtpusername;
}
	
public static String getpassword() 
{
		return smtppassword;
}
	
public static String getdefaultfromaddress() 
{
		return defaultformaddress;
}
	
public static String getdefaulttoaddress()
{
		return defaulttoaddress;
}

public static String getdefaultsubjectline()
{
		return defaultsubjectline;
}
	
public static void main(String[] args) 
{
		try
		{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		JFrame frame = new JFrame("Jarvis Desktop Application");
		frame.add(new applicationpanel());
		frame.setMenuBar(new ApplicationMenuBar());
		frame.setSize(800,600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JFrame.setDefaultLookAndFeelDecorated(true);
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		//frame.setLocation((screenSize.width - 800) / 2, (screenSize.height - 475) / 2);
		
		frame.setVisible(true);
		//frame.setResizable(false);
		}
}


