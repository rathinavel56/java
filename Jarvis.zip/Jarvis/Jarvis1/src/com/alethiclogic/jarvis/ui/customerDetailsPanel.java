package com.alethiclogic.jarvis.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.TabExpander;
import javax.swing.text.DefaultEditorKit.CutAction;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

public class customerDetailsPanel extends JPanel implements ActionListener,MouseListener
{
	private JPanel mainPanel=new JPanel(new BorderLayout());
	private JTabbedPane  tabbedPane=new JTabbedPane();
	private Vector<customerEntity> customervector =new Vector<customerEntity>();
	
	//This initilaztion for all button with in the box layout panel
	
	private JLabel label_firstname = new JLabel("First Name");
	private JLabel label_lastname = new JLabel("Last Name");
	private JLabel label_doorno = new JLabel("Door no & Street ");
	private JLabel label_locality = new JLabel("Locality");
	private JLabel label_city = new JLabel("City");
	private JLabel label_state = new JLabel("State");
	private JLabel label_subscriptionfrom = new JLabel("From");
	private JLabel labelempty2 = new JLabel("");
	private JLabel labelempty3 = new JLabel("");
	private JLabel label_contactno = new JLabel("Contact no");
	private JLabel label_email = new JLabel("Email");
	private JLabel label_uname = new JLabel("User Name");
	private JLabel label_pname = new JLabel("Password");
	
	private JTextField field_customerno = new JTextField();
	private JTextField field_firstname = new JTextField();
	private JTextField field_lastname = new JTextField();
	private JTextField field_doorno = new JTextField();
	private JTextField field_street = new JTextField();
	private JTextField field_locality = new JTextField();
	private JTextField field_city = new JTextField();
	private JTextField field_state = new JTextField();
	private JTextField field_contactno = new JTextField();
	private JTextField field_uname = new JTextField();
	private JTextField field_pname = new JTextField();
	private JTextField field_email = new JTextField();
	private XDateChooser datesubs = new XDateChooser(new Date());
	private JButton butsave = new JButton("Save");
	private JButton Clear = new JButton("Clear");
	private Boolean custbool = true;
	
	private  JTextField custtextfield=new JTextField();
	private JTextField customerfield=new JTextField();
	private JTextField searchtext=new JTextField();
	

	private  JLabel custidlabel=new JLabel("CustomerId");
	private  JLabel fnamelabel=new JLabel("Firstname");
	private  JLabel lastlabel=new JLabel("Lastname");
	private  JLabel telephonelabel=new JLabel("Telephoneno");
	private  JLabel addresslabel=new JLabel("Address");
	private  JLabel emaillabel=new JLabel("Emailid");
	private  JLabel mobilenolabel=new JLabel("Mobileno");
	
	private  JButton save=new JButton("Save");
	private JButton search=new JButton("Search");
	private JButton subsearch=new JButton("Search");
	
	//tabbed pane for customersubscrptionsearch
	
	private Vector<subscriptiontitleentity> titleVector=new Vector<subscriptiontitleentity>();
	private Vector<subscriptionstoryarcentity> sarcVector=new Vector<subscriptionstoryarcentity>();
	
	
	private JTabbedPane  subtabbedPane=new JTabbedPane();

		
	 //declaration of the customer tabel
	private JTable viewsubcustTable;
	private Object[] columnNames = new Object[] {"CustomerId","Customer Name","Address","Telephone"};
	private Object[][] columnData = new Object[][] {};
	private DefaultTableModel model = new DefaultTableModel(columnData, columnNames);
	private JTable table1 = new JTable(model);	
	private JPanel tablepanel1 = new JPanel(new GridLayout());
	
	 //declaration of the customer tabel2
	 private JTable customersubscriptiontable;
	 private Object[] columnNames1 = new Object[] {"CustomerId","CustomerName","Address","Telephone"};
	 private Object[][] columnData1 = new Object[][] {};
	 private DefaultTableModel model1 = new DefaultTableModel(columnData1, columnNames1);
	 private JTable table2 = new JTable(model1);	
	 private JPanel tablepanel2 = new JPanel(new GridLayout());
	 	 
	 private Object[] columnNames3 = new Object[] {"Title","Subscription Date"};
	 private Object[][] columnData3 = new Object[][] {};
	 private DefaultTableModel customersubscriptionsearchmodel = new DefaultTableModel(columnData3, columnNames3);
	 private JTable customersubscriptionsearchtable = new JTable(customersubscriptionsearchmodel);
	 
	 private Object[] columnNames4 = new Object[] {"Issue Code","StoryArc Name","Release Date"};
	 private Object[][] columnData4 = new Object[][] {};
	 private DefaultTableModel customersubscriptionsearchmodel1 = new DefaultTableModel(columnData4, columnNames4);
	 private JTable customersubscriptionsearchtable1 = new JTable(customersubscriptionsearchmodel1);
	 
		//initialization
	
		

	public customerDetailsPanel() 
	{
		tabbedPane=new JTabbedPane();
		tabbedPane.add(customerdetailspanel(),"Customer Details");
		tabbedPane.add(customersubscriptionspanel(),"Customer Subscription");
		tabbedPane.setBackground(Color.DARK_GRAY);
		tabbedPane.setOpaque(true);
		
		mainPanel.add(tabbedPane);
		
		
		mainPanel.setSize(new Dimension(640,545));
		mainPanel.setPreferredSize(new Dimension(640,545));
		mainPanel.setBackground(Color.DARK_GRAY);
		mainPanel.setOpaque(true);
		
		add(mainPanel);
		
	}
	
	public JPanel customerdetailspanel()
	{
		 
		 JPanel northtabpanel=new JPanel(new BorderLayout());
		 JPanel  northwestpanel1=new JPanel();
		 JPanel  northwestpanel2=new JPanel();
		 
		 JPanel south=new JPanel();
		 JPanel southtextpanel=new JPanel(new BorderLayout());
		 JPanel center=new JPanel(new BorderLayout());
		 
		 northtabpanel.setBackground(Color.DARK_GRAY);
		 northtabpanel.setOpaque(true);
		 northwestpanel1.setBackground(Color.DARK_GRAY);
		 northwestpanel1.setOpaque(true);
		 south.setBackground(Color.DARK_GRAY);
		 south.setOpaque(true);
		 center.setBackground(Color.DARK_GRAY);
		 center.setOpaque(true);
		 
		 south.setPreferredSize(new Dimension(650,320));
		 southtextpanel.setPreferredSize(new Dimension(620,40));
		 center.setPreferredSize(new Dimension(620,270));
		 customerfield.setPreferredSize(new Dimension(500,20));
		 search.setPreferredSize(new Dimension(150,20));
		 
		 search.addActionListener(this);
		 

		 southtextpanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		 center.setBorder(BorderFactory.createRaisedBevelBorder());
		 
		 Font fd= new Font("Arial", Font.BOLD, 12);
		
		 fnamelabel.setFont(fd);
		 lastlabel.setFont(fd);
		 telephonelabel.setFont(fd);
		 addresslabel.setFont(fd);
		 emaillabel.setFont(fd);
		 mobilenolabel.setFont(fd);
		 save.setFont(fd);
		 
		 
			northwestpanel1.setLayout(new BoxLayout(northwestpanel1,
					BoxLayout.PAGE_AXIS));
			northwestpanel2.setLayout(new BoxLayout(northwestpanel2,
					BoxLayout.PAGE_AXIS));

			Component box_100 = Box.createRigidArea(new Dimension(5, 5));
			Box box_101 = Box.createHorizontalBox();
			Component box_1 = Box.createRigidArea(new Dimension(5, 5));
			Box box_2 = Box.createHorizontalBox();
			Box box_6 = Box.createHorizontalBox();
			Component box_7 = Box.createRigidArea(new Dimension(5, 5));
			Box box_8 = Box.createHorizontalBox();
			Component box_9 = Box.createRigidArea(new Dimension(5, 5));
			Box box_10 = Box.createHorizontalBox();
			Component box_11 = Box.createRigidArea(new Dimension(5, 5));
			Box box_12 = Box.createHorizontalBox();
			Component box_13 = Box.createRigidArea(new Dimension(5, 5));
			Box box_14 = Box.createHorizontalBox();
			Component box_15 = Box.createRigidArea(new Dimension(5, 5));
			Box box_16 = Box.createHorizontalBox();
			Component box_17 = Box.createRigidArea(new Dimension(5, 5));
			Box box_18 = Box.createHorizontalBox();
			Component box_19 = Box.createRigidArea(new Dimension(5, 5));
			Box box_20 = Box.createHorizontalBox();
			Component box_21 = Box.createRigidArea(new Dimension(5, 5));
			Box box_22 = Box.createHorizontalBox();
			Component box_23 = Box.createRigidArea(new Dimension(5, 5));
			Box box_24 = Box.createHorizontalBox();
			Component box_25 = Box.createRigidArea(new Dimension(5, 5));
			Box box_26 = Box.createHorizontalBox();
			Component box_27 = Box.createRigidArea(new Dimension(5, 5));
			Box box_28 = Box.createHorizontalBox();
			
			Component box_29 = Box.createRigidArea(new Dimension(5, 5));
			Box box_30 = Box.createHorizontalBox();

			Component box_31 = Box.createRigidArea(new Dimension(5, 5));
			Box box_32 = Box.createHorizontalBox();

			box_32.add(Box.createRigidArea(new Dimension(20, 0)));
			JPanel pbox32= new JPanel(new BorderLayout());
			custidlabel.setPreferredSize(new Dimension(100, 25));
			custidlabel.setMaximumSize(new Dimension(100, 25));
			custtextfield.setPreferredSize(new Dimension(150, 25));
			custtextfield.setMaximumSize(new Dimension(150, 25));
			pbox32.setMaximumSize(new Dimension(300, 25));
			pbox32.add(custidlabel, BorderLayout.WEST);
			pbox32.add(custtextfield, BorderLayout.CENTER);
			box_32.add(pbox32);
			box_32.add(Box.createRigidArea(new Dimension(0, 10)));
			
			pbox32.setBackground(Color.DARK_GRAY);
			pbox32.setOpaque(true);
			custidlabel.setForeground(Color.white);
			custtextfield.setEditable(false);
			
			box_2.add(Box.createRigidArea(new Dimension(20, 0)));
			JPanel pbox2 = new JPanel(new BorderLayout());
			label_firstname.setPreferredSize(new Dimension(100, 25));
			label_firstname.setMaximumSize(new Dimension(100, 25));
			field_firstname.setPreferredSize(new Dimension(150, 25));
			field_firstname.setMaximumSize(new Dimension(150, 25));
			pbox2.setMaximumSize(new Dimension(300, 25));
			pbox2.add(label_firstname, BorderLayout.WEST);
			pbox2.add(field_firstname, BorderLayout.CENTER);
			box_2.add(pbox2);
			box_2.add(Box.createRigidArea(new Dimension(0, 10)));
			
			pbox2.setBackground(Color.DARK_GRAY);
			pbox2.setOpaque(true);
			label_firstname.setForeground(Color.white);

			box_6.add(Box.createRigidArea(new Dimension(20, 0)));
			JPanel pbox6 = new JPanel(new BorderLayout());
			label_locality.setPreferredSize(new Dimension(100, 25));
			label_locality.setMaximumSize(new Dimension(100, 25));
			field_locality.setPreferredSize(new Dimension(150, 25));
			field_locality.setMaximumSize(new Dimension(150, 25));
			pbox6.setMaximumSize(new Dimension(300, 25));
			pbox6.add(label_locality, BorderLayout.WEST);
			pbox6.add(field_locality, BorderLayout.CENTER);
			box_6.add(pbox6);
			box_6.add(Box.createRigidArea(new Dimension(0, 10)));
			
			pbox6.setBackground(Color.DARK_GRAY);
			pbox6.setOpaque(true);
			label_locality.setForeground(Color.white);

			box_8.add(Box.createRigidArea(new Dimension(20, 0)));
			JPanel pbox8 = new JPanel(new BorderLayout());
			label_state.setPreferredSize(new Dimension(100, 25));
			label_state.setMaximumSize(new Dimension(100, 25));
			field_state.setPreferredSize(new Dimension(150, 25));
			field_state.setMaximumSize(new Dimension(150, 25));
			pbox8.setMaximumSize(new Dimension(300, 25));
			pbox8.add(label_state, BorderLayout.WEST);
			pbox8.add(field_state, BorderLayout.CENTER);
			box_8.add(pbox8);
			box_8.add(Box.createRigidArea(new Dimension(0, 10)));
			
			pbox8.setBackground(Color.DARK_GRAY);
			pbox8.setOpaque(true);
			label_state.setForeground(Color.white);
			

			box_10.add(Box.createRigidArea(new Dimension(20, 0)));
			JPanel pbox10 = new JPanel(new BorderLayout());
			label_email.setPreferredSize(new Dimension(100, 25));
			label_email.setMaximumSize(new Dimension(100, 25));
			field_email.setPreferredSize(new Dimension(150, 25));
			field_email.setMaximumSize(new Dimension(150, 25));
			pbox10.setMaximumSize(new Dimension(300, 25));
			pbox10.add(label_email, BorderLayout.WEST);
			pbox10.add(field_email, BorderLayout.CENTER);
			box_10.add(pbox10);
			box_10.add(Box.createRigidArea(new Dimension(0, 10)));
			
			pbox10.setBackground(Color.DARK_GRAY);
			pbox10.setOpaque(true);
			label_email.setForeground(Color.white);

			box_26.add(Box.createRigidArea(new Dimension(20, 0)));
			JPanel pbox26 = new JPanel(new BorderLayout());
			labelempty3.setPreferredSize(new Dimension(100, 25));
			labelempty3.setMaximumSize(new Dimension(100, 25));
			Clear.setPreferredSize(new Dimension(150, 25));
			Clear.setMaximumSize(new Dimension(150, 25));					
			pbox26.setMaximumSize(new Dimension(300, 25));
			pbox26.add(labelempty3, BorderLayout.WEST);
			pbox26.add(Clear, BorderLayout.CENTER);
			box_26.add(pbox26);
			box_26.add(Box.createRigidArea(new Dimension(0, 10)));
			
			pbox26.setBackground(Color.DARK_GRAY);
			pbox26.setOpaque(true);
			labelempty3.setForeground(Color.white);
			
			Clear.addActionListener(this);

			northwestpanel1.add(box_31);
			northwestpanel1.add(box_32);
			northwestpanel1.add(box_1);
			northwestpanel1.add(box_2);
			northwestpanel1.add(box_100);
			northwestpanel1.add(box_101);
			northwestpanel1.add(box_6);
			northwestpanel1.add(box_7);
			northwestpanel1.add(box_8);
			northwestpanel1.add(box_9);
			northwestpanel1.add(box_10);
			northwestpanel1.add(box_25);
			northwestpanel1.add(box_26);
			
			
			box_30.add(Box.createRigidArea(new Dimension(20, 0)));
			JPanel pbox30 = new JPanel(new BorderLayout());
			labelempty2.setPreferredSize(new Dimension(100, 25));
			labelempty2.setMaximumSize(new Dimension(100, 25));
			pbox30.setMaximumSize(new Dimension(300, 25));
			pbox30.add(labelempty2, BorderLayout.WEST);
			pbox30.add(labelempty2, BorderLayout.CENTER);
			box_30.add(pbox30);
			box_30.add(Box.createRigidArea(new Dimension(0, 10)));

			box_12.add(Box.createRigidArea(new Dimension(20, 0)));
			JPanel pbox12 = new JPanel(new BorderLayout());
			label_lastname.setPreferredSize(new Dimension(150, 25));
			label_lastname.setMaximumSize(new Dimension(150, 25));
			field_lastname.setPreferredSize(new Dimension(150, 25));
			field_lastname.setMaximumSize(new Dimension(150, 25));
			pbox12.setMaximumSize(new Dimension(300, 25));
			pbox12.add(label_lastname, BorderLayout.WEST);
			pbox12.add(field_lastname, BorderLayout.CENTER);
			box_12.add(pbox12);
			box_12.add(Box.createRigidArea(new Dimension(0, 10)));
			
			pbox12.setBackground(Color.DARK_GRAY);
			pbox12.setOpaque(true);
			label_lastname.setForeground(Color.white);

			box_14.add(Box.createRigidArea(new Dimension(20, 0)));
			JPanel pbox14 = new JPanel(new BorderLayout());
			label_doorno.setPreferredSize(new Dimension(150, 25));
			label_doorno.setMaximumSize(new Dimension(150, 25));
			field_doorno.setPreferredSize(new Dimension(150, 25));
			field_doorno.setMaximumSize(new Dimension(150, 25));
			pbox14.setMaximumSize(new Dimension(300, 25));
			pbox14.add(label_doorno, BorderLayout.WEST);
			pbox14.add(field_doorno, BorderLayout.CENTER);
			box_14.add(pbox14);
			box_14.add(Box.createRigidArea(new Dimension(0, 10)));
			
			pbox14.setBackground(Color.DARK_GRAY);
			pbox14.setOpaque(true);
			label_doorno.setForeground(Color.white);

			box_16.add(Box.createRigidArea(new Dimension(20, 0)));
			JPanel pbox16 = new JPanel(new BorderLayout());
			label_city.setPreferredSize(new Dimension(150, 25));
			label_city.setMaximumSize(new Dimension(150, 25));
			field_city.setPreferredSize(new Dimension(150, 25));
			field_city.setMaximumSize(new Dimension(150, 25));
			pbox16.setMaximumSize(new Dimension(300, 25));
			pbox16.add(label_city, BorderLayout.WEST);
			pbox16.add(field_city, BorderLayout.CENTER);
			box_16.add(pbox16);
			box_16.add(Box.createRigidArea(new Dimension(0, 10)));
			
			pbox16.setBackground(Color.DARK_GRAY);
			pbox16.setOpaque(true);
			label_city.setForeground(Color.white);

			box_18.add(Box.createRigidArea(new Dimension(20, 0)));
			JPanel pbox18 = new JPanel(new BorderLayout());
			label_subscriptionfrom.setPreferredSize(new Dimension(150, 25));
			label_subscriptionfrom.setMaximumSize(new Dimension(150, 25));
			datesubs.setPreferredSize(new Dimension(150, 25));
			datesubs.setMaximumSize(new Dimension(150, 25));
			pbox18.setMaximumSize(new Dimension(300, 25));
			pbox18.add(label_subscriptionfrom, BorderLayout.WEST);
			pbox18.add(datesubs, BorderLayout.CENTER);
			box_18.add(pbox18);
			box_18.add(Box.createRigidArea(new Dimension(0, 10)));
			
			pbox18.setBackground(Color.DARK_GRAY);
			pbox18.setOpaque(true);
			label_subscriptionfrom.setForeground(Color.white);
			

			box_20.add(Box.createRigidArea(new Dimension(20, 0)));
			JPanel pbox20 = new JPanel(new BorderLayout());
			label_contactno.setPreferredSize(new Dimension(150, 25));
			label_contactno.setMaximumSize(new Dimension(150, 25));
			field_contactno.setPreferredSize(new Dimension(150, 25));
			field_contactno.setMaximumSize(new Dimension(150, 25));
			pbox20.setMaximumSize(new Dimension(300, 25));
			pbox20.add(label_contactno, BorderLayout.WEST);
			pbox20.add(field_contactno, BorderLayout.CENTER);
			box_20.add(pbox20);
			box_18.add(Box.createRigidArea(new Dimension(0, 10)));
			
			pbox20.setBackground(Color.DARK_GRAY);
			pbox20.setOpaque(true);
			label_contactno.setForeground(Color.white);

			
			box_22.add(Box.createRigidArea(new Dimension(20, 0)));
			JPanel pbox22 = new JPanel(new BorderLayout());
			label_uname.setPreferredSize(new Dimension(100, 25));
			label_uname.setMaximumSize(new Dimension(100, 25));
			field_uname.setPreferredSize(new Dimension(150, 25));
			field_uname.setMaximumSize(new Dimension(150, 25));
			pbox22.setMaximumSize(new Dimension(300, 25));
			pbox22.add(label_uname, BorderLayout.WEST);
			pbox22.add(field_uname, BorderLayout.CENTER);
			box_22.add(pbox22);
			box_22.add(Box.createRigidArea(new Dimension(0, 10)));
			
			pbox22.setBackground(Color.DARK_GRAY);
			pbox22.setOpaque(true);
			label_uname.setForeground(Color.white);
			

			box_24.add(Box.createRigidArea(new Dimension(20, 0)));
			JPanel pbox24 = new JPanel(new BorderLayout());
			label_pname.setPreferredSize(new Dimension(100, 25));
			label_pname.setMaximumSize(new Dimension(100, 25));
			field_pname.setPreferredSize(new Dimension(150, 25));
			field_pname.setMaximumSize(new Dimension(150, 25));
			pbox24.setMaximumSize(new Dimension(300, 25));
			pbox24.add(label_pname, BorderLayout.WEST);
			pbox24.add(field_pname, BorderLayout.CENTER);
			box_24.add(pbox24);
			box_24.add(Box.createRigidArea(new Dimension(0, 10)));
			
			pbox24.setBackground(Color.DARK_GRAY);
			pbox24.setOpaque(true);
			label_pname.setForeground(Color.white);

			
			box_28.add(Box.createRigidArea(new Dimension(20, 0)));
			JPanel pbox28 = new JPanel(new BorderLayout());
			butsave.addActionListener(this);
			labelempty2.setPreferredSize(new Dimension(150, 25));
			labelempty2.setMaximumSize(new Dimension(150, 25));
			butsave.setPreferredSize(new Dimension(150, 25));
			butsave.setMaximumSize(new Dimension(150, 25));
			pbox28.setMaximumSize(new Dimension(300, 25));
			pbox28.add(labelempty2, BorderLayout.WEST);
			pbox28.add(butsave, BorderLayout.CENTER);
			box_28.add(pbox28);
			box_28.add(Box.createRigidArea(new Dimension(0, 10)));
			
			pbox28.setBackground(Color.DARK_GRAY);
			pbox28.setOpaque(true);
			
			pbox30.setBackground(Color.DARK_GRAY);
			pbox30.setOpaque(true);
			
			northwestpanel2.add(box_19);
			northwestpanel2.add(box_20);
			northwestpanel2.add(box_11);
			northwestpanel2.add(box_12);
			northwestpanel2.add(box_13);
			northwestpanel2.add(box_14);
			northwestpanel2.add(box_15);
			northwestpanel2.add(box_16);
			northwestpanel2.add(box_17);
			northwestpanel2.add(box_18);
			northwestpanel2.add(box_27);
			northwestpanel2.add(box_28);
			
			
			
			table1.addMouseListener(this);
			tablepanel1.add(new JScrollPane(table1));
			center.add(tablepanel1, BorderLayout.CENTER);
			southtextpanel.add(customerfield,BorderLayout.WEST);
			southtextpanel.add(search,BorderLayout.CENTER);
			south.add(southtextpanel,BorderLayout.NORTH);
			south.add(center,BorderLayout.CENTER);
			
			customerloaddata();
			tablepanel1.updateUI();
			
			northtabpanel.add(northwestpanel1,BorderLayout.WEST);
			northtabpanel.add(northwestpanel2,BorderLayout.CENTER);
			northtabpanel.add(south,BorderLayout.SOUTH);
			northwestpanel1.setBackground(Color.DARK_GRAY);
			northwestpanel2.setBackground(Color.DARK_GRAY);
			southtextpanel.setBackground(Color.DARK_GRAY);
			northtabpanel.setBackground(Color.DARK_GRAY);
			northtabpanel.setOpaque(true);
			
			return northtabpanel;
		
	}
	
	
	private JPanel customersubscriptionspanel()
	{
		
			JPanel  mainpanel=new JPanel();
			JPanel  northpanel=new JPanel(new BorderLayout());
			JPanel centerpanel=new JPanel(new BorderLayout());
			
			//searhtab
			subtabbedPane=new JTabbedPane();
			JPanel south=new JPanel(new GridLayout());
			subtabbedPane.add(subsearchtab1(),"Title");
			subtabbedPane.add(subsearchtab2(),"StoryArc");
			
			JLabel empty=new JLabel();
			
			centerpanel.setBackground(Color.DARK_GRAY);
			centerpanel.setOpaque(true);
			northpanel.setBackground(Color.DARK_GRAY);
			northpanel.setOpaque(true);
			south.setBackground(Color.DARK_GRAY);
			south.setOpaque(true);
			subtabbedPane.setBackground(Color.DARK_GRAY);
			subtabbedPane.setOpaque(true);
			
			centerpanel.setPreferredSize(new Dimension(640,200));
			northpanel.setPreferredSize(new Dimension(630,40));
			south.setPreferredSize(new Dimension(630,350));
			
			
			searchtext.setPreferredSize(new Dimension(500,40));
			subsearch.setPreferredSize(new Dimension(120,40));
			
			centerpanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
			northpanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
			
			subsearch.addActionListener(this);
			south.add(subtabbedPane,BorderLayout.NORTH);
			
			
			table2.addMouseListener(this);
			tablepanel2.add(new JScrollPane(table2));
			centerpanel.add(tablepanel2, BorderLayout.CENTER);
			northpanel.setOpaque(true);
			northpanel.setBackground(Color.DARK_GRAY);
			
			centerpanel.setBackground(Color.DARK_GRAY);
			centerpanel.setOpaque(true);
			
			tablepanel2.setBackground(Color.DARK_GRAY);
			tablepanel2.setOpaque(true);
			
			
			customersuscriptionloaddate();
			tablepanel2.updateUI();
			 
			northpanel.add(searchtext,BorderLayout.WEST);
			northpanel.add(subsearch,BorderLayout.CENTER);
			northpanel.add(empty,BorderLayout.EAST); 
			mainpanel.add(northpanel,BorderLayout.NORTH);
			mainpanel.add(centerpanel,BorderLayout.CENTER);
			mainpanel.add(south,BorderLayout.SOUTH);
			mainpanel.setBackground(Color.DARK_GRAY);
			mainpanel.setOpaque(true);
			
			add(mainpanel);
			return mainpanel;
			
	}
	
	private JPanel subsearchtab1()
	
		{
			JPanel customertab1=new JPanel(new BorderLayout());
			//declaration of the customersearch tab1
			
			
			customertab1.setPreferredSize(new Dimension(620,100));
			
			JPanel tablepanel3 = new JPanel(new GridLayout());
			tablepanel3.add(new JScrollPane(customersubscriptionsearchtable));
			  
			customertab1.add(tablepanel3, BorderLayout.CENTER);
				
			return customertab1;
			
		}
	
	private JPanel subsearchtab2()
	
		{
			
			//declaration of the customersearch tab1
			
			JPanel customertab2=new JPanel(new BorderLayout());
			customertab2.setPreferredSize(new Dimension(630,100));  	
			JPanel tablepanel4 = new JPanel(new GridLayout());
			tablepanel4.add(new JScrollPane(customersubscriptionsearchtable1));  
			customertab2.add(tablepanel4, BorderLayout.CENTER);
			
			return customertab2;
		
		}
	

	private void customerloaddata() 
		{
			customervector.clear();
			try 
			{
			HttpClient client = new DefaultHttpClient();
			HttpGet request = new HttpGet(applicationpanel.getBase() + "query/javacust.php");
			HttpResponse response = client.execute(request);
			BufferedReader rd = new BufferedReader(new InputStreamReader(
			response.getEntity().getContent()));
			
			//dccombo_cname.removeAllElements();
			
			StringBuffer buffer = new StringBuffer();

			String line = "";
			String ss = "";
			while ((line = rd.readLine()) != null) 
			{
				buffer.append(line);
				ss = ss + line;
			}
			
				if (!ss.isEmpty()) 
				{

					String[] namevaluePairs = buffer.toString().split("\\-\\-");
			
					for (String namevaluePair : namevaluePairs) 
					{
						if (namevaluePair.contains("|")) 
					  {
						    String[] pairArray = namevaluePair.split("\\|");
					
						    customerEntity ce = new customerEntity();
					
						
						if (pairArray[0] != null && !pairArray[0].isEmpty())
						{
							ce.setCustid(pairArray[0]);
						}
						else
						{
							ce.setCustid(" ");
						}
					
						if (pairArray[2] != null && !pairArray[2].isEmpty())
						{
							ce.setFirstName(pairArray[2]);
						}
						else
						{
							ce.setFirstName(" ");
						}
						if (pairArray[3] != null && !pairArray[3].isEmpty())
						{
							ce.setLastName(pairArray[3]);
						}
						else
						{
							ce.setLastName(" ");
						}
						if (pairArray[4] != null && !pairArray[4].isEmpty())
						{
							ce.setDoorNo(pairArray[4]);
						}
						else
						{
							ce.setDoorNo(" ");
						}
						if (pairArray[5] != null && !pairArray[5].isEmpty())
						{
							ce.setStreet(pairArray[5]);
						}
						else
						{
							ce.setStreet(" ");
						}
						if (pairArray[6] != null && !pairArray[6].isEmpty())
						{
							ce.setLocality(pairArray[6]);
						}
						else
						{
							ce.setLocality(" ");
						}
						if (pairArray[7] != null && !pairArray[7].isEmpty())
						{
							ce.setCity(pairArray[7]);
						}
						else
						{
							ce.setCity(" ");
						}

						if (pairArray[8] != null && !pairArray[8].isEmpty())
						{
							ce.setState(pairArray[8]);
						}
						else
						{
							ce.setState(" ");
						}
						
						if (pairArray[9] != null && !pairArray[9].isEmpty())
						{
							ce.setContactNo(pairArray[9]);
						}
						else
						{
							ce.setContactNo(" ");
						}
						if (pairArray[10] != null && !pairArray[10].isEmpty())
						{
							ce.setEmail(pairArray[10]);
						}
						else
						{
							ce.setEmail(" ");
						}
						if (pairArray[12] != null && !pairArray[12].isEmpty())
						{
							ce.setFromDate(pairArray[12]);
						}
						else
						{
							ce.setFromDate(" ");
						}
						
						customervector.add(ce);
				
					}
				}
			}
			
		} 			catch (IOException e3) 
					{
						e3.printStackTrace();
					}

					int address = customervector.size();
				 	Object[][] columnData = new Object[address][4];
				    for (int i = 0; i < address; i++)
				    {
				    columnData[i] = customervector.get(i).getcustomerdetails();
				    }
				    if (model == null) 
				    {
				    	model = new DefaultTableModel(columnData, columnNames) 
				    	{
							@Override
							public boolean isCellEditable(int row, int col1) 
							{
											if (col1 < 3)
												return false;
											return true;
							}

							@Override
							public Class getColumnClass(int c) 
							{
									try 
									{
										return getValueAt(0, c).getClass();
									} 
									catch (Exception exception) 
									{
												return String.class;
									}
							}
				    	};
			} 
				    else 
				    {
				    	model.setDataVector(columnData, columnNames);
				    }
				    if (viewsubcustTable == null)
				    	viewsubcustTable = new JTable(model);
				    	viewsubcustTable.updateUI();
		}
	
	
	private void customersuscriptionloaddate() 
	{
			customervector.clear();
			try 
			{
			HttpClient client = new DefaultHttpClient();
			HttpGet request = new HttpGet(applicationpanel.getBase() + "query/javasubcust.php");
			HttpResponse response = client.execute(request);
			BufferedReader rd = new BufferedReader(new InputStreamReader(
			response.getEntity().getContent()));
			
			//dccombo_cname.removeAllElements();
			
			StringBuffer buffer = new StringBuffer();

			String line = "";
			String ss = "";
			while ((line = rd.readLine()) != null) 
			{
				buffer.append(line);
				ss = ss + line;
			}

				if (!ss.isEmpty()) 
				{

					String[] namevaluePairs = buffer.toString().split("\\-\\-");
			
					for (String namevaluePair : namevaluePairs) 
					{
						if (namevaluePair.contains("|")) 
					  {
						    String[] pairArray = namevaluePair.split("\\|");
					
						    customerEntity ce = new customerEntity();
					
						
						if (pairArray[0] != null && !pairArray[0].isEmpty())
						{
							ce.setCustid(pairArray[0]);
						}
						else
						{
							ce.setCustid(" ");
						}
					
						if (pairArray[2] != null && !pairArray[2].isEmpty())
						{
							ce.setFirstName(pairArray[2]);
						}
						else
						{
							ce.setFirstName(" ");
						}
						if (pairArray[3] != null && !pairArray[3].isEmpty())
						{
							ce.setLastName(pairArray[3]);
						}
						else
						{
							ce.setLastName(" ");
						}
						if (pairArray[4] != null && !pairArray[4].isEmpty())
						{
							ce.setDoorNo(pairArray[4]);
						}
						else
						{
							ce.setDoorNo(" ");
						}
						if (pairArray[5] != null && !pairArray[5].isEmpty())
						{
							ce.setStreet(pairArray[5]);
						}
						else
						{
							ce.setStreet(" ");
						}
						if (pairArray[6] != null && !pairArray[6].isEmpty())
						{
							ce.setLocality(pairArray[6]);
						}
						else
						{
							ce.setLocality(" ");
						}
						if (pairArray[7] != null && !pairArray[7].isEmpty())
						{
							ce.setCity(pairArray[7]);
						}
						else
						{
							ce.setCity(" ");
						}

						if (pairArray[8] != null && !pairArray[8].isEmpty())
						{
							ce.setState(pairArray[8]);
						}
						else
						{
							ce.setState(" ");
						}
						
						if (pairArray[9] != null && !pairArray[9].isEmpty())
						{
							ce.setContactNo(pairArray[9]);
						}
						else
						{
							ce.setContactNo(" ");
						}
						if (pairArray[10] != null && !pairArray[10].isEmpty())
						{
							ce.setEmail(pairArray[10]);
						}
						else
						{
							ce.setEmail(" ");
						}
						if (pairArray[12] != null && !pairArray[12].isEmpty())
						{
							ce.setFromDate(pairArray[12]);
						}
						else
						{
							ce.setFromDate(" ");
						}
						
						customervector.add(ce);
				
					}
				}
			}
			
		} 			catch (IOException e3) 
					{
						e3.printStackTrace();
					}

					int address = customervector.size();
				 	Object[][] columnData1 = new Object[address][3];
				    for (int i = 0; i < address; i++) 
				    {
				    columnData1[i] = customervector.get(i).getcustomersubscription();
				    }
				    if (model1 == null) 
				    {
				    	model1 = new DefaultTableModel(columnData1, columnNames1) 
				    	{
							@Override
							public boolean isCellEditable(int row, int col1) 
							{
											if (col1 < 2)
												return false;
											return true;
							}

							@Override
							public Class getColumnClass(int c) 
							{
									try 
									{
										return getValueAt(0, c).getClass();
									} 
									catch (Exception exception) 
									{
												return String.class;
									}
							}
				    	};
			} 
				    else 
				    {
				    	model1.setDataVector(columnData1, columnNames1);
				    }
				    if (customersubscriptiontable == null)
				    	customersubscriptiontable = new JTable(model1);
				    customersubscriptiontable.updateUI();
	}

	
	private void customersearchloaddata()
	{
	customervector.clear();
	try {

				HttpClient client = new DefaultHttpClient();
				HttpPost post = new HttpPost(
				applicationpanel.getBase() + "query/javasearchcust.php");
				List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
			
				nameValuePairs.add(new BasicNameValuePair("search",customerfield.getText()));
				
				post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse response = client.execute(post);
				BufferedReader rd = new BufferedReader(new InputStreamReader(
				response.getEntity().getContent()));

				String[] array;
				String line = "";
				String ss = "";
				int j = 0;
		
				StringBuffer buffer = new StringBuffer();

				while ((line = rd.readLine()) != null) 
				{
					buffer.append(line);
					ss = ss + line;

				}
				System.out.println(ss +"lp");
		
				if (!ss.isEmpty()) 
				{
			
					String[] namevaluePairs = buffer.toString().split("\\-\\-");
					for (String namevaluePair : namevaluePairs) 
					{
					if (namevaluePair.contains("|")) 
					{
						
					String[] pairArray = namevaluePair.split("\\|");
					customerEntity ce = new customerEntity();
					
					if (pairArray[0] != null && !pairArray[0].isEmpty())
					{
						ce.setCustid(pairArray[0]);
					}
					else
					{
						ce.setCustid(" ");
					}
				
					if (pairArray[2] != null && !pairArray[2].isEmpty())
					{
						ce.setFirstName(pairArray[2]);
					}
					else
					{
						ce.setFirstName(" ");
					}
					if (pairArray[3] != null && !pairArray[3].isEmpty())
					{
						ce.setLastName(pairArray[3]);
					}
					else
					{
						ce.setLastName(" ");
					}
					if (pairArray[4] != null && !pairArray[4].isEmpty())
					{
						ce.setDoorNo(pairArray[4]);
					}
					else
					{
						ce.setDoorNo(" ");
					}
					if (pairArray[5] != null && !pairArray[5].isEmpty())
					{
						ce.setStreet(pairArray[5]);
					}
					else
					{
						ce.setStreet(" ");
					}
					if (pairArray[6] != null && !pairArray[6].isEmpty())
					{
						ce.setLocality(pairArray[6]);
					}
					else
					{
						ce.setLocality(" ");
					}
					if (pairArray[7] != null && !pairArray[7].isEmpty())
					{
						ce.setCity(pairArray[7]);
					}
					else
					{
						ce.setCity(" ");
					}

					if (pairArray[8] != null && !pairArray[8].isEmpty())
					{
						ce.setState(pairArray[8]);
					}
					else
					{
						ce.setState(" ");
					}
					
					if (pairArray[9] != null && !pairArray[9].isEmpty())
					{
						ce.setContactNo(pairArray[9]);
					}
					else
					{
						ce.setContactNo(" ");
					}
					if (pairArray[10] != null && !pairArray[10].isEmpty())
					{
						ce.setEmail(pairArray[10]);
					}
					else
					{
						ce.setEmail(" ");
					}
					if (pairArray[12] != null && !pairArray[12].isEmpty())
					{
						ce.setFromDate(pairArray[12]);
					}
					else
					{
						ce.setFromDate(" ");
					}
					
					customervector.add(ce);
					}
					}
				 }

			} 
				catch (IOException e3) 
				{
					e3.printStackTrace();
				}
				int address = customervector.size();
				Object[][] columnData = new Object[address][4];
				for (int i = 0; i < address; i++) 
				{
					columnData[i] = customervector.get(i).getcustomerdetails();
				}

				if (model == null) 
				{
				model = new DefaultTableModel(columnData, columnNames) 
				{
				@Override
				public boolean isCellEditable(int row, int col1) 
				{
				if (col1 < 3)
					return false;
				return true;
				}

				@Override
				public Class getColumnClass(int c)
				{
				try 
				{
					return getValueAt(0, c).getClass();
				} 
				catch (Exception exception) 
				{
					return String.class;
				}
				}
				};
	}
	
				
	else 
	{
		model.setDataVector(columnData, columnNames);
	}
	if (viewsubcustTable == null)
		viewsubcustTable = new JTable(model);
		viewsubcustTable.updateUI();
}

	
	private void customersubsearchloaddata()
	{
		customervector.clear();
		try {

				HttpClient client = new DefaultHttpClient();
				HttpPost post = new HttpPost(
				applicationpanel.getBase() + "query/javasubsearchcust.php");
				List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
			
				nameValuePairs.add(new BasicNameValuePair("subsearch",searchtext.getText()));
				
				post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse response = client.execute(post);
				BufferedReader rd = new BufferedReader(new InputStreamReader(
				response.getEntity().getContent()));

				String[] array;
				String line = "";
				String ss = "";
				int j = 0;
		
				StringBuffer buffer = new StringBuffer();

				while ((line = rd.readLine()) != null) 
				{
					buffer.append(line);
					ss = ss + line;

				}
		
				if (!ss.isEmpty()) 
				{
			
					String[] namevaluePairs = buffer.toString().split("\\-\\-");
					for (String namevaluePair : namevaluePairs) 
					{
					if (namevaluePair.contains("|")) 
					{
						
					String[] pairArray = namevaluePair.split("\\|");
					customerEntity ce = new customerEntity();
					
					if (pairArray[0] != null && !pairArray[0].isEmpty())
					{
						ce.setCustid(pairArray[0]);
					}
					else
					{
						ce.setCustid(" ");
					}
				
					if (pairArray[2] != null && !pairArray[2].isEmpty())
					{
						ce.setFirstName(pairArray[2]);
					}
					else
					{
						ce.setFirstName(" ");
					}
					if (pairArray[3] != null && !pairArray[3].isEmpty())
					{
						ce.setLastName(pairArray[3]);
					}
					else
					{
						ce.setLastName(" ");
					}
					if (pairArray[4] != null && !pairArray[4].isEmpty())
					{
						ce.setDoorNo(pairArray[4]);
					}
					else
					{
						ce.setDoorNo(" ");
					}
					if (pairArray[5] != null && !pairArray[5].isEmpty())
					{
						ce.setStreet(pairArray[5]);
					}
					else
					{
						ce.setStreet(" ");
					}
					if (pairArray[6] != null && !pairArray[6].isEmpty())
					{
						ce.setLocality(pairArray[6]);
					}
					else
					{
						ce.setLocality(" ");
					}
					if (pairArray[7] != null && !pairArray[7].isEmpty())
					{
						ce.setCity(pairArray[7]);
					}
					else
					{
						ce.setCity(" ");
					}

					if (pairArray[8] != null && !pairArray[8].isEmpty())
					{
						ce.setState(pairArray[8]);
					}
					else
					{
						ce.setState(" ");
					}
					
					if (pairArray[9] != null && !pairArray[9].isEmpty())
					{
						ce.setContactNo(pairArray[9]);
					}
					else
					{
						ce.setContactNo(" ");
					}
					if (pairArray[10] != null && !pairArray[10].isEmpty())
					{
						ce.setEmail(pairArray[10]);
					}
					else
					{
						ce.setEmail(" ");
					}
					if (pairArray[12] != null && !pairArray[12].isEmpty())
					{
						ce.setFromDate(pairArray[12]);
					}
					else
					{
						ce.setFromDate(" ");
					}
					
					customervector.add(ce);
					}
					}
				 }

			} 
				catch (IOException e3) 
				{
					e3.printStackTrace();
				}
				int address = customervector.size();
				Object[][] columnData1 = new Object[address][4];
				for (int i = 0; i < address; i++) 
				{
					columnData1[i] = customervector.get(i).getsubcustomersubscription();
				}

				if (model1 == null) 
				{
				model1 = new DefaultTableModel(columnData1, columnNames1) 
				{
				@Override
				public boolean isCellEditable(int row, int col1) 
				{
				if (col1 < 3)
					return false;
				return true;
				}

				@Override
				public Class getColumnClass(int c)
				{
				try 
				{
					return getValueAt(0, c).getClass();
				} 
				catch (Exception exception) 
				{
					return String.class;
				}
				}
				};
	}
	
				
		else 
		{
			model1.setDataVector(columnData1, columnNames1);
		}
		if (customersubscriptiontable == null)
			customersubscriptiontable = new JTable(model1);
			customersubscriptiontable.updateUI();
	}
	
	

	@Override
	public void actionPerformed(ActionEvent e)
	{
	
		if(e.getSource().equals(butsave))
		{
				SimpleDateFormat sdf =new SimpleDateFormat("yyyy-MM-dd");
				HttpClient client = new DefaultHttpClient();
				HttpPost post = new HttpPost(
						applicationpanel.getBase() + "query/javainsertcustomer.php");

				try {

					List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(
							1);
					nameValuePairs.add(new BasicNameValuePair("addedit", custtextfield.getText()));
					nameValuePairs.add(new BasicNameValuePair("txtfname",field_firstname.getText()));
					nameValuePairs.add(new BasicNameValuePair("txtlname",field_lastname.getText()));
					nameValuePairs.add(new BasicNameValuePair("txtdno",field_doorno.getText()));
					nameValuePairs.add(new BasicNameValuePair("txtstreet",field_street.getText()));
					nameValuePairs.add(new BasicNameValuePair("txtlty", field_locality.getText()));
					nameValuePairs.add(new BasicNameValuePair("txtcity",field_city.getText()));
					nameValuePairs.add(new BasicNameValuePair("txtstate",field_state.getText()));
					nameValuePairs.add(new BasicNameValuePair("txtcno",field_contactno.getText()));
					nameValuePairs.add(new BasicNameValuePair("txtemail",field_email.getText()));
					nameValuePairs.add(new BasicNameValuePair("txtfdate",sdf.format(datesubs.getDate())));
					
					post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
					HttpResponse response = client.execute(post);
					BufferedReader rd = new BufferedReader(new InputStreamReader(
							response.getEntity().getContent()));

					String line = "";
					
					while ((line = rd.readLine()) != null) 
					{
						System.out.println(line);

					}

					
					custtextfield.setText("");
					field_firstname.setText("");
					field_lastname.setText("");
					field_doorno.setText("");
					field_locality.setText("");
					field_city.setText("");
					field_state.setText("");
					field_contactno.setText("");
					field_email.setText("");
					field_uname.setText("");
					field_pname.setText("");
					customerloaddata();
										
					custbool =true;

				}
				catch (IOException e3) 
				{
					e3.printStackTrace();
				}
		
			
		}
		
		
		
				else if(e.getSource().equals(search))
				{
			
					customersearchloaddata();
					tablepanel1.updateUI();
				}
		
		
				else if(e.getSource().equals(subsearch))
				{
			
					customersubsearchloaddata();
					tablepanel2.updateUI();
				}
				else if(e.getSource().equals(Clear))
					
				{
					custtextfield.setText("");
					field_firstname.setText("");
					field_lastname.setText("");
					field_doorno.setText("");
					field_locality.setText("");
					field_city.setText("");
					field_state.setText("");
					field_contactno.setText("");
					field_email.setText("");
					field_uname.setText("");
					field_pname.setText("");
					datesubs.setDate(new Date());
			
				}
		
	}

	@Override
	public void mouseClicked(MouseEvent e) 
	{
		if(e.getSource().equals(table2))
		{
			titleVector.clear();
			sarcVector.clear();
			int userid=0;
			
			int selectedRow = table2.getSelectedRow();
	
			if (selectedRow > -1)
			{
				try 
				{
					int tableId = 0;				
					if (selectedRow > -1) 
					{
						tableId = (int) Integer.parseInt((table2.getValueAt(
								selectedRow, 0)).toString());
						userid = tableId;
					}
					
					HttpClient client = new DefaultHttpClient();
					HttpPost post = new HttpPost(applicationpanel.getBase() +"query/javatitledesk.php");
	
					List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
					nameValuePairs.add(new BasicNameValuePair("cid",String.valueOf(userid)));
					post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
					HttpResponse response = client.execute(post);
					BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));
	
					StringBuffer buffer = new StringBuffer();
					String line="";
					String ss="";
					
					while ((line = rd.readLine()) != null) 
					{
						buffer.append(line);
						ss = ss + line;
	
					}
					
					if (!ss.isEmpty()) 
					{
				
						String[] namevaluePairs = buffer.toString().split("\\-\\-");
						for (String namevaluePair : namevaluePairs) 
						{
							if (namevaluePair.contains("|")) 
							{
								
							String[] pairArray = namevaluePair.split("\\|");
							subscriptiontitleentity ce = new subscriptiontitleentity();
							ce.setTitle(pairArray[0]);
							ce.setSubscriptiondate(pairArray[1]);			
							titleVector.add(ce);
							}
						}
					 }
					
					
				}
					
				
				catch(IOException io)
				{
					io.printStackTrace();
				}
				
				int address = titleVector.size();
				columnData3 = new Object[address][2];
				
				for (int i = 0; i < address; i++) 
				{
					columnData3[i] = titleVector.get(i).getsubscriptiontitle();
				}
				
	
				if (customersubscriptionsearchmodel == null) 
				{
					customersubscriptionsearchmodel = new DefaultTableModel(columnData3, columnNames3) 
					{
						@Override
						public boolean isCellEditable(int row, int col1) 
						{
						if (col1 < 1)
							return false;
						return true;
						}
			
						@Override
						public Class getColumnClass(int c)
						{
							try 
							{
								return getValueAt(0, c).getClass();
							} 
							catch (Exception exception) 
							{
								return String.class;
							}
						}
					};
				}
				else 
				{
					customersubscriptionsearchmodel.setDataVector(columnData3, columnNames3);
				}
				if (customersubscriptionsearchtable == null)
					customersubscriptionsearchtable = new JTable(customersubscriptionsearchmodel);
					customersubscriptionsearchtable.updateUI();
					
				
					try 
					{
						int tableId = 0;				
						if (selectedRow > -1) 
						{
							tableId = (int) Integer.parseInt((table2.getValueAt(selectedRow, 0)).toString());
							userid = tableId;
						}
						
						HttpClient client = new DefaultHttpClient();
						HttpPost post = new HttpPost(applicationpanel.getBase() +"query/javastoryarcdesk.php");
	
						List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
						nameValuePairs.add(new BasicNameValuePair("cid",String.valueOf(userid)));
						post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
						HttpResponse response = client.execute(post);
						BufferedReader rd = new BufferedReader(new InputStreamReader(
						response.getEntity().getContent()));
	
						StringBuffer buffer = new StringBuffer();
						String line="";
						String ss="";
						
						while ((line = rd.readLine()) != null) 
						{
							buffer.append(line);
							ss = ss + line;
	
						}
				
						if (!ss.isEmpty()) 
						{
					
							String[] namevaluePairs = buffer.toString().split("\\-\\-");
							for (String namevaluePair : namevaluePairs) 
							{
								if (namevaluePair.contains("|")) 
								{
									
								String[] pairArray = namevaluePair.split("\\|");
								subscriptionstoryarcentity ce = new subscriptionstoryarcentity();
								ce.setIssue_code(pairArray[0]);
								ce.setStoryarc_name(pairArray[1]);
								ce.setRelease_date(pairArray[2]);
								sarcVector.add(ce);
								}
							}
						 }
						
						
					}
						
					
					catch(IOException io)
					{
						io.printStackTrace();
					}
					
					int address1 = sarcVector.size();
					columnData4 = new Object[address1][3];
					
					for (int i = 0; i < address1; i++) 
					{
						columnData4[i] = sarcVector.get(i).getSubscriptionStoryArc();
					}
					
	
					if (customersubscriptionsearchmodel1 == null) 
					{
						customersubscriptionsearchmodel1 = new DefaultTableModel(columnData4, columnNames4) 
						{
							@Override
							public boolean isCellEditable(int row, int col1) 
							{
							if (col1 < 2)
								return false;
							return true;
							}
				
							@Override
							public Class getColumnClass(int c)
							{
								try 
								{
									return getValueAt(0, c).getClass();
								} 
								catch (Exception exception) 
								{
									return String.class;
								}
							}
						};
					}
					else 
					{
						customersubscriptionsearchmodel1.setDataVector(columnData4, columnNames4);
					}
					if (customersubscriptionsearchtable1 == null)
						customersubscriptionsearchtable1 = new JTable(customersubscriptionsearchmodel1);
						customersubscriptionsearchtable1.updateUI();
				
				
			
			}
	}
	
	
	
	
	else if(e.getSource().equals(table1))
	{

		int userid=0;
		
		int selectedRow = table1.getSelectedRow();

		if (selectedRow > -1)
		{
			int tableId = 0;
			try 
			{

				if (selectedRow > -1) 
				{
					tableId = (int) Integer.parseInt((table1.getValueAt(
							selectedRow, 0)).toString());
					userid = tableId;
				}
				
				HttpClient client = new DefaultHttpClient();
				HttpPost post = new HttpPost(applicationpanel.getBase() +"query/jarvistablesetvalue.php");

				List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
				nameValuePairs.add(new BasicNameValuePair("id",String.valueOf(userid)));
				post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse response = client.execute(post);
				BufferedReader rd = new BufferedReader(new InputStreamReader(
				response.getEntity().getContent()));

				StringBuffer buffer = new StringBuffer();

				String line = "";
				while ((line = rd.readLine()) != null) 
				{
					buffer.append(line);
				}

				
				String[] namevaluePairs = buffer.toString().split("\\-\\-");

				for (String namevaluePair : namevaluePairs) 
				{
					String[] pairArray = namevaluePair.split("\\|");
					
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

					

					custtextfield.setText(pairArray[0]);
					field_firstname.setText(pairArray[2]);
					field_lastname.setText(pairArray[3]);
					field_customerno.setText(pairArray[1]);
					field_doorno.setText(pairArray[4] +" "+pairArray[5]);
					field_locality.setText(pairArray[6]);
					field_city.setText(pairArray[7]);
					field_state.setText(pairArray[8]);
					field_contactno.setText(pairArray[9]);
					field_email.setText(pairArray[10]);
					String s21 = pairArray[12];
					Date dd1 = null;

					dd1 = sdf.parse(s21);
					datesubs.setDate(dd1);
					
					
						
				}
			}
				
			
			catch(IOException io)
			{
				io.printStackTrace();
			} catch (ParseException e3) 
			{
				// TODO Auto-generated catch block
				e3.printStackTrace();
			}
		
		}	
	}
	
	}
	

	@Override
	public void mousePressed(MouseEvent e) 
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	}




