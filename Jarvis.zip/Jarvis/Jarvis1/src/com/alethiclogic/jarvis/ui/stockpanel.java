package com.alethiclogic.jarvis.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.filechooser.FileFilter;
import javax.swing.table.DefaultTableModel;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class stockpanel extends JPanel implements ActionListener
{
	//declaration 
	
	private   JPanel northpanel;
	private   JPanel centerpanel;
	private   JPanel southpanel;
	private JTextField stocktextfield;
	private JButton browse;
	private JLabel empty;
	private Sheet sheet2;
	private JLabel label_stock = new JLabel("Stock  Details");
    //south table declaration

	private JTable stockTable2;
	private DefaultTableModel catalogmodel2;
	Object[] columnNames = new Object[] { "Issue Code","Issue Name","price","Release Date" };
	Object[][] columnData = new Object[][] {};
	DefaultTableModel model = new DefaultTableModel(columnData, columnNames);
	JTable table1 = new JTable(model);
	JPanel tablepanel1 = new JPanel(new GridLayout());
	private Vector<stockentity>issuestockEntitiesvector =new Vector<stockentity>();

	//center table declaration

	private JTable catalogTabel1;
	private DefaultTableModel catalogmodel1;
	Object[] columnNames1 = new Object[] {};
	Object[][] columnData1 = new Object[][] {};
	DefaultTableModel model1 = new DefaultTableModel(columnData1, columnNames1);
	JTable table2 = new JTable(model1);
	JPanel tablepanel2 = new JPanel(new GridLayout());

	
	private JFileChooser filechoser=new JFileChooser();
	
	public stockpanel()
	{
		 issuestockloaddata();
		 setLayout(new BorderLayout());
		 northpanel=new JPanel();
		 centerpanel=new JPanel();
		 southpanel=new JPanel(new BorderLayout());
		 stocktextfield=new JTextField();
		 browse=new JButton("Browse");
		 empty=new JLabel();
		 
		 northpanel.setPreferredSize(new Dimension(660,50));
		 /*southpanel.setPreferredSize(new Dimension(660,280));*/
		 southpanel.setPreferredSize(new Dimension(660,500));
		 label_stock.setPreferredSize(new Dimension(125, 35));
		 stocktextfield.setPreferredSize(new Dimension(350,35));
		 browse.setPreferredSize(new Dimension(100,35));
		 //empty.setPreferredSize(new Dimension(300,35));
		 tablepanel1.setPreferredSize(new Dimension(650,270));
		 tablepanel2.setPreferredSize(new Dimension(650,230));
	
		 label_stock.setForeground(Color.white);
		 
		 southpanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		 northpanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		 centerpanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
			
		 
		 //set the Actionlistner
		 
		 browse.addActionListener(this);
		 
		 
		//set the scroll pane 

		 tablepanel1.add(new JScrollPane(table1));
		 southpanel.add(tablepanel1, BorderLayout.CENTER);
		/* tablepanel2.add(new JScrollPane(table2));
		 centerpanel.add(tablepanel2, BorderLayout.CENTER);*/

		 northpanel.add(label_stock,BorderLayout.WEST);
		 northpanel.add(stocktextfield,BorderLayout.CENTER);
		 northpanel.add(browse,BorderLayout.EAST);
		 //northpanel.add(empty,BorderLayout.EAST);
		 
		 add(southpanel,BorderLayout.SOUTH);
		 add(northpanel,BorderLayout.NORTH);
		 //add(centerpanel,BorderLayout.CENTER);
		 
		 northpanel.setOpaque(true);
		 northpanel.setBackground(Color.DARK_GRAY);
		 southpanel.setOpaque(true);
		 southpanel.setBackground(Color.DARK_GRAY);
		 
	}
	
	private void issuestockloaddata()
	{

		issuestockEntitiesvector.clear();
		try {

			HttpClient client = new DefaultHttpClient();
			HttpGet request = new HttpGet(
					applicationpanel.getBase() + "query/javajarvisstock.php");
			HttpResponse response = client.execute(request);
			BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));

			//dccombo_cname.removeAllElements();
			
			StringBuffer buffer = new StringBuffer();

			String line = "";
			String ss = "";
			while ((line = rd.readLine()) != null) {
				buffer.append(line);
				ss = ss + line;
			}
			if (!ss.isEmpty()) {

				String[] namevaluePairs = buffer.toString().split("\\-\\-");

				for (String namevaluePair : namevaluePairs) {
					if (namevaluePair.contains("|")) {
						String[] pairArray = namevaluePair.split("\\|");
						
						stockentity ce = new stockentity();
						
						if (pairArray[0] != null && !pairArray[0].isEmpty())
						{
							ce.setIssuecode(pairArray[0]);
						}
						else
						{
							ce.setIssuecode(" ");
						}
						if (pairArray[1] != null && !pairArray[1].isEmpty())
						{
							ce.setCatname(pairArray[1]);
						}
						else
						{
							ce.setCatname(" ");
						}
						if (pairArray[2] != null && !pairArray[2].isEmpty())
						{
							ce.setPrice(pairArray[2]);
						}
						else
						{
							ce.setPrice(" ");
						}
						if (pairArray[3] != null && !pairArray[3].isEmpty())
						{
							ce.setReleasedate(pairArray[3]);
						}
						else
						{
							ce.setReleasedate(" ");
						}
						
						issuestockEntitiesvector.add(ce);
				
					}
				}
			}

		} catch (IOException e3) {
			e3.printStackTrace();
		}

		int address = issuestockEntitiesvector.size();

		Object[][] columnData = new Object[address][4];

		for (int i = 0; i < address; i++) {
			columnData[i] = issuestockEntitiesvector.get(i).getissuecatdetails();
		}

		if (model == null) {
			model= new DefaultTableModel(columnData, columnNames) {
				@Override
				public boolean isCellEditable(int row, int col1) {
					if (col1 < 3)
						return false;
					return true;
				}

				@Override
				public Class getColumnClass(int c) {
					try {
						return getValueAt(0, c).getClass();
					} catch (Exception exception) {
						return String.class;
					}
				}
			};
		} else {
			model.setDataVector(columnData, columnNames);
		}
		if (stockTable2 == null)
			stockTable2 = new JTable(model);
		stockTable2.updateUI();
	
	
	}

		public static void main(String[] args) 
	{
		try
		{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JFrame frame = new JFrame("Stock Panel");
		frame.add(new stockpanel());
		frame.setSize(660,600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		frame.setLocation((screenSize.width - 800) / 2, (screenSize.height - 475) / 2);
		
		frame.setVisible(true);
		frame.setResizable(false);
	}

	@Override
	public void actionPerformed(ActionEvent e)
	{
	Object object=e.getSource();
	filechoser.setFileFilter(new FileFilter()
	{

		@Override
		public String getDescription()
		{
			return "(*.xls) Text Files Only";
		}

		@Override
		public boolean accept(File f)
		{
			if (f.isDirectory()
					|| f.getName().toLowerCase().endsWith(".xls"))
				return true;
			return false;
		}
	});


	
	if(object.equals(browse))
	{
				
		if (filechoser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION)
		{
			stocktextfield.setText(filechoser.getSelectedFile().getAbsolutePath());
			

			if (filechoser.getSelectedFile() != null)
			{
				try
				{
					File file = filechoser.getSelectedFile();
					
					Workbook wb = Workbook.getWorkbook(file);
										
					for (int sheetCounter = 0; sheetCounter < 1; sheetCounter++)
					{
						Sheet sheet = wb.getSheet(sheetCounter);
						
						StringBuilder sto=new StringBuilder();
						for (int rowCounter = 1,rows = sheet.getRows(); rowCounter < rows; rowCounter++)
						{
							
							String issueNumber = sheet.getCell(1, rowCounter).getContents();
							if (issueNumber != null && !issueNumber.replaceAll(" ", "").isEmpty())
							{
								sto  = sto.append( sheet.getCell(1, rowCounter).getContents() + "|" + sheet.getCell(3, rowCounter).getContents() + "|" + sheet.getCell(21, rowCounter).getContents() + "|" + sheet.getCell(8, rowCounter).getContents() + "|" + sheet.getCell(10, rowCounter).getContents() + "|" + sheet.getCell(26, rowCounter).getContents() + "|" + sheet.getCell(4, rowCounter).getContents() + "|" ); 
							}
							sto.append("--");
													
						}
						HttpClient client = new DefaultHttpClient();
						HttpPost post = new HttpPost(applicationpanel.getBase() + "query/insertavailablelist.php");
						List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
						nameValuePairs.add(new BasicNameValuePair("ipstock",sto.toString()));
						post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
						HttpResponse response = client.execute(post);
						BufferedReader rd = new BufferedReader(new InputStreamReader(
						response.getEntity().getContent()));

						String line = "";
						String ss = "";
						StringBuffer buffer = new StringBuffer();

						while ((line = rd.readLine()) != null) 
						{
							buffer.append(line);
							ss = ss + line;
							System.out.println(ss);
						}
						}
						}
					catch (Exception exception)
					{
						JOptionPane.showMessageDialog(null, "Please check the file");
					}
                 }
		}
	}
	
	
	
	
	}

	}


