package com.alethiclogic.jarvis.ui;

public class subscriptiontitleentity 
{
	
	private String title;
	private String subscriptiondate;
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getSubscriptiondate() {
		return subscriptiondate;
	}
	public void setSubscriptiondate(String subscriptiondate) {
		this.subscriptiondate = subscriptiondate;
	}

	
	public Object[] getsubscriptiontitle()
	{
		Object[] temp=new Object[2];
		temp[0]=title;
		temp[1]=subscriptiondate;
		return temp;
	}


}
