package com.alethiclogic.jarvis.ui;

public class stockentity {
	

	private String issuecode;
	private String stockname;
	private String price;
	private String releasedate;
	
	

	public String getPrice()
	{
		return price;
	}
	public void setPrice(String price)
	{
		this.price = price;
	}
	public String getReleasedate() 
	{
		return releasedate;
	}
	public void setReleasedate(String releasedate) 
	{
		this.releasedate = releasedate;
	}
	public String getIssuecode()
	{
		return issuecode;
	}
	public void setIssuecode(String issuecode) {
		this.issuecode = issuecode;
	}
	
	public String getCatname() {
		return stockname;
	}
	public void setCatname(String catname) {
		this.stockname = catname;
	}
	
	public Object[] getissuecatdetails()
	{
		Object[] temp=new Object[4];
		
		temp[0]=issuecode;
		temp[1]=stockname;
		temp[2]=price;
		temp[3]=releasedate;

		return temp;
	}

	public String toString()
	{
		return stockname;
	}
		

}
