package com.alethiclogic.jarvis.ui;

public class customerEntity {

	private String custid;
	private String FirstName;
	private String LastName;
	private String DoorNo;
	private String Locality;
	private String city;
	private String state;
	private String ContactNo;
	private String Email;
	private String FromDate;
	private String username;
	private String password;
	private String street;
	private boolean bool=false;
	
	

	public String getStreet() {
		return street;
	}


	public void setStreet(String street) {
		this.street = street;
	}


	public boolean isBool() {
		return bool;
	}


	public void setBool(boolean bool) {
		this.bool = bool;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getCustid() {
		return custid;
	}


	public void setCustid(String custid) {
		this.custid = custid;
	}


	public String getFirstName() 
	{
		return FirstName;
	}


	public void setFirstName(String firstName)
	{
		FirstName = firstName;
	}


	public String getLastName() 
	{
		return LastName;
	}


	public void setLastName(String lastName) 
	{
		LastName = lastName;
	}


	public String getDoorNo() 
	{
		return DoorNo;
	}


	public void setDoorNo(String doorNo) 
	{
		DoorNo = doorNo;
	}

	public String getLocality() 
	{
		return Locality;
	}


	public void setLocality(String locality) 
	{
		Locality = locality;
	}


	public String getCity() 
	{
		return city;
	}


	public void setCity(String city) 
	{
		this.city = city;
	}


	public String getFromDate() 
	{
		return FromDate;
	}


	public void setFromDate(String fromDate) 
	{
		FromDate = fromDate;
	}


	public String getContactNo() 
	{
		return ContactNo;
	}


	public void setContactNo(String contactNo) 
	{
		ContactNo = contactNo;
	}


	public String getEmail() 
	{
		return Email;
	}


	public void setEmail(String email) 
	{
		Email = email;
	}


	public Object[] getcustomerdetails()
	{
		Object[] temp=new Object[4];
	
		temp[0]=custid;
		temp[1]=FirstName + " " + LastName;
		temp[2]=DoorNo + " " + street + " "  + Locality + " " + city  + " " + state ;
		temp[3]=ContactNo;	
		
		return temp;
	}
	
	public Object[] getcustomersubscription()
	{
		Object[] temp=new Object[4];
	
		temp[0]=custid;
		temp[1]=FirstName + " " + LastName;
		temp[2]=DoorNo + " " + street + " " + Locality + " " + city  + " " + state ;
		temp[3]=ContactNo;	
		
		return temp;
	}
	
	public Object[] getsubcustomersubscription()
	{
		Object[] temp=new Object[4];
	
		//temp[]=custid;
		temp[0]=custid;
		temp[1]=FirstName + " " + LastName;
		temp[2]=DoorNo + " "  + Locality + " " + city  + "" + state ;
		temp[3]=ContactNo;	
		
		
		
		return temp;
	}
	
	

	public String toString()
	{
		return FirstName + " " + LastName;
		
	}

	}


