package com.alethiclogic.jarvis.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JEditorPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

public class Emaildialog extends JDialog implements ActionListener
{
private JPanel mainpanel=new JPanel(new BorderLayout());
private JPanel centerpanel=new JPanel();
private JPanel centerpanelwest=new JPanel();
private JPanel centerpaneleast=new JPanel();
private JLabel tolabel=new JLabel("To");
private JLabel cclabel=new JLabel("Cc");
private JLabel subjectlabel=new JLabel("Subject");
private JTextField totxt=new JTextField();
private JTextField cctxt=new JTextField();
private JTextField subjecttxt=new JTextField();


private JButton sendbutton=new JButton("Send");
private JEditorPane  editorpane=new JEditorPane();

private String ss;
private String stat="";
private String dhost="";
private String dport="";
private String duname="";
private String dpword="";
private String dfrom="";
private String dto="";
private String dsubject="";


	public Emaildialog()
	{
		
		File file = new File("Jarvis.props");
		Properties properties = new Properties();
		
		if (file.exists())
		{
			try {
				properties.load(new FileInputStream(file));
				dhost = properties.getProperty("Smtphost");
				dport = properties.getProperty("Smtpport");
				duname = properties.getProperty("Smtpusername");
				dpword = properties.getProperty("Smtppassword");
				dsubject = properties.getProperty("Defaultsubjectline");
				dfrom = properties.getProperty("Defaultformaddress");
				dto = properties.getProperty("Defaulttoaddress");
				
			}
			catch (Exception e) {
				// TODO: handle exception
			}
		}
		
		init();
		loaddata();
	}
	
	public void loaddata()
	{
		try 
		{
			HttpClient client = new DefaultHttpClient();
			HttpPost post = new HttpPost(
			applicationpanel.getBase() + "query/javaMailData.php");

			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
			nameValuePairs.add(new BasicNameValuePair("stat","-5"));
			
			post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			HttpResponse response = client.execute(post);
			BufferedReader rd = new BufferedReader(new InputStreamReader(
			response.getEntity().getContent()));

			String line = "";
			ss="";

			StringBuffer buffer = new StringBuffer();

			while ((line = rd.readLine()) != null) 
			{
				buffer.append(line);
				ss = ss + line;
			}
			
			if(!ss.equals("<center>There is No Subscription Details to Send</center>"))
			{
				if (!ss.isEmpty()) 
				{
				String[] namevaluePairs = buffer.toString().split("\\-\\-");
					for (String namevaluePair : namevaluePairs) 
					{
						if (namevaluePair.contains("|")) 
						{
						    String[] pairArray = namevaluePair.split("\\|");
						    
						    if (pairArray[0] != null && !pairArray[0].isEmpty())
							{
						    	editorpane.setContentType("text/html");
								editorpane.setText(ss);
							}
						    
						    if (pairArray[1] != null && !pairArray[1].isEmpty())
							{
						    	stat = pairArray[1];
							}
							
						}
					}
				}
			}
			else
			{
				editorpane.setContentType("text/html");
				editorpane.setText("<center>There is No Subscription Details to Send</center>");
			}
			
			
			
		}
		catch (IOException e3) 
		{
			e3.printStackTrace();
		}
	}
	
	
	public void init()
	{
	mainpanel.setPreferredSize(new Dimension(650,650));
	centerpanel.setPreferredSize(new Dimension(600,90));
	centerpanelwest.setPreferredSize(new Dimension(500,120));
	centerpaneleast.setPreferredSize(new Dimension(100,120));
	
	mainpanel.setBackground(Color.DARK_GRAY);
	centerpanel.setBackground(Color.DARK_GRAY);
	centerpanelwest.setBackground(Color.DARK_GRAY);
	centerpaneleast.setBackground(Color.DARK_GRAY);
	
	tolabel.setForeground(Color.WHITE);
	cclabel.setForeground(Color.WHITE);
	subjectlabel.setForeground(Color.WHITE);
	
	totxt.setText(dto);
	subjecttxt.setText(dsubject);
		
	tolabel.setPreferredSize(new Dimension(70,30));
	cclabel.setPreferredSize(new Dimension(70,30));
	subjectlabel.setPreferredSize(new Dimension(70,30));
	cctxt.setPreferredSize(new Dimension(400,25));
	subjecttxt.setPreferredSize(new Dimension(400,25));
	totxt.setPreferredSize(new Dimension(400,25));
	sendbutton.setPreferredSize(new Dimension(100,65));
	editorpane.setPreferredSize(new Dimension(600,480));
	
	//mainpanel.setBorder(BorderFactory.createRaisedBevelBorder());
	//centerpanel.setBorder(BorderFactory.createRaisedBevelBorder());
	//south.setBorder(BorderFactory.createRaisedBevelBorder());
	//centerpanelwest.setBorder(BorderFactory.createRaisedBevelBorder());
	editorpane.setBorder(BorderFactory.createEmptyBorder(5,10,5,5));
	//sendbutton.setBorder(BorderFactory.createEmptyBorder(5,10,5,5));
	centerpanelwest.add(tolabel,BorderLayout.WEST);
	centerpanelwest.add(totxt,BorderLayout.CENTER);
	/*centerpanelwest.add(cclabel,BorderLayout.WEST);
	centerpanelwest.add(cctxt,BorderLayout.CENTER);*/
	centerpanelwest.add(subjectlabel,BorderLayout.WEST);
	centerpanelwest.add(subjecttxt,BorderLayout.CENTER);
	centerpaneleast.add(sendbutton,BorderLayout.CENTER);
	
	
	centerpanel.add(centerpanelwest,BorderLayout.WEST);
	centerpanel.add(centerpaneleast,BorderLayout.EAST);
	
	sendbutton.addActionListener(this);
	
	mainpanel.add(centerpanel,BorderLayout.NORTH);
	mainpanel.add(new JScrollPane(editorpane),BorderLayout.CENTER);
	this.add(mainpanel);
	this.setSize(650,650);
	this.setVisible(true);
	this.setTitle("Compose Email");
	this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
	
	}


	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource().equals(sendbutton))
		{
			String to,cc,subject;
			
			if(!ss.equals("<center>There is No Subscription Details to Send</center>"))
			{
				to=totxt.getText();
				cc=cctxt.getText();
				subject=subjecttxt.getText();
				
				if(to != null && !to.isEmpty())
				{
					
					try {
						Properties props = new Properties();
						
						props.put("mail.smtp.auth", "true");
						props.put("mail.smtp.starttls.enable", "true");
						props.put("mail.smtp.host", dhost);
						props.put("mail.smtp.port", dport);
				 		
				//		props.setProperty("mail.smtp.host", "smtp.gmail.com");
						Session session = Session.getDefaultInstance(props,  new javax.mail.Authenticator() {
							protected PasswordAuthentication getPasswordAuthentication() {
								return new PasswordAuthentication(duname, dpword);
							}
						  });
						
				        String msgBody = editorpane.getText();
			            Message msg = new MimeMessage(session);
			            
			            msg.setFrom(new InternetAddress(dfrom));
			            msg.addRecipient(Message.RecipientType.TO,new InternetAddress(to));
			            msg.setHeader("content-type", editorpane.getContentType());
			            msg.setSubject(subject);
			            msg.setContent(editorpane.getText(), "text/html");
			            Transport.send(msg);
			            JOptionPane.showMessageDialog(this,"Email has been Sent");
			            
			            try
				        {
				        	HttpClient client = new DefaultHttpClient();
							HttpPost post = new HttpPost(applicationpanel.getBase() + "query/javaMailData.php");
							List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
						
							nameValuePairs.add(new BasicNameValuePair("stat",stat));
							
							post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
							HttpResponse response = client.execute(post);
							BufferedReader rd = new BufferedReader(new InputStreamReader(
							response.getEntity().getContent()));
	
							String line = "";
							ss="";
							
							StringBuffer buffer = new StringBuffer();
	
							while ((line = rd.readLine()) != null) 
							{
								buffer.append(line);
								ss = ss + line;
							}
	
							editorpane.setText("<center>There is No Subscription Details to Send</center>");
	
				        }
				        catch (Exception e1) 
				        {
				        	e1.printStackTrace();
						}
			            
			        } catch (AddressException e2) {
			            JOptionPane.showMessageDialog(this,"Process Aborted");
			        	e2.printStackTrace();
			        } catch (MessagingException e3) {
			            JOptionPane.showMessageDialog(this,"Process Aborted");
			        	e3.printStackTrace();
			        }
			    }
				else
				{
					JOptionPane.showMessageDialog(this, "Please Enter the Send Mail Address");
				}
					
				
			}
			else
			{
				if(JOptionPane.showConfirmDialog(this, "There is No Subscription to Send, Do you want to Continue to Send Mail?", "Are You Sure!",JOptionPane.YES_NO_OPTION) ==0)
				{
					to=totxt.getText();
					cc=cctxt.getText();
					subject=subjecttxt.getText();
					
					if(to != null && !to.isEmpty())
					{
						
						try {
							Properties props = new Properties();
							
							props.put("mail.smtp.auth", "true");
							props.put("mail.smtp.starttls.enable", "true");
							props.put("mail.smtp.host", dhost);
							props.put("mail.smtp.port", dport);
					 		
					//		props.setProperty("mail.smtp.host", "smtp.gmail.com");
							Session session = Session.getDefaultInstance(props,  new javax.mail.Authenticator() {
								protected PasswordAuthentication getPasswordAuthentication() {
									return new PasswordAuthentication(duname, dpword);
								}
							  });
							
					        String msgBody = editorpane.getText();
				            Message msg = new MimeMessage(session);
				            
				            msg.setFrom(new InternetAddress(dfrom));
				            msg.addRecipient(Message.RecipientType.TO,new InternetAddress(to));
				            msg.setHeader("content-type", editorpane.getContentType());
				            msg.setSubject(subject);
				            msg.setContent(editorpane.getText(), "text/html");
				            Transport.send(msg);
				            JOptionPane.showMessageDialog(this,"Email has been Sent");
				            
				            try
					        {
					        	HttpClient client = new DefaultHttpClient();
								HttpPost post = new HttpPost(applicationpanel.getBase() + "query/javaMailData.php");
								List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
							
								nameValuePairs.add(new BasicNameValuePair("stat",stat));
								
								post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
								HttpResponse response = client.execute(post);
								BufferedReader rd = new BufferedReader(new InputStreamReader(
								response.getEntity().getContent()));
		
								String line = "";
								ss="";
								
								StringBuffer buffer = new StringBuffer();
		
								while ((line = rd.readLine()) != null) 
								{
									buffer.append(line);
									ss = ss + line;
								}
		
								editorpane.setText("<center>There is No Subscription Details to Send</center>");
		
					        }
					        catch (Exception e1) 
					        {
					        	e1.printStackTrace();
							}
				            
				        } catch (AddressException e2) {
				            JOptionPane.showMessageDialog(this,"Process Aborted");
				        	e2.printStackTrace();
				        } catch (MessagingException e3) {
				            JOptionPane.showMessageDialog(this,"Process Aborted");
				        	e3.printStackTrace();
				        }
				    }
					else
					{
						JOptionPane.showMessageDialog(this, "Please Enter the Send Mail Address");
					}
				}
				else
				{
					this.dispose();
				}
			}
		}
		
	}

}