package com.alethiclogic.jarvis.ui;

public class issuecatlogEntity 
{

	private String issuecode;
	private String catname;
	private String price;
	
	

	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getIssuecode() {
		return issuecode;
	}
	public void setIssuecode(String issuecode) {
		this.issuecode = issuecode;
	}
	
	public String getCatname() {
		return catname;
	}
	public void setCatname(String catname) {
		this.catname = catname;
	}
	
	public Object[] getissuecatdetails()
	{
		Object[] temp=new Object[3];
		
		temp[0]=issuecode;
		temp[1]=catname;
		temp[2]=price;
		

		return temp;
	}

	public String toString()
	{
		return catname;
	}

	
}
