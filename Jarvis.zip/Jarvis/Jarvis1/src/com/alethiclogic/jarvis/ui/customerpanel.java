package com.alethiclogic.jarvis.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Savepoint;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.w3c.dom.css.ViewCSS;


public class customerpanel extends JPanel implements ActionListener
{
private  JPanel northpanel;
private  JPanel southpanel;
private JTabbedPane  northtabbedpanel=new JTabbedPane();
private JPanel  southtextpanel=new JPanel(new BorderLayout());

private JPanel southtablepanel=new JPanel();

private JTextField customerfield=new JTextField();
private JButton search=new JButton("Search");
private JLabel empty=new JLabel();
private Vector<customerEntity> customervector =new Vector<customerEntity>();

//This initilaztion for all button with in the box layout panel
private  JTextField fnametextfield=new JTextField();
private  JTextField lnametextfield=new JTextField();
private  JTextField telephonetextfield=new JTextField();
private  JTextField addresstextfield=new JTextField();
private  JTextField emailtextfield=new JTextField();
private  JTextField mobilenotextfield=new JTextField();
private  JLabel fnamelabel=new JLabel("Firstname");
private  JLabel lastlabel=new JLabel("Lastname");
private  JLabel telephonelabel=new JLabel("Telephoneno");
private  JLabel addresslabel=new JLabel("Address");
private  JLabel emaillabel=new JLabel("Emailid");
private  JLabel mobilenolabel=new JLabel("Mobileno");

private  JButton save=new JButton("Save");


private JPanel tab1=new JPanel(new BorderLayout());
private JTable viewsubcustTable;
private DefaultTableModel viewsubcustmodel;
private Object[] columnNames = new Object[] {"Customer Name","Address","Telephone"};
private Object[][] columnData = new Object[][] {};
private DefaultTableModel model = new DefaultTableModel(columnData, columnNames);
private JTable table1 = new JTable(model);	
private JPanel tablepanel1 = new JPanel(new GridLayout());

private JPanel CustDetailsPanel=new JPanel(new BorderLayout());
private JPanel custtable = new JPanel(new BorderLayout());



//initialization

private JLabel label_customerno = new JLabel("Telephone No");
private JLabel label_firstname = new JLabel("First Name");
private JLabel label_lastname = new JLabel("Last Name");
private JLabel label_address = new JLabel("Address");
private JLabel label_doorno = new JLabel("Door no & Street ");
private JLabel label_locality = new JLabel("Locality");
private JLabel label_city = new JLabel("City");
private JLabel label_state = new JLabel("State");
private JLabel label_subscriptionfrom = new JLabel("From");
private JLabel labelempty = new JLabel("");
private JLabel labelempty2 = new JLabel("");
private JLabel label_contactno = new JLabel("Contact no");
private JLabel label_email = new JLabel("Email");
private JLabel label_uname = new JLabel("User Name");
private JLabel label_pname = new JLabel("Password");

private JTextField field_customerno = new JTextField();
private JTextField field_firstname = new JTextField();
private JTextField field_lastname = new JTextField();
private JTextField field_address = new JTextField();
private JTextField field_doorno = new JTextField();
private JTextField field_street = new JTextField();
private JTextField field_locality = new JTextField();
private JTextField field_city = new JTextField();
private JTextField field_state = new JTextField();
private JTextField field_contactno = new JTextField();
private JTextField field_uname = new JTextField();
private JTextField field_pname = new JTextField();
private JTextField field_email = new JTextField();
private XDateChooser datesubs = new XDateChooser();
private JButton butsave = new JButton("Save");
private Boolean custbool = true;

public customerpanel() 
{
init();
}
public void init()
{
		setLayout(new GridLayout(2,1));
		northpanel=new JPanel(new GridLayout());
		southpanel=new JPanel(new BorderLayout());
		
		northtabbedpanel=new JTabbedPane();
		
		northtabbedpanel.add(CustDetailsPanel,"Customer Details");
		northtabbedpanel.add(customersubscriptionpanel(),"Customer Subscription");
		//northtabbedpanel.add(customerdepositepanel(),"Customer Deposit");
		
		//southpanel.setPreferredSize(new Dimension(660,300));
		//southtextpanel.setPreferredSize(new Dimension(660,30));
		//southtablepanel.setPreferredSize(new Dimension(660,250));
		tablepanel1.setPreferredSize(new Dimension(630,230));
				
		customerfield.setPreferredSize(new Dimension(500,35));
		search.setPreferredSize(new Dimension(100,35));
		empty.setPreferredSize(new Dimension(10,35));
		
		
		northpanel.setBorder(BorderFactory.createRaisedBevelBorder());
		southpanel.setBorder(BorderFactory.createRaisedBevelBorder());
		southtextpanel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
		southtablepanel.setBorder(BorderFactory.createRaisedBevelBorder());
		
		search.addActionListener(this);
		
		southtextpanel.add(customerfield,BorderLayout.WEST);
		southtextpanel.add(search,BorderLayout.CENTER);
		southtextpanel.add(empty,BorderLayout.EAST);
		southtextpanel.setBackground(Color.DARK_GRAY);
		southtextpanel.setVisible(true);
	
		tablepanel1.add(new JScrollPane(viewsubcustTable));
		southtablepanel.add(tablepanel1, BorderLayout.CENTER);
		
		southpanel.add(southtextpanel,BorderLayout.NORTH);
		southpanel.add(southtablepanel,BorderLayout.CENTER);
				
		custtable.add(southpanel);
		
		CustDetailsPanel.add(customerdetailspanel(),BorderLayout.NORTH);
		CustDetailsPanel.add(custtable,BorderLayout.CENTER);
					
		northpanel.add(northtabbedpanel);
		
		add(northpanel);
		add(southpanel);

}


public JPanel customerdetailspanel()
{
	 
	 JPanel northtabpanel=new JPanel(new GridLayout());
	 JPanel  northwestpanel1=new JPanel();
	 JPanel  northwestpanel2=new JPanel();

	
	 northtabpanel.setPreferredSize(new Dimension(400,200));
	
	 Font fd= new Font("Arial", Font.BOLD, 12);
	 
	
	 fnamelabel.setFont(fd);
	 lastlabel.setFont(fd);
	 telephonelabel.setFont(fd);
	 addresslabel.setFont(fd);
	 emaillabel.setFont(fd);
	 mobilenolabel.setFont(fd);
	 save.setFont(fd);
	 
	 
		northwestpanel1.setLayout(new BoxLayout(northwestpanel1,
				BoxLayout.PAGE_AXIS));
		northwestpanel2.setLayout(new BoxLayout(northwestpanel2,
				BoxLayout.PAGE_AXIS));

		Component box_100 = Box.createRigidArea(new Dimension(5, 5));
		Box box_101 = Box.createHorizontalBox();
		Component box_1 = Box.createRigidArea(new Dimension(5, 5));
		Box box_2 = Box.createHorizontalBox();
		Component box_3 = Box.createRigidArea(new Dimension(5, 5));
		Box box_4 = Box.createHorizontalBox();
		Component box_5 = Box.createRigidArea(new Dimension(5, 5));
		Box box_6 = Box.createHorizontalBox();
		Component box_7 = Box.createRigidArea(new Dimension(5, 5));
		Box box_8 = Box.createHorizontalBox();
		Component box_9 = Box.createRigidArea(new Dimension(5, 5));
		Box box_10 = Box.createHorizontalBox();
		Component box_11 = Box.createRigidArea(new Dimension(5, 5));
		Box box_12 = Box.createHorizontalBox();
		Component box_13 = Box.createRigidArea(new Dimension(5, 5));
		Box box_14 = Box.createHorizontalBox();
		Component box_15 = Box.createRigidArea(new Dimension(5, 5));
		Box box_16 = Box.createHorizontalBox();
		Component box_17 = Box.createRigidArea(new Dimension(5, 5));
		Box box_18 = Box.createHorizontalBox();
		Component box_19 = Box.createRigidArea(new Dimension(5, 5));
		Box box_20 = Box.createHorizontalBox();
		Component box_21 = Box.createRigidArea(new Dimension(5, 5));
		Box box_22 = Box.createHorizontalBox();
		Component box_23 = Box.createRigidArea(new Dimension(5, 5));
		Box box_24 = Box.createHorizontalBox();
		Component box_25 = Box.createRigidArea(new Dimension(5, 5));
		Box box_26 = Box.createHorizontalBox();
		Component box_27 = Box.createRigidArea(new Dimension(5, 5));
		Box box_28 = Box.createHorizontalBox();
		
		Component box_29 = Box.createRigidArea(new Dimension(5, 5));
		Box box_30 = Box.createHorizontalBox();



		box_101.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox2a2 = new JPanel(new BorderLayout());
		label_customerno.setPreferredSize(new Dimension(100, 25));
		label_customerno.setMaximumSize(new Dimension(100, 25));
		field_customerno.setPreferredSize(new Dimension(150, 25));
		field_customerno.setMaximumSize(new Dimension(150, 25));
		pbox2a2.setMaximumSize(new Dimension(300, 25));
		pbox2a2.add(label_customerno, BorderLayout.WEST);
		pbox2a2.add(field_customerno, BorderLayout.CENTER);
		box_101.add(pbox2a2);
		box_101.add(Box.createRigidArea(new Dimension(0, 10)));
		
		pbox2a2.setBackground(Color.DARK_GRAY);
		pbox2a2.setOpaque(true);
		label_customerno.setForeground(Color.white);
		
		box_2.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox2 = new JPanel(new BorderLayout());
		label_firstname.setPreferredSize(new Dimension(100, 25));
		label_firstname.setMaximumSize(new Dimension(100, 25));
		field_firstname.setPreferredSize(new Dimension(150, 25));
		field_firstname.setMaximumSize(new Dimension(150, 25));
		pbox2.setMaximumSize(new Dimension(300, 25));
		pbox2.add(label_firstname, BorderLayout.WEST);
		pbox2.add(field_firstname, BorderLayout.CENTER);
		box_2.add(pbox2);
		box_2.add(Box.createRigidArea(new Dimension(0, 10)));
		
		pbox2.setBackground(Color.DARK_GRAY);
		pbox2.setOpaque(true);
		label_firstname.setForeground(Color.white);

		box_4.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox4 = new JPanel(new BorderLayout());
		label_address.setPreferredSize(new Dimension(100, 25));
		label_address.setMaximumSize(new Dimension(100, 25));
		field_address.setPreferredSize(new Dimension(150, 25));
		field_address.setMaximumSize(new Dimension(150, 25));
		pbox4.setMaximumSize(new Dimension(300, 25));
		pbox4.add(label_address, BorderLayout.WEST);
		pbox4.add(field_address, BorderLayout.CENTER);
		box_4.add(pbox4);
		box_4.add(Box.createRigidArea(new Dimension(0, 10)));
		
		pbox4.setBackground(Color.DARK_GRAY);
		pbox4.setOpaque(true);
		label_address.setForeground(Color.white);

		box_6.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox6 = new JPanel(new BorderLayout());
		label_locality.setPreferredSize(new Dimension(100, 25));
		label_locality.setMaximumSize(new Dimension(100, 25));
		field_locality.setPreferredSize(new Dimension(150, 25));
		field_locality.setMaximumSize(new Dimension(150, 25));
		pbox6.setMaximumSize(new Dimension(300, 25));
		pbox6.add(label_locality, BorderLayout.WEST);
		pbox6.add(field_locality, BorderLayout.CENTER);
		box_6.add(pbox6);
		box_6.add(Box.createRigidArea(new Dimension(0, 10)));
		
		pbox6.setBackground(Color.DARK_GRAY);
		pbox6.setOpaque(true);
		label_locality.setForeground(Color.white);

		box_8.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox8 = new JPanel(new BorderLayout());
		label_state.setPreferredSize(new Dimension(100, 25));
		label_state.setMaximumSize(new Dimension(100, 25));
		field_state.setPreferredSize(new Dimension(150, 25));
		field_state.setMaximumSize(new Dimension(150, 25));
		pbox8.setMaximumSize(new Dimension(300, 25));
		pbox8.add(label_state, BorderLayout.WEST);
		pbox8.add(field_state, BorderLayout.CENTER);
		box_8.add(pbox8);
		box_8.add(Box.createRigidArea(new Dimension(0, 10)));
		
		pbox8.setBackground(Color.DARK_GRAY);
		pbox8.setOpaque(true);
		label_state.setForeground(Color.white);
		

		box_10.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox10 = new JPanel(new BorderLayout());
		label_email.setPreferredSize(new Dimension(100, 25));
		label_email.setMaximumSize(new Dimension(100, 25));
		field_email.setPreferredSize(new Dimension(150, 25));
		field_email.setMaximumSize(new Dimension(150, 25));
		pbox10.setMaximumSize(new Dimension(300, 25));
		pbox10.add(label_email, BorderLayout.WEST);
		pbox10.add(field_email, BorderLayout.CENTER);
		box_10.add(pbox10);
		box_10.add(Box.createRigidArea(new Dimension(0, 10)));
		
		pbox10.setBackground(Color.DARK_GRAY);
		pbox10.setOpaque(true);
		label_email.setForeground(Color.white);

		box_26.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox26 = new JPanel(new BorderLayout());
		labelempty.setPreferredSize(new Dimension(100, 25));
		labelempty.setMaximumSize(new Dimension(100, 25));
		butsave.setPreferredSize(new Dimension(150, 25));
		butsave.setMaximumSize(new Dimension(150, 25));
								
		pbox26.setMaximumSize(new Dimension(300, 25));
		pbox26.add(labelempty, BorderLayout.WEST);
		pbox26.add(butsave, BorderLayout.CENTER);
		box_26.add(pbox26);
		box_26.add(Box.createRigidArea(new Dimension(0, 10)));
		
		pbox26.setBackground(Color.DARK_GRAY);
		pbox26.setOpaque(true);
		labelempty.setForeground(Color.white);

		
		northwestpanel1.add(box_1);
		northwestpanel1.add(box_2);
		
		northwestpanel1.add(box_100);
		northwestpanel1.add(box_101);
		
		/*northwestpanel1.add(box_3);
		northwestpanel1.add(box_4);*/
		northwestpanel1.add(box_5);
		northwestpanel1.add(box_6);
		northwestpanel1.add(box_7);
		northwestpanel1.add(box_8);
		northwestpanel1.add(box_9);
		northwestpanel1.add(box_10);
		northwestpanel1.add(box_21);
		northwestpanel1.add(box_22);
		northwestpanel1.add(box_25);
		northwestpanel1.add(box_26);
		
		box_30.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox30 = new JPanel(new BorderLayout());
		labelempty2.setPreferredSize(new Dimension(100, 25));
		labelempty2.setMaximumSize(new Dimension(100, 25));
		pbox30.setMaximumSize(new Dimension(300, 25));
		pbox30.add(labelempty2, BorderLayout.WEST);
		pbox30.add(labelempty2, BorderLayout.CENTER);
		box_30.add(pbox30);
		box_30.add(Box.createRigidArea(new Dimension(0, 10)));

		box_12.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox12 = new JPanel(new BorderLayout());
		label_lastname.setPreferredSize(new Dimension(100, 25));
		label_lastname.setMaximumSize(new Dimension(100, 25));
		field_lastname.setPreferredSize(new Dimension(150, 25));
		field_lastname.setMaximumSize(new Dimension(150, 25));
		pbox12.setMaximumSize(new Dimension(300, 25));
		pbox12.add(label_lastname, BorderLayout.WEST);
		pbox12.add(field_lastname, BorderLayout.CENTER);
		box_12.add(pbox12);
		box_12.add(Box.createRigidArea(new Dimension(0, 10)));
		
		pbox12.setBackground(Color.DARK_GRAY);
		pbox12.setOpaque(true);
		label_lastname.setForeground(Color.white);

		box_14.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox14 = new JPanel(new BorderLayout());
		label_doorno.setPreferredSize(new Dimension(100, 25));
		label_doorno.setMaximumSize(new Dimension(100, 25));
		field_doorno.setPreferredSize(new Dimension(150, 25));
		field_doorno.setMaximumSize(new Dimension(150, 25));
		pbox14.setMaximumSize(new Dimension(300, 25));
		pbox14.add(label_doorno, BorderLayout.WEST);
		pbox14.add(field_doorno, BorderLayout.CENTER);
		box_14.add(pbox14);
		box_14.add(Box.createRigidArea(new Dimension(0, 10)));
		
		pbox14.setBackground(Color.DARK_GRAY);
		pbox14.setOpaque(true);
		label_doorno.setForeground(Color.white);

		box_16.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox16 = new JPanel(new BorderLayout());
		label_city.setPreferredSize(new Dimension(100, 25));
		label_city.setMaximumSize(new Dimension(100, 25));
		field_city.setPreferredSize(new Dimension(150, 25));
		field_city.setMaximumSize(new Dimension(150, 25));
		pbox16.setMaximumSize(new Dimension(300, 25));
		pbox16.add(label_city, BorderLayout.WEST);
		pbox16.add(field_city, BorderLayout.CENTER);
		box_16.add(pbox16);
		box_16.add(Box.createRigidArea(new Dimension(0, 10)));
		
		pbox16.setBackground(Color.DARK_GRAY);
		pbox16.setOpaque(true);
		label_city.setForeground(Color.white);

		box_18.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox18 = new JPanel(new BorderLayout());
		label_subscriptionfrom.setPreferredSize(new Dimension(100, 25));
		label_subscriptionfrom.setMaximumSize(new Dimension(100, 25));
		datesubs.setPreferredSize(new Dimension(150, 25));
		datesubs.setMaximumSize(new Dimension(150, 25));
		pbox18.setMaximumSize(new Dimension(300, 25));
		pbox18.add(label_subscriptionfrom, BorderLayout.WEST);
		pbox18.add(datesubs, BorderLayout.CENTER);
		box_18.add(pbox18);
		box_18.add(Box.createRigidArea(new Dimension(0, 10)));
		
		pbox18.setBackground(Color.DARK_GRAY);
		pbox18.setOpaque(true);
		label_subscriptionfrom.setForeground(Color.white);
		

		box_20.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox20 = new JPanel(new BorderLayout());
		label_contactno.setPreferredSize(new Dimension(100, 25));
		label_contactno.setMaximumSize(new Dimension(100, 25));
		field_contactno.setPreferredSize(new Dimension(150, 25));
		field_contactno.setMaximumSize(new Dimension(150, 25));
		pbox20.setMaximumSize(new Dimension(300, 25));
		pbox20.add(label_contactno, BorderLayout.WEST);
		pbox20.add(field_contactno, BorderLayout.CENTER);
		box_20.add(pbox20);
		box_18.add(Box.createRigidArea(new Dimension(0, 10)));
		
		pbox20.setBackground(Color.DARK_GRAY);
		pbox20.setOpaque(true);
		label_contactno.setForeground(Color.white);

		
		box_22.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox22 = new JPanel(new BorderLayout());
		label_uname.setPreferredSize(new Dimension(100, 25));
		label_uname.setMaximumSize(new Dimension(100, 25));
		field_uname.setPreferredSize(new Dimension(150, 25));
		field_uname.setMaximumSize(new Dimension(150, 25));
		pbox22.setMaximumSize(new Dimension(300, 25));
		pbox22.add(label_uname, BorderLayout.WEST);
		pbox22.add(field_uname, BorderLayout.CENTER);
		box_22.add(pbox22);
		box_22.add(Box.createRigidArea(new Dimension(0, 10)));
		
		pbox22.setBackground(Color.DARK_GRAY);
		pbox22.setOpaque(true);
		label_uname.setForeground(Color.white);
		

		box_24.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox24 = new JPanel(new BorderLayout());
		label_pname.setPreferredSize(new Dimension(100, 25));
		label_pname.setMaximumSize(new Dimension(100, 25));
		field_pname.setPreferredSize(new Dimension(150, 25));
		field_pname.setMaximumSize(new Dimension(150, 25));
		pbox24.setMaximumSize(new Dimension(300, 25));
		pbox24.add(label_pname, BorderLayout.WEST);
		pbox24.add(field_pname, BorderLayout.CENTER);
		box_24.add(pbox24);
		box_24.add(Box.createRigidArea(new Dimension(0, 10)));
		
		pbox24.setBackground(Color.DARK_GRAY);
		pbox24.setOpaque(true);
		label_pname.setForeground(Color.white);

		
		box_28.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox28 = new JPanel(new BorderLayout());
		butsave.addActionListener(this);
		labelempty2.setPreferredSize(new Dimension(100, 25));
		labelempty2.setMaximumSize(new Dimension(100, 25));
		butsave.setPreferredSize(new Dimension(150, 25));
		butsave.setMaximumSize(new Dimension(150, 25));
		pbox28.setMaximumSize(new Dimension(300, 25));
		pbox28.add(labelempty2, BorderLayout.WEST);
		pbox28.add(butsave, BorderLayout.CENTER);
		box_28.add(pbox28);
		box_28.add(Box.createRigidArea(new Dimension(0, 10)));
		
		pbox28.setBackground(Color.DARK_GRAY);
		pbox28.setOpaque(true);
		
		pbox30.setBackground(Color.DARK_GRAY);
		pbox30.setOpaque(true);
	
		/*northwestpanel2.add(box_29);
		northwestpanel2.add(box_30);*/
		northwestpanel2.add(box_11);
		northwestpanel2.add(box_12);
		northwestpanel2.add(box_13);
		northwestpanel2.add(box_14);
		northwestpanel2.add(box_15);
		northwestpanel2.add(box_16);
		northwestpanel2.add(box_17);
		northwestpanel2.add(box_18);
		northwestpanel2.add(box_19);
		northwestpanel2.add(box_20);
		northwestpanel2.add(box_19);
		northwestpanel2.add(box_20);
		northwestpanel2.add(box_23);
		northwestpanel2.add(box_24);
		northwestpanel2.add(box_27);
		northwestpanel2.add(box_28);
		
		northwestpanel1.setBackground(Color.DARK_GRAY);
		northwestpanel2.setBackground(Color.DARK_GRAY);
		northtabpanel.add(northwestpanel1);
		northtabpanel.add(northwestpanel2);
		
		customerloaddata();
		
		return northtabpanel;
	
}

public JPanel customersubscriptionpanel()
{
	//declaration
	
		 JPanel tab2=new JPanel(new BorderLayout());
		 JTable customersubscriptiontable;
		 DefaultTableModel customersubscriptionmodel;
		 Object[] columnNames = new Object[] {"Firstname","Lastname","Address","Telephone"};
		 Object[][] columnData = new Object[][] {};
		 DefaultTableModel model = new DefaultTableModel(columnData, columnNames);
		 JTable table1 = new JTable(model);	
		 JPanel tablepanel1 = new JPanel(new GridLayout());
		
		 
		 tablepanel1.add(new JScrollPane(table1));
		 tab2.add(tablepanel1, BorderLayout.CENTER);
		 add(tab2);
		 return tab2;
	
}

 
private void customerloaddata() 
{
		customervector.clear();
		try 
		{
		HttpClient client = new DefaultHttpClient();
		HttpGet request = new HttpGet(applicationpanel.getBase() + "query/javacust.php");
		HttpResponse response = client.execute(request);
		BufferedReader rd = new BufferedReader(new InputStreamReader(
		response.getEntity().getContent()));
		
		//dccombo_cname.removeAllElements();
		
		StringBuffer buffer = new StringBuffer();

		String line = "";
		String ss = "";
		while ((line = rd.readLine()) != null) 
		{
			buffer.append(line);
			ss = ss + line;
		}
			if (!ss.isEmpty()) 
			{

				String[] namevaluePairs = buffer.toString().split("\\-\\-");
		
				for (String namevaluePair : namevaluePairs) 
				{
					if (namevaluePair.contains("|")) 
				  {
					    String[] pairArray = namevaluePair.split("\\|");
				
					    customerEntity ce = new customerEntity();
				
					
					if (pairArray[0] != null && !pairArray[0].isEmpty())
					{
						ce.setCustid(pairArray[0]);
					}
					else
					{
						ce.setCustid(" ");
					}
				
					if (pairArray[2] != null && !pairArray[2].isEmpty())
					{
						ce.setFirstName(pairArray[2]);
					}
					else
					{
						ce.setFirstName(" ");
					}
					if (pairArray[3] != null && !pairArray[3].isEmpty())
					{
						ce.setLastName(pairArray[3]);
					}
					else
					{
						ce.setLastName(" ");
					}
					if (pairArray[4] != null && !pairArray[4].isEmpty())
					{
						ce.setDoorNo(pairArray[4]);
					}
					else
					{
						ce.setDoorNo(" ");
					}
					if (pairArray[6] != null && !pairArray[6].isEmpty())
					{
						ce.setLocality(pairArray[6]);
					}
					else
					{
						ce.setLocality(" ");
					}
					if (pairArray[7] != null && !pairArray[7].isEmpty())
					{
						ce.setCity(pairArray[7]);
					}
					else
					{
						ce.setCity(" ");
					}

					if (pairArray[8] != null && !pairArray[8].isEmpty())
					{
						ce.setState(pairArray[8]);
					}
					else
					{
						ce.setState(" ");
					}
					
					if (pairArray[9] != null && !pairArray[9].isEmpty())
					{
						ce.setContactNo(pairArray[9]);
					}
					else
					{
						ce.setContactNo(" ");
					}
					if (pairArray[10] != null && !pairArray[10].isEmpty())
					{
						ce.setEmail(pairArray[10]);
					}
					else
					{
						ce.setEmail(" ");
					}
					if (pairArray[12] != null && !pairArray[12].isEmpty())
					{
						ce.setFromDate(pairArray[12]);
					}
					else
					{
						ce.setFromDate(" ");
					}
					
					customervector.add(ce);
			
				}
			}
		}
		
	} 			catch (IOException e3) 
				{
					e3.printStackTrace();
				}

				int address = customervector.size();
			 	Object[][] columnData = new Object[address][4];
			    for (int i = 0; i < address; i++) 
			    {
			    columnData[i] = customervector.get(i).getcustomerdetails();
			    }
			    if (model == null) 
			    {
			    	model = new DefaultTableModel(columnData, columnNames) 
			    	{
						@Override
						public boolean isCellEditable(int row, int col1) 
						{
										if (col1 < 3)
											return false;
										return true;
						}

						@Override
						public Class getColumnClass(int c) 
						{
								try 
								{
									return getValueAt(0, c).getClass();
								} 
								catch (Exception exception) 
								{
											return String.class;
								}
						}
			    	};
		} 
			    else 
			    {
			    	model.setDataVector(columnData, columnNames);
			    }
			    if (viewsubcustTable == null)
			    	viewsubcustTable = new JTable(model);
			    	viewsubcustTable.updateUI();
}


		
private void customersearchloaddata()
{/*
			customervector.clear();
			try {

						HttpClient client = new DefaultHttpClient();
						HttpPost post = new HttpPost(
						applicationpanel.getBase() + "query/javasearchcust.php");
						List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);

						//String sd =((customerEntity) combo_cname.getSelectedItem()).getCustid();
						//System.out.println(sd);
					
						nameValuePairs.add(new BasicNameValuePair("id",field_firstname.getText()));
						nameValuePairs.add(new BasicNameValuePair("cno",field_lastname.getText()));
						nameValuePairs.add(new BasicNameValuePair("addr",field_address.getText()));
				
						nameValuePairs.add(new BasicNameValuePair("sear",customerfield.getText()));
						
						post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
						HttpResponse response = client.execute(post);
						BufferedReader rd = new BufferedReader(new InputStreamReader(
						response.getEntity().getContent()));

						String[] array;
						String line = "";
						String ss = "";
						int j = 0;
				
						StringBuffer buffer = new StringBuffer();

						while ((line = rd.readLine()) != null) 
						{
							buffer.append(line);
							ss = ss + line;

						}
						//System.out.println(ss +"lp");
				
						if (!ss.isEmpty()) 
						{
					
							String[] namevaluePairs = buffer.toString().split("\\-\\-");
							for (String namevaluePair : namevaluePairs) 
							{
							if (namevaluePair.contains("|")) 
							{
								
							String[] pairArray = namevaluePair.split("\\|");
							customerEntity ce = new customerEntity();
							
							if (pairArray[0] != null && !pairArray[0].isEmpty())
							{
								ce.setCustid(pairArray[0]);
							}
							else
							{
								ce.setCustid(" ");
							}
						
							if (pairArray[2] != null && !pairArray[2].isEmpty())
							{
								ce.setFirstName(pairArray[2]);
							}
							else
							{
								ce.setFirstName(" ");
							}
							if (pairArray[3] != null && !pairArray[3].isEmpty())
							{
								ce.setLastName(pairArray[3]);
							}
							else
							{
								ce.setLastName(" ");
							}
							if (pairArray[4] != null && !pairArray[4].isEmpty())
							{
								ce.setDoorNo(pairArray[4]);
							}
							else
							{
								ce.setDoorNo(" ");
							}
							if (pairArray[6] != null && !pairArray[6].isEmpty())
							{
								ce.setLocality(pairArray[6]);
							}
							else
							{
								ce.setLocality(" ");
							}
							if (pairArray[7] != null && !pairArray[7].isEmpty())
							{
								ce.setCity(pairArray[7]);
							}
							else
							{
								ce.setCity(" ");
							}

							if (pairArray[8] != null && !pairArray[8].isEmpty())
							{
								ce.setState(pairArray[8]);
							}
							else
							{
								ce.setState(" ");
							}
							
							if (pairArray[9] != null && !pairArray[9].isEmpty())
							{
								ce.setContactNo(pairArray[9]);
							}
							else
							{
								ce.setContactNo(" ");
							}
							if (pairArray[10] != null && !pairArray[10].isEmpty())
							{
								ce.setEmail(pairArray[10]);
							}
							else
							{
								ce.setEmail(" ");
							}
							if (pairArray[12] != null && !pairArray[12].isEmpty())
							{
								ce.setFromDate(pairArray[12]);
							}
							else
							{
								ce.setFromDate(" ");
							}
							
							customervector.add(ce);
							}
							}
						 }

					} 
						catch (IOException e3) 
						{
							e3.printStackTrace();
						}
						int address = customervector.size();
						Object[][] columnData = new Object[address][4];
						for (int i = 0; i < address; i++) 
						{
							columnData[i] = customervector.get(i).getcustomerdetails();
						}

						if (model == null) 
						{
						model = new DefaultTableModel(columnData, columnNames) 
						{
						@Override
						public boolean isCellEditable(int row, int col1) 
						{
						if (col1 < 3)
							return false;
						return true;
						}

						@Override
						public Class getColumnClass(int c)
						{
						try 
						{
							return getValueAt(0, c).getClass();
						} 
						catch (Exception exception) 
						{
							return String.class;
						}
						}
						};
			}
			
						
			else 
			{
				model.setDataVector(columnData, columnNames);
			}
			if (viewsubcustTable == null)
				viewsubcustTable = new JTable(model);
				viewsubcustTable.updateUI();
*/}

public void actionPerformed(ActionEvent e) 
{
	if(e.getSource().equals(butsave))
	{
			SimpleDateFormat sdf =new SimpleDateFormat("yyyy-MM-dd");
			HttpClient client = new DefaultHttpClient();
			HttpPost post = new HttpPost(
					applicationpanel.getBase() + "query/insertcustomer.php");

			try {

				List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(
						1);
				nameValuePairs.add(new BasicNameValuePair("addedit", "-1"));
				nameValuePairs.add(new BasicNameValuePair("txtfname",field_firstname.getText()));
				nameValuePairs.add(new BasicNameValuePair("txtlname",field_lastname.getText()));
				nameValuePairs.add(new BasicNameValuePair("txtdno",field_doorno.getText()));
				nameValuePairs.add(new BasicNameValuePair("txtstreet",field_street.getText()));
				nameValuePairs.add(new BasicNameValuePair("txtlty", field_locality.getText()));
				nameValuePairs.add(new BasicNameValuePair("txtcity",field_city.getText()));
				nameValuePairs.add(new BasicNameValuePair("txtstate",field_state.getText()));
				nameValuePairs.add(new BasicNameValuePair("txtcno",field_contactno.getText()));
				nameValuePairs.add(new BasicNameValuePair("txtemail",field_email.getText()));
				nameValuePairs.add(new BasicNameValuePair("txtfdate",sdf.format(datesubs.getDate())));
				
				post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse response = client.execute(post);
				BufferedReader rd = new BufferedReader(new InputStreamReader(
						response.getEntity().getContent()));

				String line = "";
				
				while ((line = rd.readLine()) != null) 
				{
					System.out.println(line);

				}

				field_customerno.setText("");
				field_firstname.setText("");
				field_lastname.setText("");
				field_doorno.setText("");
				field_locality.setText("");
				field_city.setText("");
				field_state.setText("");
				field_contactno.setText("");
				field_email.setText("");
				field_uname.setText("");
				field_pname.setText("");
				customerloaddata();
									
				custbool =true;

			}
			catch (IOException e3) 
			{
				e3.printStackTrace();
			}
	
		
	}
	
			else if(e.getSource().equals(search))
			{
		
				customersearchloaddata();
				customerloaddata();
				tablepanel1.updateUI();
			}
	
}
	public static void main(String[] args) 
	{
		try
		{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		JFrame frame = new JFrame("Customer Panel");
		frame.add(new customerpanel());
		frame.setSize(650,600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		frame.setLocation((screenSize.width - 800) / 2, (screenSize.height - 475) / 2);
		
		frame.setVisible(true);
		frame.setResizable(false);
	}
	
}


