package com.alethiclogic.jarvis.ui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.MediaTracker;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Properties;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class ApplicationMenuBar extends MenuBar implements ActionListener
{
	private Menu applicationMenu;
	private String burl;
	private String smtph;
	private String smtppo;
	private String smtpun;
	private String smtppass;
	private String defaultfrom;
	private String defaultto;
	private String defaultsubject;
	
	private MenuItem settingsItem = new MenuItem("Settings");
	private MenuItem MailSettings = new MenuItem("MailSettings");
	private MenuItem exitItem = new MenuItem("Exit");
	public ApplicationMenuBar()
	{
		burl=applicationpanel.getBase();
		smtph=applicationpanel.getsmtphost();
		smtppo=applicationpanel.getsmtpport();
		smtpun=applicationpanel.getsmtpusername();
		smtppass=applicationpanel.getpassword();
		defaultfrom=applicationpanel.getdefaultfromaddress();
		defaultto=applicationpanel.getdefaulttoaddress();
		defaultsubject=applicationpanel.getdefaultsubjectline();
		init();
	}
	
	private void init()
	{
		settingsItem.addActionListener(this);
		MailSettings.addActionListener(this);
		exitItem.addActionListener(this);
		applicationMenu = new Menu("Application");
		applicationMenu.add(settingsItem);
		//applicationMenu.add(MailSettings);
		applicationMenu.addSeparator();
		applicationMenu.add(exitItem);
		add(applicationMenu);
	}

	@Override
	public void actionPerformed(ActionEvent e) 
	{
	if(e.getSource().equals(settingsItem))
		{
		
			JPanel configPanel = new JPanel(new GridLayout(8, 2));
			
			configPanel.setPreferredSize(new Dimension(500,300));
			
			JTextField baseUrlField = new JTextField(burl);
			JTextField smtphostField = new JTextField(smtph);
			JTextField smtportField = new JTextField(smtppo);
			JTextField smtpusernameField = new JTextField(smtpun);
			JPasswordField smtppasswordField = new JPasswordField(smtppass);
			JTextField defaultfromaddressField = new JTextField(defaultfrom);
			JTextField defaulttoaddressField = new JTextField(defaultto);
			JTextField defaultsubjectlineField = new JTextField(defaultsubject);
			
			configPanel.add(new JLabel("Base Url"));
			configPanel.add(baseUrlField);
			
			configPanel.add(new JLabel("SMTP Host"));
			configPanel.add(smtphostField);
			
			configPanel.add(new JLabel("SMTP Port"));
			configPanel.add(smtportField);
			
			configPanel.add(new JLabel("SMTP UserName"));
			configPanel.add(smtpusernameField);
			
			configPanel.add(new JLabel("SMTP Password"));
			configPanel.add(smtppasswordField);
			
			configPanel.add(new JLabel("Default From Address"));
			configPanel.add(defaultfromaddressField);
			
			configPanel.add(new JLabel("Default To Address"));
			configPanel.add(defaulttoaddressField);
			
			configPanel.add(new JLabel("Default Subject Line "));
			configPanel.add(defaultsubjectlineField);
			
			
			if (JOptionPane.showConfirmDialog(null, configPanel, "Configuarion", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION)
			{
				 burl = baseUrlField.getText();
				 smtph =smtphostField.getText();
				 smtppo =smtportField.getText();
				 smtpun =smtpusernameField.getText();
				 smtppass =smtppasswordField.getText();
				 defaultfrom =defaultfromaddressField.getText();
				 defaultto =defaulttoaddressField.getText();
				 defaultsubject =defaultsubjectlineField.getText();
				 
				 
			}

			if (burl == null || burl.replaceAll(" ", "").isEmpty() )
			{
				JOptionPane
						.showMessageDialog(null,
								"Unable to open application. Please contact adminsitrator");
				System.exit(0);
			}
			
			if(smtph == null || smtph .replaceAll(" ", "").isEmpty() )
			{
				JOptionPane.showMessageDialog(null,"pls enter the smtphost");
			}
			
			
			File file = new File("Jarvis.props");
			Properties properties = new Properties();
			try
			{
				FileOutputStream fileOutputStream = new FileOutputStream(file);
				properties.put("base", burl);
				properties.put("Smtphost", smtph);
				properties.put("Smtpport", smtppo);
				properties.put("Smtpusername", smtpun);
				properties.put("Smtppassword",smtppass);
				properties.put("Defaultformaddress",defaultfrom);
				properties.put("Defaulttoaddress", defaultto);
				properties.put("Defaultsubjectline", defaultsubject);
				properties.save(fileOutputStream, "Jarvis Properties");
				
				fileOutputStream.close();
			}
			catch (Exception exception)
			{
				JOptionPane.showMessageDialog(null, "<HTML><BODY>There has been an error saving the settings.<br>Please try again later.<br>or Contact administrator</BODY></HTML>");
				exception.printStackTrace();
			}
		}

		if(e.getSource().equals(MailSettings))
		{
		new EmailSettingdialog();
		
		}
		
		else if(e.getSource().equals(exitItem))
		{
			if (JOptionPane.showConfirmDialog(null,
					"Do you wish to exit the application?",
					"Exit Application", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
			{
				System.exit(0);
			}	
		}
	}
	
}
