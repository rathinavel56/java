package mainClassPack;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class InitProps {
	public static  String image_store_path;
	public static File file = new File("Designer.props");
	public static void Getnewprops(){
		Properties properties = new Properties();
		try
		{
			properties.load(new FileInputStream(file));
			image_store_path = properties.getProperty("folder_path");
			if (image_store_path == null) {
				Getallprops();
			}
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
		}
	}
	public static void Getallprops() throws FileNotFoundException, IOException{
		JPanel basePanel = new JPanel(new GridLayout(1,2));
		basePanel.setPreferredSize(new Dimension(200,50));
		JTextField imagepathfield = new JTextField();
		imagepathfield.setPreferredSize(new Dimension(10,10));
		basePanel.add(new JLabel("Image Store Path"));
		basePanel.add(imagepathfield);
		Properties properties = new Properties();
		if(file.exists()){
			properties.load(new FileInputStream(file));
			image_store_path = properties.getProperty("folder_path");
			imagepathfield.setText(image_store_path);
		}
		if (JOptionPane.showConfirmDialog(null, basePanel, "Image Path Like: eg:D", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
			image_store_path = imagepathfield.getText();
		}
		if (image_store_path == null || image_store_path.replaceAll(" ", "").isEmpty()) {
			JOptionPane.showMessageDialog(null,"Unable to open application. Please contact administrator");
			System.exit(0);
		}
		try {
			FileOutputStream fileOutputStream = new FileOutputStream(file);
			properties.put("folder_path", image_store_path);
			properties.save(fileOutputStream, "Designer.props");
			fileOutputStream.close();
		} catch (Exception exception) {
			JOptionPane.showMessageDialog(null, "Unable to open application. Please contact administrator");
			exception.printStackTrace();
		}
	}
	public static String GetallpropsDeatils() throws FileNotFoundException, IOException{
		Properties properties = new Properties();
		if(file.exists()){
			properties.load(new FileInputStream(file));
			image_store_path = properties.getProperty("folder_path");
		} else {
			image_store_path ="E";
		}
		return image_store_path;
	}
}