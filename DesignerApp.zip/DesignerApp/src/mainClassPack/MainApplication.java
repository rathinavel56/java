package mainClassPack;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;

public class MainApplication {
	public static JButton colorbtn = new JButton("Choose color");
	public static JButton fullsrcbtn = new JButton("Full Screen");
	public static JButton pariallysrcbtn = new JButton("Partial Screen");
	public static JButton dragsrcbtn = new JButton("Drag Screen");
	public static JButton rulerbtn = new JButton("Ruler");
	public static JButton Settingbtn = new JButton("Settings");
	final static JFrame frame = new JFrame("Designer App");
	public static void main(String[] args) {
		frame.setSize(350,100);
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		frame.setLocation(screenSize.width/2, screenSize.width/2-screenSize.height/40);
		frame.setVisible(true);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new FlowLayout());
//		colorbtn.setSize(150,50);
//		frame.getContentPane().add(colorbtn);
		
		//Full Screen btn
		fullsrcbtn.setSize(150,50);
		frame.getContentPane().add(fullsrcbtn);
		
		//Partial Screen btn
		pariallysrcbtn.setSize(150,50);
		frame.getContentPane().add(pariallysrcbtn);
		
		//Partial Screen btn
		dragsrcbtn.setSize(150,50);
		frame.getContentPane().add(dragsrcbtn);
		
		//Ruler Screen btn
		rulerbtn.setSize(150,50);
		frame.getContentPane().add(rulerbtn);
		
		//Settings Screen btn
		Settingbtn.setSize(150,50);
		frame.getContentPane().add(Settingbtn);
		
		colorbtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ColorPicker getcolorpicker = new ColorPicker();
				Color colorchoose = getcolorpicker.getColorpicker();
				System.out.println(colorchoose);
			}
		});
		fullsrcbtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				frame.setState(Frame.ICONIFIED);
				GenerateScreenShot getPariallyScreen = new GenerateScreenShot();
				getPariallyScreen.FullScreenCapture();
				frame.setState(Frame.NORMAL);
			}
		});
		pariallysrcbtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				frame.setState(Frame.ICONIFIED);
				GenerateScreenShot getPariallyScreen = new GenerateScreenShot();
				getPariallyScreen.PartialScreenCapture();
				frame.setState(Frame.NORMAL);
			}
		});
		dragsrcbtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				frame.setState(Frame.ICONIFIED);
				frame.setVisible(false);
				GenerateScreenShot getDragScreen = new GenerateScreenShot();
				getDragScreen.dragScreenCapture("capture_mode");
				frame.setState(Frame.NORMAL);
				frame.setVisible(true);
			}
		});
		rulerbtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				frame.setState(Frame.ICONIFIED);
				frame.setVisible(false);
				GenerateScreenShot getDragScreen = new GenerateScreenShot();
				getDragScreen.dragScreenCapture("ruler_mode");
				frame.setState(Frame.NORMAL);
				frame.setVisible(true);
			}
		});
		Settingbtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					InitProps.Getallprops();
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
	}
}