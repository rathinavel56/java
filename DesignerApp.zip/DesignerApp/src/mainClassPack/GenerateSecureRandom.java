package mainClassPack;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Collections;

public class GenerateSecureRandom {
	public static SecureRandom random = new SecureRandom();
	
	public String GetSecurityToken() {
		String security_string = new BigInteger(130, random).toString(32);
		return security_string;
	}
	public String GetshuffleString() {
		String[] alphaString = new String[]{"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"};
		Collections.shuffle(Arrays.asList(alphaString));
		String randomString = String.join("", alphaString);
		return randomString;
	}
}
