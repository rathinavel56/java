package mainClassPack;

import java.awt.AWTException;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class GenerateScreenShot {

	//FullScreenCapture
	public String FullScreenCapture() {
		try {
			Robot robot = new Robot(); 
			String format = "jpg";
			Rectangle screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
			BufferedImage screenFullImage = robot.createScreenCapture(screenRect);
			GenerateSecureRandom getTokenString = new GenerateSecureRandom();
			String fileName = getTokenString.GetshuffleString()+"."+format;
			String foldername = InitProps.GetallpropsDeatils();
			ImageIO.write(screenFullImage, format, new File(foldername+"://"+fileName));
			return "wite";
		} catch (AWTException | IOException ex) {
			System.err.println(ex);
			return "wite no";
		}
	}
	
	//PartialScreenCapture
	public String PartialScreenCapture() {
		try {
			Robot robot = new Robot(); 
			String format = "jpg";
			Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
			Rectangle captureRect = new Rectangle(0, 0, screenSize.width / 2, screenSize.height / 2);
			BufferedImage screenFullImage = robot.createScreenCapture(captureRect);
			GenerateSecureRandom getTokenString = new GenerateSecureRandom();
			String fileName = getTokenString.GetshuffleString()+"."+format;
			String foldername = InitProps.GetallpropsDeatils();
			ImageIO.write(screenFullImage, format,new File(foldername+"://"+fileName));
			return "wite";
		} catch (AWTException | IOException ex) {
			System.err.println(ex);
			return "wite no";
		}
	}
	
	//PartialScreenCapture
		public String dragScreenCapture(String modechk) {
			DragSelectArea getDragSelectArea = new DragSelectArea();
			return getDragSelectArea.DrayAreaSelect(modechk);
		}

}
