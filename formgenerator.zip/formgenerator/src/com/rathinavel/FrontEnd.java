/**
* @package		Form Generator
* @author 		K.V.Rathinavel Subramani
* @since 		2016.12.04 08.00.00
*/
package com.rathinavel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JComboBox;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;

public class FrontEnd extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * Labels
	 */
	JLabel  databaseTypeLabel     = AppConstant.createLabel(AppConstant.databaseTypeLabel, 12, AppConstant.white);
	JLabel  databaseLabel         = AppConstant.createLabel(AppConstant.databaseLabel, 12, AppConstant.white);
	JLabel  tableLabel            = AppConstant.createLabel(AppConstant.tableLabel, 12, AppConstant.white);
	JLabel  backendType           = AppConstant.createLabel(AppConstant.backendType, 12, AppConstant.white);
	JLabel  frontEndType           = AppConstant.createLabel(AppConstant.frontType, 12, AppConstant.white);
	JLabel  singelLabel           = AppConstant.createLabel(AppConstant.singelLabel, 12, AppConstant.white);
	JLabel  mutipleLabel          = AppConstant.createLabel(AppConstant.mutipleLabel, 12, AppConstant.white);
	JLabel  loginLabel            = AppConstant.createLabel(AppConstant.loginLabel, 12, AppConstant.white);
	JLabel  pluginLabel           = AppConstant.createLabel(AppConstant.pluginLabel, 12, AppConstant.white);
	JLabel  favaoriteLabel        = AppConstant.createLabel(AppConstant.favaoriteLabel, 12, AppConstant.white);
	JLabel  reviewLabel           = AppConstant.createLabel(AppConstant.reviewLabel, 12, AppConstant.white);
	JLabel  likeLabel             = AppConstant.createLabel(AppConstant.likeLabel, 12, AppConstant.white);
	JLabel  frontLabel            = AppConstant.createLabel(AppConstant.frontLabel, 12, AppConstant.white);
	JLabel  backLabel             = AppConstant.createLabel(AppConstant.backLabel, 12, AppConstant.white);
	JLabel  adminLabel            = AppConstant.createLabel(AppConstant.adminLabel, 12, AppConstant.white);
	JLabel  foreignLabel          = AppConstant.createLabel(AppConstant.foreignLabel, 12, AppConstant.white);
	JLabel  labelEmpty			  = AppConstant.createLabel("", 12, AppConstant.white);
	JButton generateButton        = AppConstant.createButton(AppConstant.generateButton, 12, AppConstant.black);
	
	/**
	 * Panel
	 */
	JPanel mainpanel             = new JPanel(new BorderLayout());
	JPanel northpanel            = new JPanel(new BorderLayout());
	JTabbedPane jTabbedPane      = new JTabbedPane();
	
	
	/**
	 * ComboBox
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	JComboBox databaseTypCombo   = new JComboBox(AppConstant.defaultDatabase);
	@SuppressWarnings("rawtypes")
	JComboBox databaseCombo      = new JComboBox();
	@SuppressWarnings({ "rawtypes", "unchecked" })
	JComboBox tablecombo         = new JComboBox(AppConstant.defaultObj);
	@SuppressWarnings({ "rawtypes", "unchecked" })
	JComboBox frontEndcombo      = new JComboBox(AppConstant.frontEndComobo);
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	JComboBox backcombo         = new JComboBox(AppConstant.backObj);
	
	/**
	 * Check box
	 */
	JCheckBox singelChk          = new JCheckBox();
	JCheckBox mutipleChk         = new JCheckBox();
	JCheckBox pluginChk          = new JCheckBox();
	JCheckBox favoriteChk        = new JCheckBox();
	JCheckBox reviewChk          = new JCheckBox();
	JCheckBox likeChk            = new JCheckBox();
	JCheckBox frontChk           = new JCheckBox();
	JCheckBox adminChk           = new JCheckBox();
	JCheckBox foreignChk         = new JCheckBox();
	JCheckBox backChk            = new JCheckBox();
	JCheckBox loginChk           = new JCheckBox();
	
	/**
	 * TextArea
	 */
	JTextArea display            = new JTextArea (250, 250);
	
	/**
	 * ScrollPane
	 */
	JScrollPane scroll           = new JScrollPane(display);
	
	JMenuBar menubar             = new JMenuBar();
	JMenu fileMenu               = new JMenu(AppConstant.file);
	JMenuItem newMenuItem        = new JMenuItem(AppConstant.databaseCon);
	JMenuItem newMenuInnerItem   = new JMenuItem(AppConstant.mysql);
	
	/**
	 * Panel
	 */
	JPanel mainPanel                            = new JPanel(new BorderLayout());
	JPanel tablepanel                           = new JPanel(new GridLayout());
	DefaultTableModel previewScreenDisplay      = new DefaultTableModel(AppConstant.columnData, AppConstant.previewScreen);
	JTable previewTextArea                      = new JTable(previewScreenDisplay);	
	
	public FrontEnd() {
		 
		//ServiceBackEnd get_tables                = new ServiceBackEnd();
		//DefaultComboBoxModel getDatabseTableList = get_tables.getAllDatabaseTables();
		JPanel northtabpanel                     = new JPanel(new BorderLayout());
		JPanel northWestPanelLeft                = new JPanel();
		JPanel northWestPanelRight               = new JPanel();

		JPanel south                             = new JPanel();
		JPanel southtextpanel                    = new JPanel(new BorderLayout());
		JPanel center                            = new JPanel(new BorderLayout());

		Component box_01 = Box.createRigidArea(new Dimension(5, 5));
		Box box_11 = Box.createHorizontalBox();
		
		Component box_21 = Box.createRigidArea(new Dimension(5, 5));
		Box box_31 = Box.createHorizontalBox();
		
		Component box_41 = Box.createRigidArea(new Dimension(5, 5));
		Component box_4a1 = Box.createRigidArea(new Dimension(5, 5));
		Box box_51 = Box.createHorizontalBox();
		
		Component box_6a1 = Box.createRigidArea(new Dimension(5, 5));
		Box box_61 = Box.createHorizontalBox();
		
		Box box_6c1 = Box.createHorizontalBox();
		
		Box box_71 = Box.createHorizontalBox();
		
		Component box_81 = Box.createRigidArea(new Dimension(5, 5));
		Box box_91 = Box.createHorizontalBox();
		
		Component box_101 = Box.createRigidArea(new Dimension(5, 5));
		Box box_111 = Box.createHorizontalBox();
		
		Component box_121 = Box.createRigidArea(new Dimension(5, 5));
		Box box_131 = Box.createHorizontalBox();
		
		Component box_141 = Box.createRigidArea(new Dimension(5, 5));
		Box box_151 = Box.createHorizontalBox();
		
		Component box_161 = Box.createRigidArea(new Dimension(5, 5));
		Box box_171 = Box.createHorizontalBox();
		
		Component box_002 = Box.createRigidArea(new Dimension(5, 5));
		Box box_0012 = Box.createHorizontalBox();
		
		Component box_02 = Box.createRigidArea(new Dimension(5, 5));
		Box box_12 = Box.createHorizontalBox();
		
		Component box_22 = Box.createRigidArea(new Dimension(5, 5));
		Box box_32 = Box.createHorizontalBox();
		
		Component box_42 = Box.createRigidArea(new Dimension(5, 5));
		Box box_52 = Box.createHorizontalBox();
		
		Component box_62 = Box.createRigidArea(new Dimension(5, 5));
		Box box_72 = Box.createHorizontalBox();
		
		Component box_82 = Box.createRigidArea(new Dimension(5, 5));
		Box box_92 = Box.createHorizontalBox();
		
		Component box_102 = Box.createRigidArea(new Dimension(5, 5));
		Box box_112 = Box.createHorizontalBox();
		
		Component box_122 = Box.createRigidArea(new Dimension(5, 5));
		Box box_132 = Box.createHorizontalBox();
		
		Component box_142 = Box.createRigidArea(new Dimension(5, 5));
		Box box_152 = Box.createHorizontalBox();
		
		Component box_162 = Box.createRigidArea(new Dimension(5, 5));
		Box box_172 = Box.createHorizontalBox();
		
		
		JPanel pBox01 = AppConstant.createPBoxComo(databaseTypeLabel, databaseTypCombo);
		box_11.add(Box.createRigidArea(new Dimension(20, 0)));
		box_11.add(pBox01);
		
		JPanel pBox31 = AppConstant.createPBoxComo(databaseLabel, databaseCombo);
		box_31.add(Box.createRigidArea(new Dimension(20, 0)));
		box_31.add(pBox31);
		
		JPanel pBox51 = AppConstant.createPBoxComo(tableLabel, tablecombo);
		box_51.add(Box.createRigidArea(new Dimension(20, 0)));
		box_51.add(pBox51);
		
		JPanel pBox61 = AppConstant.createPBoxComo(frontEndType, frontEndcombo);
		box_61.add(Box.createRigidArea(new Dimension(20, 0)));
		box_61.add(pBox61);
		
		JPanel pBox61a = AppConstant.createPBoxComo(backendType, backcombo);
		box_6c1.add(Box.createRigidArea(new Dimension(20, 0)));
		box_6c1.add(pBox61a);
		
		JPanel pBox71 = AppConstant.createPCheckBox(singelLabel, singelChk);
		box_71.add(Box.createRigidArea(new Dimension(20, 0)));
		box_71.add(pBox71);
		
		JPanel pBox91 = AppConstant.createPCheckBox(singelLabel, singelChk);
		box_91.add(Box.createRigidArea(new Dimension(20, 0)));
		box_91.add(pBox91);
		
		JPanel pBox111 = AppConstant.createPCheckBox(mutipleLabel, mutipleChk);
		box_111.add(Box.createRigidArea(new Dimension(20, 0)));
		box_111.add(pBox111);
		
		JPanel pBox113 = AppConstant.createPCheckBox(loginLabel, loginChk);
		box_131.add(Box.createRigidArea(new Dimension(20, 0)));
		box_131.add(pBox113);
		
		
		JPanel pBox002 = AppConstant.createPCheckBox(foreignLabel, foreignChk);
		box_0012.add(Box.createRigidArea(new Dimension(20, 0)));
		box_0012.add(pBox002);
		
		JPanel pBox02 = AppConstant.createPCheckBox(likeLabel, likeChk);
		box_12.add(Box.createRigidArea(new Dimension(20, 0)));
		box_12.add(pBox02);
		
		JPanel pBox32 = AppConstant.createPCheckBox(favaoriteLabel, favoriteChk);
		box_32.add(Box.createRigidArea(new Dimension(20, 0)));
		box_32.add(pBox32);
		
		JPanel pBox52 = AppConstant.createPCheckBox(reviewLabel, reviewChk);
		box_52.add(Box.createRigidArea(new Dimension(20, 0)));
		box_52.add(pBox52);
		
		JPanel pBox72 = AppConstant.createPCheckBox(pluginLabel, pluginChk);
		box_72.add(Box.createRigidArea(new Dimension(20, 0)));
		box_72.add(pBox72);
		
		JPanel pBox92 = AppConstant.createPCheckBox(adminLabel, adminChk);
		box_92.add(Box.createRigidArea(new Dimension(20, 0)));
		box_92.add(pBox92);
		
		JPanel pBox112 = AppConstant.createPCheckBox(frontLabel, frontChk);
		box_112.add(Box.createRigidArea(new Dimension(20, 0)));
		box_112.add(pBox112);
	
		JPanel pBox132 = AppConstant.createPCheckBox(backLabel, backChk);
		box_132.add(Box.createRigidArea(new Dimension(20, 0)));
		box_132.add(pBox132);
		
		JPanel pBox152 = AppConstant.createPButtonBox(labelEmpty, generateButton);
		box_152.add(Box.createRigidArea(new Dimension(20, 0)));
		box_152.add(pBox152);
		
		northWestPanelLeft.add(box_01);
		northWestPanelLeft.add(box_11);
		northWestPanelLeft.add(box_21);
		northWestPanelLeft.add(box_31);
		northWestPanelLeft.add(box_41);
		northWestPanelLeft.add(box_51);
		northWestPanelLeft.add(box_4a1);
		northWestPanelLeft.add(box_61);
		northWestPanelLeft.add(box_6a1);
		northWestPanelLeft.add(box_6c1);
		northWestPanelLeft.add(box_71);
		northWestPanelLeft.add(box_81);
		northWestPanelLeft.add(box_91);
		northWestPanelLeft.add(box_101);
		northWestPanelLeft.add(box_111);
		northWestPanelLeft.add(box_121);
		northWestPanelLeft.add(box_131);
		northWestPanelLeft.add(box_141);
		northWestPanelLeft.add(box_151);
		northWestPanelLeft.add(box_161);
		northWestPanelLeft.add(box_171);
		
		northWestPanelRight.add(box_002);
		northWestPanelRight.add(box_0012);
		northWestPanelRight.add(box_02);
		northWestPanelRight.add(box_12);
		northWestPanelRight.add(box_22);
		northWestPanelRight.add(box_32);
		northWestPanelRight.add(box_42);
		northWestPanelRight.add(box_52);
		northWestPanelRight.add(box_62);
		northWestPanelRight.add(box_72);
		northWestPanelRight.add(box_82);
		northWestPanelRight.add(box_92);
		northWestPanelRight.add(box_102);
		northWestPanelRight.add(box_112);
		northWestPanelRight.add(box_122);
		northWestPanelRight.add(box_132);
		northWestPanelRight.add(box_142);
		northWestPanelRight.add(box_152);
		northWestPanelRight.add(box_162);
		northWestPanelRight.add(box_172);

		AppConstant.UiDecorate(south, Color.DARK_GRAY);
		AppConstant.UiDecorate(center, Color.DARK_GRAY);
		AppConstant.UiDecorate(northtabpanel, Color.DARK_GRAY);
		AppConstant.UiDecorate(northWestPanelLeft, Color.DARK_GRAY);
		AppConstant.UiDecorate(northWestPanelRight, Color.DARK_GRAY);
		AppConstant.UiDecorate(northtabpanel, Color.DARK_GRAY);
		AppConstant.UiDecorate(southtextpanel, Color.DARK_GRAY);
		AppConstant.UiDecorate(mainPanel, Color.DARK_GRAY);
		
		south.setPreferredSize(new Dimension(650,305));
		southtextpanel.setPreferredSize(new Dimension(620,40));
		center.setPreferredSize(new Dimension(620,265));
		

		southtextpanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		center.setBorder(BorderFactory.createRaisedBevelBorder());

		northWestPanelLeft.setLayout(new BoxLayout(northWestPanelLeft, BoxLayout.PAGE_AXIS));
		northWestPanelRight.setLayout(new BoxLayout(northWestPanelRight, BoxLayout.PAGE_AXIS));
		tablepanel.add(new JScrollPane(previewTextArea));
		center.add(tablepanel, BorderLayout.CENTER);
		south.add(southtextpanel,BorderLayout.NORTH);
		south.add(center,BorderLayout.CENTER);

		tablepanel.updateUI();

		northtabpanel.add(northWestPanelLeft,BorderLayout.WEST);
		northtabpanel.add(northWestPanelRight,BorderLayout.CENTER);
		northtabpanel.add(south,BorderLayout.SOUTH);
		
		mainPanel.add(northtabpanel);
		mainPanel.setSize(new Dimension(640,545));
		mainPanel.setPreferredSize(new Dimension(640,545));
		add(mainPanel);
		
		/**
		 * ActionListener
		*/
		databaseTypCombo.addActionListener (new ActionListener () {
			@SuppressWarnings({ "unchecked", "rawtypes" })
			public void actionPerformed(ActionEvent e) {
				JComboBox combo             = (JComboBox)e.getSource();
				AppConstant.selectDbtype    = (String)combo.getSelectedItem();
				ResultSet getDbList         = ServiceBackEnd.getAllDatabaseTables();
				databaseCombo.removeAllItems();
				tablecombo.removeAllItems();
        		tablecombo.addItem(AppConstant.defaultAll);
        		try {
        			if (AppConstant.selectDbtype.equals(AppConstant.mysql)) {
	        			if (getDbList.next()) {
	        				while (getDbList.next()) {
	        					databaseCombo.addItem(getDbList.getString("databases"));
							}
	        			} else {
	        				JOptionPane.showMessageDialog(null, "No Databases");
	        			}
        			} else if (AppConstant.selectDbtype.equals(AppConstant.postgres)) {
        				while (getDbList.next()) {
        					databaseCombo.addItem(getDbList.getString("databases"));
						}
        			}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
            }
		});
		databaseCombo.addActionListener (new ActionListener () {
		    @SuppressWarnings({ "rawtypes", "unchecked" })
			public void actionPerformed(ActionEvent e) {
                JComboBox combo             = (JComboBox)e.getSource();
                String dbName               = (String)combo.getSelectedItem();
                tablecombo.removeAllItems();
        		tablecombo.addItem(AppConstant.defaultAll);
                ServiceBackEnd get_tables   = new ServiceBackEnd();
                ResultSet getTableList      = get_tables.getSelectTables(dbName);
        		try {
        			while (getTableList.next()) {
						tablecombo.addItem(getTableList.getString("table_name"));
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
            }
		});
		
		singelChk.addActionListener (new ActionListener () {
		    public void actionPerformed(ActionEvent e) {
		    	if(singelChk.isSelected()){
		    		mutipleChk.setSelected(false);
	            }
            }
		});
		
		mutipleChk.addActionListener (new ActionListener () {
		    public void actionPerformed(ActionEvent e) {
		    	if(mutipleChk.isSelected()){
		    		singelChk.setSelected(false);
	            }
            }
		});
		
		generateButton.addActionListener (new ActionListener () {
		    public void actionPerformed(ActionEvent e) {
		    	AppConstant.angularFormat   = frontEndcombo.getSelectedItem().toString();
				ServiceBackEnd.generateCode(databaseCombo.getSelectedItem()
						.toString(), tablecombo.getSelectedItem().toString());
		    	/*display.setText("");*/
            }
		});
	}
	/*@SuppressWarnings({ "unchecked", "rawtypes" })
	public void placeComponents(JPanel panel) {
	
		ServiceBackEnd get_tables = new ServiceBackEnd();
		DefaultComboBoxModel getDatabseTableList = get_tables.getAllDatabaseTables();
		panel.setLayout(null);
		
		fileMenu.add(newMenuItem);
		newMenuItem.add(newMenuInnerItem);
		
		menubar.add(fileMenu);
		menubar.setBounds(5, xAxisIncrease, 550, 25);
		panel.add(menubar);
		
		xAxisIncrease = xAxisIncrease+40;
		databaseTypeLabel.setBounds(30, xAxisIncrease, 150, 25);
		panel.add(databaseTypeLabel);
	
		databaseCombo = new JComboBox(AppConstant.defaultDatabase);
		databaseCombo.setBounds(320, xAxisIncrease, 160, 25);
		panel.add(databaseCombo);
		
		xAxisIncrease = xAxisIncrease+40;
		databaseLabel.setBounds(30, xAxisIncrease, 150, 25);
		panel.add(databaseLabel);
	
		databaseCombo = new JComboBox(getDatabseTableList);
		databaseCombo.setBounds(320, xAxisIncrease, 160, 25);
		panel.add(databaseCombo);
	
		tableLabel.setBounds(30, xAxisIncrease, 150, 25);
		panel.add(tableLabel);
	
		tablecombo.setBounds(320, xAxisIncrease, 160, 25);
		panel.add(tablecombo);
		
		xAxisIncrease = xAxisIncrease+40;
		tableLabel.setBounds(30, xAxisIncrease, 150, 25);
		panel.add(tableLabel);
		
		tablecombo.setBounds(320, xAxisIncrease, 160, 25);
		panel.add(tablecombo);
		
		xAxisIncrease = xAxisIncrease+40;
		loginLabel.setBounds(30, xAxisIncrease, 160, 25);
		panel.add(loginLabel);
	
		xAxisIncrease = xAxisIncrease+40;
		singelLabel.setBounds(30, xAxisIncrease, 160, 25);
		panel.add(singelLabel);
	
		singelChk.setBounds(375, xAxisIncrease, 160, 25);
		panel.add(singelChk);
		
		xAxisIncrease = xAxisIncrease+40;
		pluginLabel.setBounds(30, xAxisIncrease, 160, 25);
		panel.add(pluginLabel);
	
		pluginChk.setBounds(375, xAxisIncrease, 160, 25);
		panel.add(pluginChk);
		
		xAxisIncrease = xAxisIncrease+40;
		favaoriteLabel.setBounds(30, xAxisIncrease, 160, 25);
		panel.add(favaoriteLabel);
	
		favoriteChk.setBounds(375, xAxisIncrease, 160, 25);
		panel.add(favoriteChk);
		
		xAxisIncrease = xAxisIncrease+40;
		reviewLabel.setBounds(30, xAxisIncrease, 160, 25);
		panel.add(reviewLabel);
	
		reviewChk.setBounds(375, xAxisIncrease, 160, 25);
		panel.add(reviewChk);
		
		xAxisIncrease = xAxisIncrease+40;
		likeLabel.setBounds(30, xAxisIncrease, 160, 25);
		panel.add(likeLabel);
	
		likeChk.setBounds(375, xAxisIncrease, 160, 25);
		panel.add(likeChk);
		
		xAxisIncrease = xAxisIncrease+40;
		mutipleLabel.setBounds(30, xAxisIncrease, 160, 25);
		panel.add(mutipleLabel);
	
		mutipleChk.setBounds(375, xAxisIncrease, 160, 25);
		panel.add(mutipleChk);
		
		xAxisIncrease = xAxisIncrease+40;
		singelLabel.setBounds(30, xAxisIncrease, 160, 25);
		panel.add(singelLabel);
	
		frontChk.setBounds(375, xAxisIncrease, 160, 25);
		panel.add(frontChk);
		
		xAxisIncrease = xAxisIncrease+40;
		frontLabel.setBounds(30, xAxisIncrease, 160, 25);
		panel.add(frontLabel);
		
		xAxisIncrease = xAxisIncrease+40;
		loginLabel.setBounds(30, xAxisIncrease, 160, 25);
		panel.add(loginLabel);
	
		loginChk.setSelected(true);
		loginChk.setBounds(375, xAxisIncrease, 160, 25);
		panel.add(loginChk);
	
		frontChk.setSelected(true);
		frontChk.setBounds(375, xAxisIncrease, 160, 25);
		panel.add(frontChk);
		
		xAxisIncrease = xAxisIncrease+40;
		backLabel.setBounds(30, xAxisIncrease, 160, 25);
		panel.add(backLabel);
	
		backChk.setSelected(true);
		backChk.setBounds(375, xAxisIncrease, 160, 25);
		panel.add(backChk);
		
		xAxisIncrease = xAxisIncrease+40;
		adminLabel.setBounds(30, xAxisIncrease, 160, 25);
		panel.add(adminLabel);
	
		adminChk.setSelected(true);
		adminChk.setBounds(375, xAxisIncrease, 160, 25);
		panel.add(adminChk);
		
		xAxisIncrease = xAxisIncrease+40;
		foreignLabel.setBounds(30, xAxisIncrease, 150, 25);
		panel.add(foreignLabel);
	
		foreignChk.setSelected(true);
		foreignChk.setBounds(375, xAxisIncrease, 160, 25);
		panel.add(foreignChk);
		
		xAxisIncrease = xAxisIncrease+40;
		generateButton.setBounds(325, xAxisIncrease, 125, 25);
		panel.add(generateButton);
		
		xAxisIncrease = xAxisIncrease+40;
		display.setEditable(true);
		scroll.setVerticalScrollBarPolicy (ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scroll.setBounds(20, xAxisIncrease, 500, 230);
		panel.add(scroll);
		
		
	}*/
}