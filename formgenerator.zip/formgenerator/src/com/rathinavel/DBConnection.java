/**
* @package		Form Generator
* @author 		K.V.Rathinavel Subramani
* @since 		2016.12.04 08.00.00
*/
package com.rathinavel;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	private Connection mysqlDbcon    = null;
	private Connection postgresDbcon = null;
	private static DBConnection single;
	private String mysqlHost         = AppConstant.mysqlHost;
	private String mysqlUsername     = AppConstant.mysqlUsername;
	private String mysqlPassword     = AppConstant.mysqlPassword; 
	private String mysqlPort         = AppConstant.mysqlPort;
	//private String mysqlDbName       = AppConstant.mysqlDB;
	private String postgresHost      = AppConstant.postgresHost;
	private String postgresUsername  = AppConstant.postgresUsername;
	private String postgresPassword  = AppConstant.postgresPassword; 
	private String postgresPort      = AppConstant.postgresPort;
	//private String postgresDbName    = "postgres";
	
	public static DBConnection getSingleton() {
		if(single!=null)
			return single;
		single = new DBConnection();
		return single;	
	}

	public DBConnection() {
		try {
			if(mysqlDbcon != null && mysqlDbcon.isClosed())
			       mysqlDbcon = getMysqlDBconnect();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		try {
			if (postgresDbcon == null || postgresDbcon.isClosed())
				postgresDbcon = getPostgresDBconnect();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public Connection getMysqlDBconnect() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			mysqlDbcon = DriverManager.getConnection("jdbc:mysql://" + mysqlHost + ":" + mysqlPort, mysqlUsername, mysqlPassword);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return mysqlDbcon;
	}
	
	public Connection getPostgresDBconnect() {
		try {
			Class.forName("org.postgresql.Driver");
			postgresDbcon = DriverManager.getConnection("jdbc:postgresql://" + postgresHost + ":" + postgresPort
					+ "/"+AppConstant.postgresDbName, postgresUsername, postgresPassword);
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return postgresDbcon;
	}
	
	public void dbclose() {
		try {
			mysqlDbcon.close();
			postgresDbcon.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}