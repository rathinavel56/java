/**
* @package		Form Generator
* @author 		K.V.Rathinavel Subramani
* @since 		2016.12.04 08.00.00
*/
package com.rathinavel;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class SettingPanel {
	public static File file;
	public static void main(String[] args) {
		System.out.println("1-------");
		initProps();
	}
	public static void initProps() {
		System.out.println("2-------");
		file = new File("FormGenerator.props");
		if (!file.exists()) {
			initProps();
		} else {
			AppConstant.setProps(file);
			if (AppConstant.mysqlConnect == null || AppConstant.postgresConnect == null) {
				initProps();
			}
		}
		JPanel basePanel = new JPanel(new GridLayout(19,2));
		basePanel.setPreferredSize(new Dimension(600,400));
		
		basePanel.add(new JLabel(AppConstant.mysqlHostLabel));
		AppConstant.mysqlHostText.setText(AppConstant.mysqlHost);
		basePanel.add(AppConstant.mysqlHostText);
		
		basePanel.add(new JLabel(AppConstant.mysqlUsernameLabel));
		AppConstant.mysqlUsernameText.setText(AppConstant.mysqlUsername);
		basePanel.add(AppConstant.mysqlUsernameText);
		
		basePanel.add(new JLabel(AppConstant.mysqlPasswordLabel));
		AppConstant.mysqlPasswordText.setText(AppConstant.mysqlPassword);
		basePanel.add(AppConstant.mysqlPasswordText);
		
		basePanel.add(new JLabel(AppConstant.mysqlPortLabel));
		AppConstant.mysqlPortText.setText(AppConstant.mysqlPort);
		basePanel.add(AppConstant.mysqlPortText);
		
		basePanel.add(new JLabel(AppConstant.postgresHostLabel));
		AppConstant.postgresHostText.setText(AppConstant.postgresHost);
		basePanel.add(AppConstant.postgresHostText);
		
		basePanel.add(new JLabel(AppConstant.postgresUsernameLabel));
		AppConstant.postgresUsernameText.setText(AppConstant.postgresUsername);
		basePanel.add(AppConstant.postgresUsernameText);
		
		basePanel.add(new JLabel(AppConstant.postgresPasswordLabel));
		AppConstant.postgresPasswordText.setText(AppConstant.postgresPassword);
		basePanel.add(AppConstant.postgresPasswordText);
		
		basePanel.add(new JLabel(AppConstant.postgresPortLabel));
		AppConstant.postgresPortText.setText(AppConstant.postgresPort);
		basePanel.add(AppConstant.postgresPortText);
		
		basePanel.add(new JLabel(AppConstant.copyRightLabel));
		AppConstant.copyRightText.setText(AppConstant.copyRight);
		basePanel.add(AppConstant.copyRightText);
		
		basePanel.add(new JLabel(AppConstant.licenseLabel));
		AppConstant.licenseText.setText(AppConstant.license);
		basePanel.add(AppConstant.licenseText);
		
		basePanel.add(new JLabel(AppConstant.loginLabel));
		basePanel.add(AppConstant.loginChkBox);
		
		basePanel.add(new JLabel(AppConstant.foreignLabel));
		basePanel.add(AppConstant.foreignChkBox);
		
		basePanel.add(new JLabel(AppConstant.likeLabel));
		basePanel.add(AppConstant.likeChkBox);
		
		basePanel.add(new JLabel(AppConstant.favaoriteLabel));
		basePanel.add(AppConstant.favaoriteChkBox);
		
		basePanel.add(new JLabel(AppConstant.reviewLabel));
		basePanel.add(AppConstant.reviewChkBox);
		
		basePanel.add(new JLabel(AppConstant.adminLabel));
		basePanel.add(AppConstant.adminChkBox);
		
		basePanel.add(new JLabel(AppConstant.frontLabel));
		basePanel.add(AppConstant.frontChkBox);
		
		basePanel.add(new JLabel(AppConstant.backLabel));
		basePanel.add(AppConstant.backChkBox);
		
		basePanel.add(AppConstant.testConnBtn);
		
		if (AppConstant.loginChkProp.equals("1")) {
			AppConstant.setChecked(AppConstant.loginChkProp, AppConstant.loginChkBox, "1", true);
        } else {
        	AppConstant.setChecked(AppConstant.loginChkProp, AppConstant.loginChkBox, "0", false);
        }
		
		if (AppConstant.foreignChkProp.equals("1")) {
			AppConstant.setChecked(AppConstant.foreignChkProp, AppConstant.foreignChkBox, "1", true);
        } else {
        	AppConstant.setChecked(AppConstant.foreignChkProp, AppConstant.foreignChkBox, "0", false);
        }
		
		if (AppConstant.likeChkProp.equals("1")) {
			AppConstant.setChecked(AppConstant.likeChkProp, AppConstant.likeChkBox, "1", true);
        } else {
        	AppConstant.setChecked(AppConstant.likeChkProp, AppConstant.likeChkBox, "0", false);
        }
		
		if (AppConstant.favaoriteChkProp.equals("1")) {
			AppConstant.setChecked(AppConstant.favaoriteChkProp, AppConstant.favaoriteChkBox, "1", true);
        } else {
        	AppConstant.setChecked(AppConstant.favaoriteChkProp, AppConstant.favaoriteChkBox, "0", false);
        }
		
		if (AppConstant.reviewChkProp.equals("1")) {
			AppConstant.setChecked(AppConstant.reviewChkProp, AppConstant.reviewChkBox, "1", true);
        } else {
        	AppConstant.setChecked(AppConstant.reviewChkProp, AppConstant.reviewChkBox, "0", false);
        }
		
		if (AppConstant.adminChkProp.equals("1")) {
			AppConstant.setChecked(AppConstant.adminChkProp, AppConstant.adminChkBox, "1", true);
        } else {
        	AppConstant.setChecked(AppConstant.adminChkProp, AppConstant.adminChkBox, "0", false);
        }
		
		if (AppConstant.frontChkProp.equals("1")) {
			AppConstant.setChecked(AppConstant.frontChkProp, AppConstant.frontChkBox, "1", true);
        } else {
        	AppConstant.setChecked(AppConstant.frontChkProp, AppConstant.frontChkBox, "0", false);
        }
		
		if (AppConstant.backChkProp.equals("1")) {
			AppConstant.setChecked(AppConstant.backChkProp, AppConstant.backChkBox, "1", true);
        } else {
        	AppConstant.setChecked(AppConstant.backChkProp, AppConstant.backChkBox, "0", false);
        }
		
		/**
		 * ActionListener
		*/
		AppConstant.testConnBtn.addActionListener (new ActionListener () {
		    public void actionPerformed(ActionEvent e) {
		    	AppConstant.setValProps();
		    	AppConstant.getDbConnection();
				String message;
				if (AppConstant.mysqlDbcon == null && AppConstant.postgresDbCon == null) {
					message = AppConstant.bothErrorMessage;
				} else if (AppConstant.mysqlDbcon == null && AppConstant.postgresDbCon != null) {
					message = AppConstant.mysqlErrorMessage;
				} else if (AppConstant.mysqlDbcon != null && AppConstant.postgresDbCon == null) {
					message = AppConstant.postErrorMessage;
				} else {
					message = AppConstant.successMessage;
				}
				JOptionPane.showMessageDialog(null, message);
            }
		});
		
		if (JOptionPane.showConfirmDialog(null, basePanel, "Settings", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {

			AppConstant.setValProps();
			AppConstant.getProps(file);
			AppConstant.getDbConnection();
			
			if (AppConstant.mysqlDbcon == null) {
				JOptionPane.showMessageDialog(null, AppConstant.generalMessage);
				System.exit(0);
			} else {
				AppConstant.getDbsProp();
				AppConstant.frame.setVisible(true);
			}
		} else {
			System.exit(0);
		}
	}
}
