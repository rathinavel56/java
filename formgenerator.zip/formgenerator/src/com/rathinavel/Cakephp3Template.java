package com.rathinavel;

public class Cakephp3Template {

	public static String getModelString(String dbName, String tableName, String field, Boolean foreignChkBool) {
		String model = 
				"<?php"
				+"\nclass Project extends AppModel {"
				+"\n    var $name = \"Project\";"
				+"\n}"
				+"\n?>";
		return model;
	}
	
	public static String getControllerString(String dbName, String tableName, String field, Boolean foreignChkBool) {
		String controller = 
						"\n<?php"
						+"\nclass DemomoviesController  extends AppController {"
						+"\n"
						+"\n    public $components = array(\"Session\");"
						+"\n"
						+"\n	public function index() {"
						+"\n		$movies = $this->Demomovie->find(\"all\");"
						+"\n		$this->set(\"demomovies\", $movies);"
						+"\n	}"
						+"\n"
						+"\n	public function add() {"
						+"\n		if (!empty($this->data)) {"
						+"\n			$this->Demomovie->create($this->data);"
						+"\n			if ($this->Demomovie->save()) {"
						+"\n				$this->Session->setFlash(\"The movie has been saved\");"
						+"\n				$this->redirect(array(\"action\" => \"add\"));"
						+"\n			} else {"
						+"\n				$this->Session->setFlash(\"The movie could not be saved. Please, try again.\");"
						+"\n			}"
						+"\n		}"
						+"\n	}"
						+"\n	public function delete($id = null) {"
						+"\n		if (!$id) {"
						+"\n			$this->Session->setFlash(\"Invalid id for movie\");"
						+"\n			$this->redirect(array(\"action\" => \"index\"));"
						+"\n		}"
						+"\n		if ($this->Demomovie->delete($id)) {"
						+"\n			$this->Session->setFlash(\"Movie deleted\");"
						+"\n		} else {"
						+"\n			$this->Session->setFlash(__(\"Movie was not deleted\",true));"
						+"\n		}"
						+"\n		$this->redirect(array(\"action\" => \"index\"));"
						+"\n	}"
						+"\n	public function edit($id = null) {"
						+"\n		if (!$id && empty($this->data)) {"
						+"\n			$this->Session->setFlash(\"Invalid movie\");"
						+"\n			$this->redirect(array(\"action\" => \"index\"));"
						+"\n		}"
						+"\n		if (!empty($this->data)) {"
						+"\n			if ($this->Demomovie->save($this->data)) {"
						+"\n				$this->Session->setFlash(\"The movie has been saved\");"
						+"\n				$this->redirect(array(\"action\" => \"index\"));"
						+"\n			} else {"
						+"\n				$this->Session->setFlash(\"The movie could not be saved. Please, try again.\");"
						+"\n			}"
						+"\n		}"
						+"\n		if (empty($this->data)) {"
						+"\n			$this->data = $this->Demomovie->read(null, $id);"
						+"\n		}"
						+"\n	}"
						+"\n"	
						+"\n	public function view($id = null) {"
						+"\n		if (!$id) {"
						+"\n			$this->Session->setFlash(\"Invalid movie\");"
						+"\n			$this->redirect(array(\"action\" => \"index\"));"
						+"\n		}"
						+"\n		$this->set(\"movie\", $this->Demomovie->findById($id));"
						+"\n	}"
						+"\n}"
						+"\n?>";
		return controller;
	}
	
	public static String getindexString(String dbName, String tableName, String field, Boolean foreignChkBool) {
		String index = 
						"<h1>Add New Project</h1>"
						+"\n"
						+"\n<?php"
						+"\n	echo $this->Form->create(\"Project\");"
						+"\n	echo $this->Form->input(\"name\");"
						+"\n	echo $this->Form->input(\"user_id\");"
						+"\n	echo $this->Form->end(\"Save New Project\");"
						+"\n?>";
		return index;
	}
	
	public static String getAddString(String dbName, String tableName, String field, Boolean foreignChkBool) {
		String add = 
						"<h1>Add New Project</h1>"
						+"\n"
						+"\n<?php"
						+"\n	echo $this->Form->create(\"Project\");"
						+"\n	echo $this->Form->input(\"name\");"
						+"\n	echo $this->Form->input(\"user_id\");"
						+"\n	echo $this->Form->end(\"Save New Project\");"
						+"\n?>";
		return add;
	}
	
	public static String getEditString(String dbName, String tableName, String field, Boolean foreignChkBool) {
		String edit = 
						"<h1>Edit Project</h1>"
						+"\n"
						+"\n<?php"
						+"\n	echo $this->Form->create(\"Project\");"
						+"\n	echo $this->Form->input(\"id\", array('type'=> \"hidden\"));"
						+"\n	echo $this->Form->input(\"name\");"
						+"\n	echo $this->Form->input(\"user_id\");"
						+"\n	echo $this->Form->end(\"Save New Project\");"
						+"\n?>";
		return edit;
	}
	
	public static String getViewString(String dbName, String tableName, String field, Boolean foreignChkBool) {
		String view = 
						"<h1>View Project</h1>"
						+"\n"
						+"\n<?php"
						+"\n	echo $this->Form->create(\"Project\");"
						+"\n	echo $this->Form->input(\"id\", array('type'=> \"hidden\"));"
						+"\n	echo $this->Form->input(\"name\");"
						+"\n	echo $this->Form->input(\"user_id\");"
						+"\n	echo $this->Form->end(\"Save New Project\");"
						+"\n?>";
		return view;
	}
}
