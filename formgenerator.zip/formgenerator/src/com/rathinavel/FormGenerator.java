/**
* @package		Form Generator
* @author 		K.V.Rathinavel Subramani
* @since 		2016.12.04 08.00.00
*/
package com.rathinavel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Menu;
import java.awt.MenuItem;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class FormGenerator extends JPanel {
	
	private static Menu applicationMenu = new Menu("Application");
	private  JPanel westPanel = new JPanel() {
		private static final long serialVersionUID = 1L;
		protected void paintComponent(Graphics g) {
			Graphics2D graphics2d = (Graphics2D)g;
			GradientPaint paint = new GradientPaint(0, 0, Color.BLACK, 150, 1100, new Color(26, 10, 173));
			graphics2d.setPaint(paint);
			graphics2d.fillRect(0, 0, 160, 600);
		 };
	};
	private  JPanel centerPanel  = new JPanel(new GridLayout());
	
	/**
	 * Button
	*/
	private JButton generateCode               = AppConstant.createButton(AppConstant.generateCode, 12, AppConstant.black);
	private JButton downloadBase               = AppConstant.createButton(AppConstant.downloadBase, 12, AppConstant.black);
	private JButton projectStructure           = AppConstant.createButton(AppConstant.projectStructure, 12, AppConstant.black);
	private JButton settings                   = AppConstant.createButton(AppConstant.settings, 12, AppConstant.black);
	private JButton exit                       = AppConstant.createButton(AppConstant.exit, 12, AppConstant.black);
	
	/**
	 * Menu Bar
	*/
	private static MenuItem settingsItem       = new MenuItem("Settings");
	
	final FrontEnd getFront                    = new FrontEnd();
	
	private static final long serialVersionUID = 1L;
	
	public FormGenerator() {
		SettingPanel.initProps();
		init();
	}
	
	public void init() {
		
		 setLayout(new BorderLayout());
		 
		 applicationMenu.add(settingsItem);
		 
		 westPanel.setPreferredSize(new Dimension(150,600));
		 generateCode.setPreferredSize(new Dimension(125,50));
		 downloadBase.setPreferredSize(new Dimension(125,50));
		 settings.setPreferredSize(new Dimension(125,50));
		 projectStructure.setPreferredSize(new Dimension(125,50));
		 exit.setPreferredSize(new Dimension(125,50));
		 
		 westPanel.setBorder(BorderFactory.createLineBorder(new Color(236,233,216)));
		 settings.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		 projectStructure.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		 exit.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		 
		 westPanel.add(generateCode);
		 westPanel.add(downloadBase);
		 westPanel.add(projectStructure);
		 westPanel.add(settings);
		 westPanel.add(exit);
		 
		 centerPanel.add(getFront);
		 add(westPanel,BorderLayout.WEST);
		 add(centerPanel,BorderLayout.CENTER);
		
		/**
		 * ActionListener
		*/
		 generateCode.addActionListener (new ActionListener () {
		    public void actionPerformed(ActionEvent e) {
		    	centerPanel.add(getFront);
            }
		});
		 
		downloadBase.addActionListener (new ActionListener () {
		    public void actionPerformed(ActionEvent e) {
		    	JOptionPane.showMessageDialog(null, AppConstant.underDevelopmentMessage);
            }
		});
		
		projectStructure.addActionListener (new ActionListener () {
		    public void actionPerformed(ActionEvent e) {
		    	JOptionPane.showMessageDialog(null, AppConstant.underDevelopmentMessage);
            }
		});
		
		settings.addActionListener (new ActionListener () {
		    public void actionPerformed(ActionEvent e) {
		    	AppConstant.frame.setVisible(false);
		    	SettingPanel.initProps();
            }
		});
		
		exit.addActionListener (new ActionListener () {
		    public void actionPerformed(ActionEvent e) {
		    	System.exit(0);
            }
		});
	}

	public static void main(String[] args) {
		AppConstant.frame.add(new FormGenerator());
		AppConstant.frame.setSize(800,580);
		
		/**
		 * Frame To Center Screen
		 */
		AppConstant.frame.setLocationRelativeTo(null);
		
		AppConstant.frame.setVisible(true);
		AppConstant.frame.setResizable(false);
		AppConstant.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}