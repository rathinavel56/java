/**
 * @package		Form Generator
 * @author 		K.V.Rathinavel Subramani
 * @since 		2016.12.04 08.00.00
 */
package com.rathinavel;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Map;
import java.util.TreeMap;
import java.sql.Statement;

import javax.swing.JOptionPane;

public class ServiceBackEnd {

	static Inflector inflector = new Inflector();
	static ResultSet rs = null;

	public static ResultSet getAllDatabaseTables() {
		rs = null;
		try {
			if (AppConstant.selectDbtype.equals(AppConstant.mysql)) {
				Statement stmt = AppConstant.mysqlDbcon.createStatement();
				rs = stmt
						.executeQuery("SELECT SCHEMA_NAME 'databases' FROM information_schema.SCHEMATA;");
			} else if (AppConstant.selectDbtype.equals(AppConstant.postgres)) {
				Statement stmt = AppConstant.postgresDbCon.createStatement();
				rs = stmt
						.executeQuery("SELECT datname as databases FROM  pg_database where datname Not in ('postgres','template1','template0')");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rs;
	}

	public ResultSet getSelectTables(String dbName) {
		rs = null;
		try {
			if (AppConstant.selectDbtype.equals(AppConstant.mysql)) {
				Statement stmt = AppConstant.mysqlDbcon.createStatement();
				rs = stmt
						.executeQuery("SELECT table_name FROM information_schema.tables WHERE table_schema = '"
								+ dbName + "' ORDER BY table_name ASC");
			} else if (AppConstant.selectDbtype.equals(AppConstant.postgres)) {
				if (!AppConstant.postgresDbName.equals(dbName)) {
					AppConstant.postgresDbName = dbName;
					AppConstant.getDbConnection();
				}
				Statement stmt = AppConstant.postgresDbCon.createStatement();
				rs = stmt
						.executeQuery("SELECT table_name FROM information_schema.tables WHERE table_schema='public' and table_catalog = '"
								+ dbName + "'");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rs;
	}

	public static ResultSet getSelectTablesColumn(String dbName,
			String tableName) {
		rs = null;
		try {
			if (AppConstant.selectDbtype.equals(AppConstant.mysql)) {
				Statement stmt = AppConstant.mysqlDbcon.createStatement();
				rs = stmt
						.executeQuery("SELECT column_name, column_type, data_type ,column_key, is_nullable"
								+ " FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME <> 'created_at'"
								+ " AND COLUMN_NAME <> 'updated_at' AND COLUMN_NAME <> 'created' AND COLUMN_NAME <> 'modified'"
								+ " AND TABLE_SCHEMA = '"
								+ dbName
								+ "' AND TABLE_NAME = '" + tableName + "';");
			} else if (AppConstant.selectDbtype.equals(AppConstant.postgres)) {
				Statement stmt = AppConstant.postgresDbCon.createStatement();
				rs = stmt
						.executeQuery("select column_name, data_type , is_nullable, udt_name, column_default, character_maximum_length"
								+ " from INFORMATION_SCHEMA.COLUMNS where table_schema='public' and table_catalog = '"
								+ dbName
								+ "' and table_name = '"
								+ tableName
								+ "';");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rs;
	}

	public static ResultSet generateCode(String dbName, String type) {
		rs = null;
		try {
			if (type == AppConstant.defaultAll) {
				ServiceBackEnd get_tables = new ServiceBackEnd();
				ResultSet getTableList = get_tables.getSelectTables(dbName);
				String maindir = System.getProperty("user.dir")
						+ AppConstant.dirSep + "Generated_Projects"
						+ AppConstant.dirSep;

				StringBuilder patchCode = new StringBuilder("");
				StringBuilder adminEnitity = new StringBuilder("");
				while (getTableList.next()) {

					ResultSet columns = getSelectTablesColumn(dbName,
							getTableList.getString("table_name"));

					AppConstant.tableColumn = columns;

					StringBuilder paramsString = new StringBuilder("");
					StringBuilder indexLabelFields = new StringBuilder("");
					StringBuilder indexValFields = new StringBuilder("");
					StringBuilder formFieldsAdd = new StringBuilder("");
					StringBuilder formFieldsEdit = new StringBuilder("");
					StringBuilder viewFields = new StringBuilder("");
					StringBuilder foreignKeyGet = new StringBuilder("");
					StringBuilder foreignKeyInject1 = new StringBuilder("");
					StringBuilder foreignKeyInject2 = new StringBuilder("");
					StringBuilder agAdminFields = new StringBuilder("");
					StringBuilder agAdminColumnsFields = new StringBuilder("");
					StringBuilder SwaggerFields = new StringBuilder("");

					int columnCnt = 1;
					int fcolumnCnt = 1;
					String tableSingle = inflector.singularize(getTableList
							.getString("table_name"));
					String foreignKeyStr = inflector.capitalize(inflector
							.singularize(getTableList.getString("table_name")
									.replaceAll("_", " ")));

					/** Replace Array **/
					Map<String, String> replacements = new TreeMap<String, String>();
					replacements.put("##DATABASENAME##", dbName);
					replacements.put("##TABLENAME##",
							getTableList.getString("table_name"));
					replacements.put("##TABLENAMEUP##", inflector
							.capitalize(getTableList.getString("table_name")));
					replacements.put("##TABLENAMESINGLE##", tableSingle);
					replacements
							.put("##TABLENAME_SINGULAR##", inflector
									.singularize(inflector.camelCase(
											getTableList
													.getString("table_name"),
											true)));
					replacements.put("##TABLENAMECAPSPACE##", foreignKeyStr);
					replacements.put("##TABLENAMECAP##",
							getFieldFormatted(getTableList
									.getString("table_name")));
					// String admindir = "";

					while (columns.next()) {
						String requiredStr = "false";
						String required = "";
						String columnName = "";
						String columnType = "";
						if (columns.getString("IS_NULLABLE").equals("YES")) {
							required = "action Required";
							requiredStr = "true";
						}
						if (AppConstant.selectDbtype.equals(AppConstant.mysql)) {
							columnName = columns.getString("COLUMN_NAME");
							columnType = columns.getString("COLUMN_TYPE");
						} else if (AppConstant.selectDbtype
								.equals(AppConstant.postgres)) {
							columnName = columns.getString("column_name");
							columnType = columns.getString("data_type");
						}
						paramsString.append("\n       	  	 * @param  "
								+ columnName + " { " + columnType.toUpperCase()
								+ " } " + required);

						Boolean foreignChkBool = false;
						if (!columnName.equals("id")) {

							String dataType = "string";
							String fieldRemoveId = columnName.replaceAll("_id",
									"");
							String labelColumn = getFieldFormatted(fieldRemoveId);
							String tableSingular = inflector
									.singularize(getTableList
											.getString("table_name"));
							String tablePluralize = inflector
									.pluralize(fieldRemoveId);

							if (!columnName.equals("user_id")) {
								if (!Arrays.asList(AppConstant.notINIntput)
										.contains(
												columns.getString("DATA_TYPE"))) {
									/**
									 * Foreign Key Check
									 **/
									String foreignChk = columnName
											.substring(columnName.length() - 3);
									if (foreignChk.equals("_id")) {
										foreignChkBool = true;
										String foreignKeyField = columnName
												.replaceAll("_id", "");
										String foreignKeyStrColn = getFieldFormatted(foreignKeyField);
										if (fcolumnCnt == 1) {
											foreignKeyGet.append("	/**"
													+ "\n			* Foreign Key Data"
													+ "\n			**/");
											foreignKeyInject1.append(", \""
													+ foreignKeyStrColn + "\"");
											foreignKeyInject2.append(", "
													+ foreignKeyStrColn);
											fcolumnCnt++;
										} else {
											foreignKeyInject1.append(", \""
													+ foreignKeyStrColn + "\"");
											foreignKeyInject2.append(", "
													+ foreignKeyStrColn);
										}
										adminEnitity
												.append(ReplaceTemplates
														.getAgAdminEntity(inflector
																.pluralize(foreignKeyField)));
										foreignKeyGet
												.append(ReplaceTemplates.getforeignString(
														getTableList
																.getString("table_name"),
														columnName));
										formFieldsAdd
												.append(ReplaceTemplates.getSelectString(
														getTableList
																.getString("table_name"),
														columnName,
														requiredStr, "add"));
										formFieldsEdit
												.append(ReplaceTemplates.getSelectString(
														getTableList
																.getString("table_name"),
														columnName,
														requiredStr, "edit"));
									} else {
										formFieldsAdd
												.append(ReplaceTemplates.getInputString(
														getTableList
																.getString("table_name"),
														columnName, requiredStr));
										formFieldsEdit
												.append(ReplaceTemplates.getInputString(
														getTableList
																.getString("table_name"),
														columnName, requiredStr));
									}
									dataType = "integer";

								} else if (columns.getString("DATA_TYPE")
										.equals(AppConstant.text)
										|| columns.getString("DATA_TYPE")
												.equals(AppConstant.longtext)) {
									formFieldsAdd.append(ReplaceTemplates
											.getTexAreaString(getTableList
													.getString("table_name"),
													columnName, requiredStr));
									formFieldsEdit.append(ReplaceTemplates
											.getTexAreaString(getTableList
													.getString("table_name"),
													columnName, requiredStr));

								} else if (columns.getString("DATA_TYPE")
										.equals(AppConstant.date)) {
									formFieldsAdd.append(ReplaceTemplates
											.getDateString(getTableList
													.getString("table_name"),
													columnName, requiredStr));
									formFieldsEdit.append(ReplaceTemplates
											.getDateString(getTableList
													.getString("table_name"),
													columnName, requiredStr));

								} else if (columns.getString("DATA_TYPE")
										.equals(AppConstant.datetime)) {
									formFieldsAdd.append(ReplaceTemplates
											.getDateString(getTableList
													.getString("table_name"),
													columnName, requiredStr));
									formFieldsEdit.append(ReplaceTemplates
											.getDateString(getTableList
													.getString("table_name"),
													columnName, requiredStr));

								} else if (columns.getString("DATA_TYPE")
										.equals(AppConstant.tinyint)) {
									formFieldsAdd.append(ReplaceTemplates
											.getInputString(getTableList
													.getString("table_name"),
													columnName, requiredStr));
									formFieldsEdit.append(ReplaceTemplates
											.getInputString(getTableList
													.getString("table_name"),
													columnName, requiredStr));
								}

								agAdminColumnsFields.append(ReplaceTemplates
										.getAgAdminString(tableSingular,
												labelColumn, tablePluralize,
												columnName, foreignChkBool,
												requiredStr));
							}

							indexLabelFields.append(ReplaceTemplates
									.getIndexString(labelColumn));

							indexValFields.append(ReplaceTemplates
									.getIndexValString(tableSingular,
											fieldRemoveId, labelColumn,
											columnName, foreignChkBool));

							viewFields.append(ReplaceTemplates.getViewString(
									tableSingular, labelColumn, fieldRemoveId,
									columnName, foreignChkBool));

							SwaggerFields.append(ReplaceTemplates
									.getSwaggerString(getTableList
											.getString("table_name"),
											labelColumn, columnName, dataType,
											requiredStr));

							agAdminFields.append(ReplaceTemplates
									.getAgAdminFieldsString(tableSingular,
											labelColumn, tablePluralize,
											columnName, foreignChkBool));
						}
						columnCnt++;
					}

					if (AppConstant.angularFormat
							.equals(AppConstant.angularFormatOld)) {

						String dir = maindir + AppConstant.dirSep + dbName
								+ AppConstant.dirSep + "client"
								+ AppConstant.dirSep + "src"
								+ AppConstant.dirSep + "app"
								+ AppConstant.dirSep
								+ getTableList.getString("table_name") + "/";
						/** Index Js **/
						String indexJs = AngularOldTemplate
								.getOldControllerIndexJs(dbName,
										getTableList.getString("table_name"),
										paramsString.toString());
						GenerateSourceCode.generateCode(
								dir + getTableList.getString("table_name")
										+ ".js", Strtr.replaceStringUsingMap(
										indexJs, replacements));

						/** Add Js **/
						String addJs = AngularOldTemplate
								.getOldControllerAddJs(dbName,
										getTableList.getString("table_name"),
										paramsString.toString(),
										foreignKeyGet.toString(),
										foreignKeyInject1.toString(),
										foreignKeyInject2.toString());
						GenerateSourceCode.generateCode(
								dir + getTableList.getString("table_name")
										+ "_add.js", Strtr
										.replaceStringUsingMap(addJs,
												replacements));

						/** Edit Js **/
						String editJs = AngularOldTemplate
								.getOldControllerEditJs(dbName,
										getTableList.getString("table_name"),
										paramsString.toString(),
										foreignKeyGet.toString(),
										foreignKeyInject1.toString(),
										foreignKeyInject2.toString());
						GenerateSourceCode.generateCode(
								dir + getTableList.getString("table_name")
										+ "_edit.js", Strtr
										.replaceStringUsingMap(editJs,
												replacements));

						/** View Js **/
						String viewJs = AngularOldTemplate
								.getOldControllerViewJs(dbName,
										getTableList.getString("table_name"),
										paramsString.toString());
						GenerateSourceCode.generateCode(
								dir + getTableList.getString("table_name")
										+ "_view.js", Strtr
										.replaceStringUsingMap(viewJs,
												replacements));

						/** Service Js **/
						String serviceJs = AngularOldTemplate.getOldServiceJs(
								dbName, getTableList.getString("table_name"),
								paramsString.toString());
						GenerateSourceCode
								.generateCode(
										dir
												+ GenerateSourceCode
														.camelcasify(getTableList
																.getString("table_name"))
												+ "Service.js",
										Strtr.replaceStringUsingMap(serviceJs,
												replacements));

						/** Module Js **/
						String moduleJs = AngularOldTemplate.getOldModuleJs(
								dbName, getTableList.getString("table_name"),
								paramsString.toString());
						GenerateSourceCode
								.generateCode(
										dir
												+ GenerateSourceCode
														.camelcasify(getTableList
																.getString("table_name"))
												+ "module.js", Strtr
												.replaceStringUsingMap(
														moduleJs, replacements));

						/** Index Html Js **/
						String htmlContentindex = ReplaceTemplates
								.getOldIndexHtml(dbName,
										getTableList.getString("table_name"),
										indexLabelFields.toString(),
										indexValFields.toString(), columnCnt);
						GenerateSourceCode.generateCode(dir + "index.tpl.html",
								Strtr.replaceStringUsingMap(htmlContentindex,
										replacements));

						/** Add Html Js **/
						String htmlContentAdd = ReplaceTemplates.getOldAddHtml(
								dbName, getTableList.getString("table_name"),
								formFieldsAdd.toString());
						GenerateSourceCode.generateCode(dir + "add.tpl.html",
								Strtr.replaceStringUsingMap(htmlContentAdd,
										replacements));

						/** Edit Html Js **/
						String htmlContentEdit = ReplaceTemplates
								.getOldEditHtml(dbName,
										getTableList.getString("table_name"),
										formFieldsEdit.toString());
						GenerateSourceCode.generateCode(dir + "edit.tpl.html",
								Strtr.replaceStringUsingMap(htmlContentEdit,
										replacements));

						/** View Html Js **/
						String htmlContentView = ReplaceTemplates
								.getOldViewHtml(dbName,
										getTableList.getString("table_name"),
										viewFields.toString());
						GenerateSourceCode.generateCode(dir + "view.tpl.html",
								Strtr.replaceStringUsingMap(htmlContentView,
										replacements));

					} else {

						String dir = maindir + AppConstant.dirSep + dbName
								+ AppConstant.dirSep + "client"
								+ AppConstant.dirSep + "src"
								+ AppConstant.dirSep + "app"
								+ AppConstant.dirSep;
						/** Index Js **/
						String indexJs = AngularNewTemplate
								.getNewControllerIndexJs(dbName,
										getTableList.getString("table_name"),
										paramsString.toString());
						GenerateSourceCode.generateCode(
								dir + "scripts" + AppConstant.dirSep
										+ "controllers" + AppConstant.dirSep
										+ getTableList.getString("table_name")
										+ ".js", Strtr.replaceStringUsingMap(
										indexJs, replacements));

						/** Add Js **/
						String addJs = AngularNewTemplate
								.getNewControllerAddJs(dbName,
										getTableList.getString("table_name"),
										paramsString.toString(),
										foreignKeyGet.toString(),
										foreignKeyInject1.toString(),
										foreignKeyInject2.toString());
						GenerateSourceCode.generateCode(
								dir + "scripts" + AppConstant.dirSep
										+ "controllers" + AppConstant.dirSep
										+ getTableList.getString("table_name")
										+ "_add.js", Strtr
										.replaceStringUsingMap(addJs,
												replacements));

						/** Edit Js **/
						String editJs = AngularNewTemplate
								.getNewControllerEditJs(dbName,
										getTableList.getString("table_name"),
										paramsString.toString(),
										foreignKeyGet.toString(),
										foreignKeyInject1.toString(),
										foreignKeyInject2.toString());
						GenerateSourceCode.generateCode(
								dir + "scripts" + AppConstant.dirSep
										+ "controllers" + AppConstant.dirSep
										+ getTableList.getString("table_name")
										+ "_edit.js", Strtr
										.replaceStringUsingMap(editJs,
												replacements));

						/** View Js **/
						String viewJs = AngularNewTemplate
								.getNewControllerViewJs(dbName,
										getTableList.getString("table_name"),
										paramsString.toString());
						GenerateSourceCode.generateCode(
								dir + "scripts" + AppConstant.dirSep
										+ "controllers" + AppConstant.dirSep
										+ getTableList.getString("table_name")
										+ "_view.js", Strtr
										.replaceStringUsingMap(viewJs,
												replacements));

						/** Service Js **/
						String serviceJs = AngularNewTemplate.getNewServiceJs(
								dbName, getTableList.getString("table_name"),
								paramsString.toString());
						GenerateSourceCode
								.generateCode(
										dir
												+ "scripts"
												+ AppConstant.dirSep
												+ "services"
												+ AppConstant.dirSep
												+ GenerateSourceCode
														.camelcasify(getTableList
																.getString("table_name"))
												+ ".js",
										Strtr.replaceStringUsingMap(serviceJs,
												replacements));

						/** Module Js **/
						String moduleJs = AngularNewTemplate.getNewModuleJs(
								dbName, getTableList.getString("table_name"),
								paramsString.toString());
						GenerateSourceCode
								.generateCode(
										dir
												+ "scripts"
												+ AppConstant.dirSep
												+ "services"
												+ AppConstant.dirSep
												+ GenerateSourceCode
														.camelcasify(getTableList
																.getString("table_name"))
												+ "module.js", Strtr
												.replaceStringUsingMap(
														moduleJs, replacements));

						/** Index Html Js **/
						String htmlContentindex = ReplaceTemplates
								.getNewIndexHtml(dbName,
										getTableList.getString("table_name"),
										indexLabelFields.toString(),
										indexValFields.toString(), columnCnt);
						GenerateSourceCode.generateCode(
								dir + "views" + AppConstant.dirSep
										+ getTableList.getString("table_name")
										+ ".html", Strtr.replaceStringUsingMap(
										htmlContentindex, replacements));

						/** Add Html Js **/
						String htmlContentAdd = ReplaceTemplates.getNewAddHtml(
								dbName, getTableList.getString("table_name"),
								formFieldsAdd.toString());
						GenerateSourceCode.generateCode(dir + "views"
								+ AppConstant.dirSep + tableSingle
								+ "_add.html", Strtr.replaceStringUsingMap(
								htmlContentAdd, replacements));

						/** Edit Html Js **/
						String htmlContentEdit = ReplaceTemplates
								.getNewEditHtml(dbName,
										getTableList.getString("table_name"),
										formFieldsEdit.toString());
						GenerateSourceCode.generateCode(dir + "views"
								+ AppConstant.dirSep + tableSingle
								+ "_edit.html", Strtr.replaceStringUsingMap(
								htmlContentEdit, replacements));

						/** View Html Js **/
						String htmlContentView = ReplaceTemplates
								.getNewViewHtml(dbName,
										getTableList.getString("table_name"),
										viewFields.toString());
						GenerateSourceCode.generateCode(dir + "views"
								+ AppConstant.dirSep + tableSingle
								+ "_view.html", Strtr.replaceStringUsingMap(
								htmlContentView, replacements));

					}
					/** View Swagger Js **/
					if (!SwaggerFields.toString().equals("")) {
						String swaggerContentView = SwaggerTemplate
							.getSwaggerString(dbName,
									getTableList.getString("table_name"),
									SwaggerFields.toString());
						GenerateSourceCode.generateCode(
								maindir
										+ AppConstant.dirSep
										+ dbName
										+ AppConstant.dirSep
										+ "public"
										+ AppConstant.dirSep
										+ "api_explorer"
										+ AppConstant.dirSep
										+ "api-docs"
										+ AppConstant.dirSep
										+ GenerateSourceCode
												.camelcasify(getTableList
														.getString("table_name"))
										+ ".json", Strtr.replaceStringUsingMap(
										swaggerContentView, replacements));
					}
					if (!agAdminColumnsFields.toString().equals("")) {
						String htmlContentAgadmin = ReplaceTemplates.getAgAdmin(
								dbName, getTableList.getString("table_name"),
								agAdminColumnsFields.toString(),
								agAdminFields.toString(), paramsString.toString());
						patchCode.append(Strtr.replaceStringUsingMap(
								htmlContentAgadmin, replacements));
						adminEnitity.append(ReplaceTemplates
								.getAgAdminEntity(getTableList
										.getString("table_name")));
					}

					/** Back End Laravel **/
					/*
					 * ReplaceTemplates.getLaravelModelString(dbName,
					 * getTableList.getString("table_name"), field,
					 * foreignChkBool);
					 * ReplaceTemplates.getLaravelTransformerString(dbName,
					 * getTableList.getString("table_name"), field,
					 * foreignChkBool);
					 * ReplaceTemplates.getLaravelControllerString(dbName,
					 * getTableList.getString("table_name"), field,
					 * foreignChkBool);
					 * 
					 * ReplaceTemplates.getSlimModelString(dbName,
					 * getTableList.getString("table_name"), field,
					 * foreignChkBool);
					 * ReplaceTemplates.getSlimIndexString(dbName,
					 * getTableList.getString("table_name"), field,
					 * foreignChkBool);
					 */

				}
				if (!patchCode.equals("")) {
					/** Ag-Admin Js **/
					GenerateSourceCode.generateCode(maindir + "PatchCode.txt",
							adminEnitity.toString() + patchCode.toString());
				}

				JOptionPane.showMessageDialog(null,
						"Generate Completed successfully. Kindly check the path "
								+ maindir);
			} else {

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rs;
	}

	public static String getFieldFormatted(String field) {
		String fieldFormatted = field.replaceAll("_", " ");
		char[] array = fieldFormatted.toCharArray();
		array[0] = Character.toUpperCase(array[0]);

		// Upper case all letters that follow a whitespace character.
		for (int i = 1; i < array.length; i++) {
			if (Character.isWhitespace(array[i - 1])) {
				array[i] = Character.toUpperCase(array[i]);
			}
		}
		return new String(array);
	}
}