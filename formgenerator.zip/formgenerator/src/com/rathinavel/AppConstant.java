/**
* @package		Form Generator
* @author 		K.V.Rathinavel Subramani
* @since 		2016.12.04 08.00.00
*/
package com.rathinavel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Properties;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class AppConstant {
	public static String frameName                 = "Code Generator";
	public static String databaseTypeLabel         = "Select DB Type";
	public static String databaseLabel             = "Select DB";
	public static String tableLabel                = "Select Table";
	public static String singelLabel               = "Single File Up";
	public static String mutipleLabel              = "Mutiple File Up";
	public static String loginLabel                = "Login Check";
	public static String frontLabel                = "Front End";
	public static String pluginLabel               = "Plugin";
	public static String favaoriteLabel            = "Favaorite";
	public static String reviewLabel               = "Review";
	public static String likeLabel                 = "Like";
	public static String backLabel                 = "Back End";
	public static String adminLabel                = "Admin End";
	public static String foreignLabel              = "Foreign Key";
	public static String generateButton            = "Generate Code";
	public static String file                      = "File";
	public static String databaseCon               = "Database Connection";
	public static String mysql                     = "Mysql";
	public static String postgres                  = "Postgres";
	public static String defaultAll                = "All Tables";
	public static String generateCode              = "Generate Code";
	public static String projectStructure          = "Project Structure";
	public static String settings                  = "Settings";
	public static String downloadBase              = "Download Base";
	public static String exit                      = "Exit";
	public static String mysqlHostLabel            = "Mysql Host";
	public static String mysqlUsernameLabel        = "Mysql Username";
	public static String mysqlPasswordLabel        = "Mysql Password";
	public static String mysqlPortLabel            = "Mysql Port";
	public static String postgresHostLabel         = "PostGres Host";
	public static String postgresUsernameLabel     = "PostGres Username";
	public static String postgresPasswordLabel     = "PostGres Password";
	public static String postgresPortLabel         = "PostGres Port";
	public static String copyRightLabel            = "Copy Right";
	public static String licenseLabel              = "License";
	public static String testConnection            = "Test Database Connnections";
	public static String mysqlDB                   = "information_schema";
	public static String ConnectionErrormessage    = "BackEnds";
	public static String backendType               = "Back End";
	public static String frontType                 = "Front End";
	public static String selectDbtype              = "";
	public static String laravel                   = "Laravel";
	public static String slim          			   = "Slim";
	public static String cakephp2                  = "Cakephp 2";
	public static String cakephp3                  = "Cakephp 3";
	public static String javahibernet              = "Java Hibernet";
	public static String javastuts                 = "Java Stuts";
	public static String angularFormatOld          = "Angular Old";
	public static String angularFormatNew          = "Angular New";
	public static String backbone                  = "Backbone";
	public static String react                     = "React";
	public static String ember                     = "Ember";
	public static String sysLoginUser              =  System.getProperty("user.name");
	public static String postgresDbName            =  "postgres";
	public static String angularFormat;	
	public static String mysqlHost;
	public static String mysqlUsername;
	public static String mysqlPassword;
	public static String mysqlPort;
	public static String mysqlConnect;
	public static String postgresHost;
	public static String postgresUsername;
	public static String postgresPassword;
	public static String postgresPort;
	public static String copyRight;
	public static String license;
	public static String postgresConnect;
	public static String loginChkProp; 
	public static String foreignChkProp; 
	public static String likeChkProp; 
	public static String favaoriteChkProp; 
	public static String reviewChkProp; 
	public static String adminChkProp; 
	public static String frontChkProp; 
	public static String backChkProp;
	
	/**
	 * App Message
	 **/
	public static String allErrorMessage           = "Unable to Estbalish Any Connection. Please Contact Administrator";
	public static String bothErrorMessage          = "Unable to Estbalish Mysql and Postgres Connection. Please Contact Administrator";
	public static String mysqlErrorMessage         = "Unable to Estbalish Mysql Connection. Please Contact Administrator";
	public static String postErrorMessage          = "Unable to Estbalish Postgres Connection. Please Contact Administrator";
	public static String successMessage            = "Both Mysql and Postgres are connected";
	public static String generalMessage            = "Unable to Estbalish Connection. Please contact administrator";
	public static String underDevelopmentMessage   = "Under Development";	
	
	
	public static String text                       = "text";
	public static String longtext                   = "longtext";
	public static String date                       = "date";
	public static String datetime                   = "datetime";
	public static String tinyint                    = "tinyint";
	
	public static String[]   defaultObj             = { AppConstant.defaultAll };
	public static String[]   backObj                = { AppConstant.laravel, AppConstant.slim, AppConstant.cakephp2, AppConstant.cakephp3, AppConstant.javahibernet, AppConstant.javastuts };
	public static String[]   frontEndComobo         = { AppConstant.angularFormatOld, AppConstant.angularFormatNew, AppConstant.backbone, AppConstant.react, AppConstant.ember };
	public static String[]   defaultDatabase        = { "Select Connection", "Mysql", "Postgres" };
	//public static String[] defaultDatabase          = AppConstant.getDbsProp();
	//public static String[]   defaultDatabase       = {};
	public static Object[]   previewScreen         = { "Generating Display" };
	public static Object[][] columnData            = new Object[][] {};
	public static String[]   notINIntputField      = { "user_id" };
	public static String[]   notINIntput           = { "varchar", "char", "text", "longtext", "date", "datetime", "tinyint" };
	
	public static Color black                      = Color.black;
	public static Color white                      = Color.white;
	
	public static JFrame frame                     = new JFrame(AppConstant.frameName);
	

	public static JTextField mysqlHostText         = new JTextField();
	public static JTextField mysqlUsernameText     = new JTextField();
	public static JTextField mysqlPasswordText     = new JTextField();
	public static JTextField mysqlPortText         = new JTextField();
	public static JTextField postgresHostText      = new JTextField();
	public static JTextField postgresUsernameText  = new JTextField();
	public static JTextField postgresPasswordText  = new JTextField();
	public static JTextField copyRightText         = new JTextField();
	public static JTextField licenseText           = new JTextField();
	public static JTextField postgresPortText      = new JTextField();
	public static JCheckBox  loginChkBox           = new JCheckBox();
	public static JCheckBox  foreignChkBox         = new JCheckBox();
	public static JCheckBox  likeChkBox            = new JCheckBox();
	public static JCheckBox  favaoriteChkBox       = new JCheckBox();
	public static JCheckBox  reviewChkBox          = new JCheckBox();
	public static JCheckBox  adminChkBox           = new JCheckBox();
	public static JCheckBox  frontChkBox           = new JCheckBox();
	public static JCheckBox  backChkBox            = new JCheckBox();
	public static JButton    testConnBtn           = new JButton(AppConstant.testConnection);
	
	public static Connection mysqlDbcon    = null;
	public static Connection postgresDbCon = null;
	public static String dirSep            = File.separator;

	public static ResultSet tableColumn;
	
	public static JLabel createLabel(String title, int fSize, Color fontColor) {
		JLabel label = new JLabel(title);
		label.setFont(new Font("Arial", Font.BOLD, fSize));
		label.setForeground(fontColor);
		return label;
	}
	
	public static JTextField createText(String title, int fSize) {
		JTextField textField = new JTextField();
		return textField;
	}
	
	public static JPasswordField createPassText(String title, int fSize) {
		JPasswordField passtextField = new JPasswordField();
		return passtextField;
	}
	
	public static JButton createButton(String title, int fSize, Color fontColor) {
		JButton btn = new JButton(title);
		btn.setFont(new Font("Arial", Font.BOLD, fSize));
		btn.setForeground(fontColor);
		return btn;
	}

	public static String[] getDbsProp() {
		
		if(AppConstant.mysqlDbcon == null && AppConstant.postgresDbCon == null) {
			
			AppConstant.defaultDatabase[0]       =  AppConstant.databaseCon;
			
		} else if(AppConstant.mysqlDbcon == null && AppConstant.postgresDbCon != null) {
			
			AppConstant.defaultDatabase[0]       =  AppConstant.mysql;
			
		} else if(AppConstant.mysqlDbcon != null && AppConstant.postgresDbCon == null) {
			
			AppConstant.defaultDatabase[0]       =  AppConstant.postgres;
			
		} else {
			
			AppConstant.defaultDatabase[0]       =  AppConstant.databaseCon;
			AppConstant.defaultDatabase[1]       =  AppConstant.mysql;
			AppConstant.defaultDatabase[2]       =  AppConstant.postgres;
		}
		return AppConstant.defaultDatabase;
	}
	
	public static JPanel createPBoxComo(JLabel databaseTypeLabel, @SuppressWarnings("rawtypes") JComboBox jComboBox) {
		
		JPanel pbox = new JPanel(new BorderLayout());
		databaseTypeLabel.setPreferredSize(new Dimension(100, 25));
		databaseTypeLabel.setMaximumSize(new Dimension(100, 25));
		jComboBox.setPreferredSize(new Dimension(150, 25));
		jComboBox.setMaximumSize(new Dimension(150, 25));
		pbox.setMaximumSize(new Dimension(300, 25));
		databaseTypeLabel.setForeground(Color.white);
		pbox.add(databaseTypeLabel, BorderLayout.WEST);
		pbox.add(jComboBox, BorderLayout.CENTER);
		pbox.setBackground(Color.DARK_GRAY);
		pbox.setOpaque(true);
		return pbox;
	}
	
	public static JPanel createPCheckBox(JLabel databaseTypeLabel, JCheckBox jCheckBox) {
		
		JPanel pbox = new JPanel(new BorderLayout());
		databaseTypeLabel.setPreferredSize(new Dimension(100, 25));
		databaseTypeLabel.setMaximumSize(new Dimension(100, 25));
		jCheckBox.setPreferredSize(new Dimension(150, 25));
		jCheckBox.setMaximumSize(new Dimension(150, 25));
		jCheckBox.setHorizontalAlignment(JCheckBox.CENTER);
		jCheckBox.setVerticalAlignment(JCheckBox.CENTER);
		jCheckBox.setBackground(Color.DARK_GRAY);
		pbox.setMaximumSize(new Dimension(300, 25));
		databaseTypeLabel.setForeground(Color.white);
		pbox.add(databaseTypeLabel, BorderLayout.WEST);
		pbox.add(jCheckBox, BorderLayout.CENTER);
		pbox.setBackground(Color.DARK_GRAY);
		pbox.setOpaque(true);
		return pbox;
	}
	
	public static JPanel createPButtonBox(JLabel databaseTypeLabel, JButton jButton) {
		
		JPanel pbox = new JPanel(new BorderLayout());
		databaseTypeLabel.setPreferredSize(new Dimension(100, 25));
		databaseTypeLabel.setMaximumSize(new Dimension(100, 25));
		jButton.setPreferredSize(new Dimension(150, 25));
		jButton.setMaximumSize(new Dimension(150, 25));
		pbox.setMaximumSize(new Dimension(300, 25));
		databaseTypeLabel.setForeground(Color.white);
		pbox.add(databaseTypeLabel, BorderLayout.WEST);
		pbox.add(jButton, BorderLayout.CENTER);
		pbox.setBackground(Color.DARK_GRAY);
		pbox.setOpaque(true);
		return pbox;
	}
	
	public static JPanel UiDecorate(JPanel jPanel, Color BackColor) {
		jPanel.setBackground(BackColor);
		jPanel.setOpaque(true);
		return jPanel;
	}
	
	public static void setProps(File file) {
		Properties properties = new Properties();
		try {
			properties.load(new FileInputStream(file));
			AppConstant.mysqlHost            = properties.getProperty("mysql_host");
			AppConstant.mysqlUsername        = properties.getProperty("mysql_username");
			AppConstant.mysqlPassword        = properties.getProperty("mysql_password");
			AppConstant.mysqlPort            = properties.getProperty("mysql_port");
			AppConstant.mysqlConnect         = properties.getProperty("mysql_connect");
			AppConstant.postgresHost         = properties.getProperty("postgres_host");
			AppConstant.postgresUsername     = properties.getProperty("postgres_username");
			AppConstant.postgresPassword     = properties.getProperty("postgres_password");
			AppConstant.postgresPort         = properties.getProperty("postgres_port");
			AppConstant.postgresConnect      = properties.getProperty("postgres_connect");
			AppConstant.copyRight            = properties.getProperty("copy_right");
			AppConstant.license              = properties.getProperty("license");
			AppConstant.loginChkProp         = properties.getProperty("login_chk");
			AppConstant.foreignChkProp       = properties.getProperty("foreign_chk");
			AppConstant.likeChkProp          = properties.getProperty("like_chk");
			AppConstant.favaoriteChkProp     = properties.getProperty("favaorite_chk");
			AppConstant.reviewChkProp        = properties.getProperty("review_chk");
			AppConstant.adminChkProp         = properties.getProperty("admin_chk");
			AppConstant.frontChkProp         = properties.getProperty("front_chk");
			AppConstant.backChkProp          = properties.getProperty("back_chk");
			
		} catch (Exception exception) {
			exception.printStackTrace();
		}
	}
	
	public static void setValProps() {
		AppConstant.mysqlHost            = mysqlHostText.getText();
		AppConstant.mysqlUsername        = mysqlUsernameText.getText();
		AppConstant.mysqlPassword        = mysqlPasswordText.getText();
		AppConstant.mysqlPort            = mysqlPortText.getText();
		AppConstant.postgresHost         = postgresHostText.getText();
		AppConstant.postgresUsername     = postgresUsernameText.getText();
		AppConstant.postgresPassword     = postgresPasswordText.getText();
		AppConstant.postgresPort         = postgresPortText.getText();
		AppConstant.copyRight            = copyRightText.getText();
		AppConstant.license              = licenseText.getText();
		AppConstant.loginChkProp         = loginChkBox.getText();
		AppConstant.foreignChkProp       = foreignChkBox.getText();
		AppConstant.likeChkProp          = likeChkBox.getText();
		AppConstant.favaoriteChkProp     = favaoriteChkBox.getText();
		AppConstant.reviewChkProp        = reviewChkBox.getText();
		AppConstant.adminChkProp         = adminChkBox.getText();
		AppConstant.frontChkProp         = frontChkBox.getText();
		AppConstant.backChkProp          = backChkBox.getText();
	}
	
	public static void getProps(File file) {
		Properties properties = new Properties();
		try {
			
			FileOutputStream fileOutputStream = new FileOutputStream(file);
			
			if (loginChkBox.isSelected()) {
				AppConstant.loginChkProp = "1";
            } else {
            	AppConstant.loginChkProp = "0";
            }
			
			if (foreignChkBox.isSelected()) {
				AppConstant.foreignChkProp = "1";
            } else {
            	AppConstant.foreignChkProp = "0";
            }
			
			if (likeChkBox.isSelected()) {
				AppConstant.likeChkProp = "1";
            } else {
            	AppConstant.likeChkProp = "0";
            }
			
			if (favaoriteChkBox.isSelected()) {
				AppConstant.favaoriteChkProp = "1";
            } else {
            	AppConstant.favaoriteChkProp = "0";
            }
			
			if (reviewChkBox.isSelected()) {
				AppConstant.reviewChkProp = "1";
            } else {
            	AppConstant.reviewChkProp = "0";
            }
			
			if (adminChkBox.isSelected()) {
				AppConstant.adminChkProp = "1";
            } else {
            	AppConstant.adminChkProp = "0";
            }
			
			if (frontChkBox.isSelected()) {
				AppConstant.frontChkProp = "1";
            } else {
            	AppConstant.frontChkProp = "0";
            }
			
			if (backChkBox.isSelected()) {
				AppConstant.backChkProp = "1";
            } else {
            	AppConstant.backChkProp = "0";
            }
			
			properties.put("mysql_host", AppConstant.mysqlHost);
			properties.put("mysql_username", AppConstant.mysqlUsername);
			properties.put("mysql_password", AppConstant.mysqlPassword);
			properties.put("mysql_port", AppConstant.mysqlPort);
			properties.put("mysql_connect", "OK");
			properties.put("postgres_host", AppConstant.postgresHost);
			properties.put("postgres_username", AppConstant.postgresUsername);
			properties.put("postgres_password", AppConstant.postgresPassword);
			properties.put("postgres_port", AppConstant.postgresPort);
			properties.put("postgres_connect", "OK");
			properties.put("copy_right", AppConstant.copyRight);
			properties.put("license", AppConstant.license);
			properties.put("login_chk", AppConstant.loginChkProp);
			properties.put("foreign_chk", AppConstant.foreignChkProp);
			properties.put("like_chk", AppConstant.likeChkProp);
			properties.put("favaorite_chk", AppConstant.favaoriteChkProp);
			properties.put("review_chk", AppConstant.reviewChkProp);
			properties.put("admin_chk", AppConstant.adminChkProp);
			properties.put("front_chk", AppConstant.frontChkProp);
			properties.put("back_chk", AppConstant.backChkProp);
				
			properties.save(fileOutputStream, "Form Generator");
			fileOutputStream.close();
		} catch (Exception exception) {
			JOptionPane.showMessageDialog(null, "Unable to open application. Please contact administrator");
			exception.printStackTrace();
		}
	}
	
	public static void getDbConnection() {
		DBConnection getDatabaseConnection = new DBConnection();
		Connection mysqlCon = (Connection) getDatabaseConnection.getMysqlDBconnect();
		Connection postgresCon = (Connection) getDatabaseConnection.getPostgresDBconnect();
		AppConstant.mysqlDbcon     = mysqlCon;
		AppConstant.postgresDbCon  = postgresCon;
	}
	
	public static void setChecked(String props, JCheckBox jCheckBox, String propsVal, Boolean jCheckBoxBool) {
		props = propsVal;
		jCheckBox.setSelected(jCheckBoxBool);
	}
	
	/**
	 * @return the base
	 */
	public static String getMysqlHost() {
		return mysqlHost;
	}
	
	public static String getMysqlUsername() {
		return mysqlUsername;
	}
	
	public static String getMysqlPassword() {
		return mysqlPassword;
	}
	
	public static String getPostgresHost() {
		return postgresHost;
	}
	
	public static String getPostgresUsername() {
		return postgresUsername;
	}
	
	public static String getPostgresPassword() {
		return postgresPassword;
	}
	
	public static String getLoginChkProp() {
		return loginChkProp;
	}
	
	public static String getForeignChkProp() {
		return foreignChkProp;
	}
	
	public static String getLikeChkProp() {
		return likeChkProp;
	}
	
	public static String getFavaoriteChkProp() {
		return favaoriteChkProp;
	}
	
	public static String getReviewChkProp() {
		return reviewChkProp;
	}
	
	public static String getAdminChkProp() {
		return adminChkProp;
	}
	
	public static String getFrontChkProp() {
		return frontChkProp;
	}
	
	public static String getBackChkProp() {
		return backChkProp;
	}
}