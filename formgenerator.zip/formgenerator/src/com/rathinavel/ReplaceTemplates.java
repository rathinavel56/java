/**
 * @package		Form Generator
 * @author 		K.V.Rathinavel Subramani
 * @since 		2016.12.04 08.00.00
 */
package com.rathinavel;

import java.text.SimpleDateFormat;
import java.util.Date;

public class ReplaceTemplates {

	static Inflector inflector = new Inflector();

	public static String getDefaultAuthor(String dbName) {
		String timeStamp = new SimpleDateFormat("yyyy.MM.dd HH.mm.ss")
				.format(new Date());
		String year = new SimpleDateFormat("yyyy").format(new Date());
		String author = "/**" + "\n* @package		" + dbName + "\n* @author 		"
				+ AppConstant.sysLoginUser + "\n* @copyright 	Copyright (c) "
				+ year + " " + AppConstant.copyRight + "\n* @license		"
				+ AppConstant.license + "\n* @since 		" + timeStamp + "\n*/\n";
		return author;
	}

	public static String getforeignString(String tableName, String field) {
		String eliminateId = field.replaceAll("_id", "").replaceAll("_", "");
		String fieldFormat = inflector.singularize(inflector.camelCase(
				eliminateId, true));
		String foreignString = "\n			" + fieldFormat
				+ ".get().$promise.then(function (response) {"
				+ "\n         		$scope." + inflector.pluralize(eliminateId)
				+ " = response.data;" + "\n         	});";
		return foreignString;
	}

	public static String getInputString(String tableName, String field,
			String validate) {

		String fieldFormat = inflector.singularize(inflector.camelCase(
				field.replaceAll("_", ""), true));
		String validateClass = "";
		String validateHtml = "";
		if (validate.equals("true")) {
			String[] error = getErrorString(tableName, field, fieldFormat);
			validateClass = error[0];
			validateHtml = error[1];
		}

		String inputString = "\n                <div class=\"form-group\" "
				+ validateClass
				+ ">"
				+ "\n                    <label for=\""
				+ field
				+ "\">{{'"
				+ fieldFormat
				+ "'| translate}}</label>"
				+ "\n                    <input type=\"text\" class=\"form-control\" id=\""
				+ field + "\" name=\"" + field + "\" ng-model=\"model."
				+ tableName + "." + field + "\" placeholder=\"{{'Enter "
				+ fieldFormat + "'| translate}}\" />"
				+ "\n                </div>" + validateHtml + "\n";
		return inputString;
	}

	public static String getDateString(String tableName, String field,
			String validate) {
		String fieldFormat = inflector.singularize(inflector.camelCase(field
				.replaceAll("_id", "").replaceAll("_", ""), true));
		String validateClass = "";
		String validateHtml = "";
		if (validate.equals("true")) {
			String[] error = getErrorString(tableName, field, fieldFormat);
			validateClass = error[0];
			validateHtml = error[1];
		}
		String dateString = "\n                <div class=\"form-group\" "
				+ validateClass
				+ ">"
				+ "\n					<div class=\"input-group\">"
				+ "\n						<span class=\"input-group-addon\"><i class=\"fa fa-user fa-fw\"></i></span>"
				+ "\n						<input class=\"form-control\" name=\"dob\" type=\"text\" ng-model=\"model."
				+ tableName
				+ "."
				+ field
				+ "\" placeholder=\"{{'Enter "
				+ fieldFormat
				+ "'| translate}}\" data-date-format=\"yyyy-MM-dd\" data-autoclose=\"1\" bs-datepicker required=\"true\" />"
				+ "\n                    </div>" + "\n                </div>"
				+ validateHtml + "\n";
		return dateString;
	}

	public static String getSelectString(String tableName, String field,
			String validate, String mode) {
		String eliminateId = field.replaceAll("_id", "").replaceAll("_", "");
		String fieldFormat = inflector.singularize(inflector.camelCase(
				eliminateId, true));
		String fieldFormatVal = inflector.singularize(eliminateId);
		String validateClass = "";
		String selectString = "";
		String validateHtml = "";
		if (validate.equals("true")) {
			String[] error = getErrorString(tableName, field, fieldFormat);
			validateClass = error[0];
			validateHtml = error[1];
		}
		if (mode.equals("add")) {
			selectString = "\n                <div class=\"form-group\" "
					+ validateClass
					+ ">"
					+ "\n                    <div class=\"input-group\">"
					+ "\n						<label for=\""
					+ field
					+ "\">{{'"
					+ fieldFormat
					+ "'| translate}}</label>"
					+ "\n						<span class=\"input-group-addon\"><i class=\"fa fa-book fa-fw\"></i></span>"
					+ "\n						<select class=\"form-control\" name=\"" + field
					+ "\" id=\"" + field + "\" ng-model=\"model." + tableName
					+ "." + field + "\" ng-required=\"true\">"
					+ "\n							<option value=\"\">{{'Select " + fieldFormat
					+ "'| translate}}</option>"
					+ "\n                            <option ng-repeat=\""
					+ eliminateId + " in " + inflector.pluralize(eliminateId)
					+ "\" value=\"{{" + fieldFormatVal + ".id}}\">{{"
					+ fieldFormatVal + ".name}}</option>"
					+ "\n                        </select>" + "\n					</div>"
					+ "\n				</div>" + validateHtml + "\n";
		} else {
			selectString = "\n                <div class=\"form-group\" "
					+ validateClass
					+ ">"
					+ "\n                    <div class=\"input-group\">"
					+ "\n						<label for=\""
					+ field
					+ "\">{{'"
					+ fieldFormat
					+ "'| translate}}</label>"
					+ "\n						<span class=\"input-group-addon\"><i class=\"fa fa-book fa-fw\"></i></span>"
					+ "\n						<select class=\"form-control\" name=\"" + field
					+ "\" id=\"" + field + "\" ng-model=\"model." + tableName
					+ "." + field + "\" ng-required=\"true\">"
					+ "\n							<option value=\"\">{{'Select " + fieldFormat
					+ "'| translate}}</option>"
					+ "\n                            <option ng-repeat=\""
					+ eliminateId + " in " + inflector.pluralize(eliminateId)
					+ "\" value=\"{{" + fieldFormatVal
					+ ".id}}\" ng-selected=\"model." + tableName + "." + field
					+ " == " + fieldFormatVal + ".id\">{{" + fieldFormatVal
					+ ".name}}</option>"
					+ "\n                        </select>" + "\n					</div>"
					+ "\n				</div>" + validateHtml + "\n";
		}
		return selectString;
	}

	public static String getTexAreaString(String tableName, String field,
			String validate) {

		String fieldFormat = inflector.singularize(inflector.camelCase(field
				.replaceAll("_id", "").replaceAll("_", ""), true));
		String validateClass = "";
		String validateHtml = "";
		if (validate.equals("true")) {
			String[] error = getErrorString(tableName, field, fieldFormat);
			validateClass = error[0];
			validateHtml = error[1];
		}
		String texareaString = "\n				<div class=\"form-group\" "
				+ validateClass + ">" + "\n					<div class=\"input-group\">"
				+ "\n						<label for=\"" + field + "\">{{'" + fieldFormat
				+ "'| translate}}</label>"
				+ "\n						<textarea class=\"form-control\" name=\"" + field
				+ "\" id=\"" + field + "\" placeholder=\"{{'" + fieldFormat
				+ "'| translate}}\" ng-model=\"model." + tableName + "."
				+ field + "\" /> </textarea>" + "\n					</div>"
				+ "\n				</div>" + validateHtml + "\n";
		return texareaString;
	}

	public static String getSingleFileString(String tableName, String field) {
		String fieldFormat = inflector.singularize(inflector.camelCase(field
				.replaceAll("_id", "").replaceAll("_", ""), true));
		String fileString = "\n				<div class=\"form-group\">"
				+ "\n					<div class=\"input-group\">"
				+ "\n						<label for=\""
				+ field
				+ "\">{{'"
				+ fieldFormat
				+ "'| translate}}</label>"
				+ "\n						<input id=\"inputFile\" name=\"file\" class=\"input-file\" type=\"file\" ng-model=\"model."
				+ tableName + ".files\" base-sixty-four-input />"
				+ "\n					</div>" + "\n				</div>\n";
		return fileString;
	}

	public static String getSingleMutipeFileString(String tableName,
			String field) {
		String fieldFormat = inflector.singularize(inflector.camelCase(field
				.replaceAll("_id", "").replaceAll("_", ""), true));
		String mutipeFileString = "\n				<div class=\"form-group\">"
				+ "\n					<div class=\"input-group\">"
				+ "\n						<label for=\""
				+ field
				+ "\">{{'"
				+ fieldFormat
				+ "'| translate}}</label>"
				+ "\n						<input id=\"inputFile\" name=\"file\" class=\"input-file\" type=\"file\" ng-model=\"model."
				+ tableName + ".files\" multiple base-sixty-four-input />"
				+ "\n					</div>" + "\n				</div>\n";
		return mutipeFileString;
	}

	public static String getIndexString(String field) {
		String indexString = "\n						<th>{{'" + field
				+ "' | translate }}</th>";
		return indexString;
	}

	public static String getIndexValString(String tableName,
			String fieldRemoveId, String fieldFormatted, String field,
			Boolean foreignChkBool) {

		String valString = "";
		if (foreignChkBool == true) {
			valString = "\n						<td>{{" + tableName + "." + fieldFormatted
					+ "}}</td>";
		} else {
			valString = "\n						<td>{{" + tableName + "." + field + "}}</td>";
		}

		return valString;
	}

	public static String getViewString(String tableName, String labelColumn,
			String fieldRemoveId, String field, Boolean foreignChkBool) {
		String viewString = "";
		if (foreignChkBool == true) {
			viewString = "\n						<tr>" + "\n							<td>{{'" + labelColumn
					+ "' | translate }} : </td>" + "\n							<td>{{"
					+ tableName + "." + fieldRemoveId + ".name}}</td>"
					+ "\n						</tr>";
		} else {
			viewString = "\n						<tr>" + "\n							<td>{{'" + labelColumn
					+ "' | translate }} : </td>" + "\n							<td>{{"
					+ tableName + "." + field + "}}</td>" + "\n						</tr>";
		}
		return viewString;
	}

	public static String getAgAdminString(String tableName, String labelColumn,
			String tablePluralize, String field, Boolean foreignChkBool,
			String requiredStr) {
		String adminString = "";
		if (foreignChkBool == true) {
			adminString = "\n					nga.field(\"" + field + "\", \"reference\")"
					+ "\n							.label(\"" + labelColumn + "\")"
					+ "\n							.attributes({" + "\n								placeholder: \""
					+ labelColumn + "\"" + "\n							})"
					+ "\n							.validation({" + "\n								required: "
					+ requiredStr + "" + "\n							})"
					+ "\n							.targetEntity(nga.entity(\"" + tablePluralize
					+ "\"))" + "\n							.perPage(all)"
					+ "\n							.targetField(nga.field('name').map(truncate))"
					+ ",";
		} else {

			if (field.equals("is_active")) {
				adminString = "\n					nga.field(\"is_active\", \"choice\").label(\"Active?\")"
						+ "\n							.attributes({"
						+ "\n							 	placeholder: \"Active?\""
						+ "\n							})"
						+ "\n							.validation({"
						+ "\n								required: "
						+ requiredStr
						+ ""
						+ "\n							})"
						+ "\n							.choices([{"
						+ "\n								label: 'Yes',"
						+ "\n								value: true"
						+ "\n							}, {"
						+ "\n							label: 'No',"
						+ "\n									value: false"
						+ "\n							}]),";
			} else {
				adminString = "\n					nga.field(\"" + field + "\", \"" + field
						+ "\").label(\"" + labelColumn + "\")"
						+ "\n							.attributes({"
						+ "\n								placeholder: \"" + labelColumn + "\""
						+ "\n							})" + "\n							.validation({"
						+ "\n								required: " + requiredStr + ""
						+ "\n							}),";
			}
		}
		return adminString;
	}

	public static String getAgAdminFieldsString(String tableName,
			String labelColumn, String tableSingular, String field,
			Boolean foreignChkBool) {

		String adminString = "";
		if (foreignChkBool == true) {
			adminString = "\n                    nga.field(\"" + tableName
					+ "." + tableSingular + ".id\").label(\"" + labelColumn
					+ "\"),";
		} else {
			adminString = "\n                    nga.field(\"" + tableName
					+ "." + field + "\").label(\"" + labelColumn + "\"),";
		}
		return adminString;
	}

	public static String getSwaggerString(String tableName, String labelColumn,
			String field, String dataType, String validate) {
		String swaggerString = "\n                        {"
				+ "\n                            \"name\": \"" + field + "\","
				+ "\n                            \"paramType\": \"path\","
				+ "\n                            \"type\": \"" + dataType
				+ "\"," + "\n                            \"description\": \""
				+ labelColumn + "\","
				+ "\n                            \"required\": " + validate
				+ "\n                        },";
		return swaggerString;
	}

	public static String[] getErrorString(String tableName, String field,
			String fieldFormat) {
		String errorHtml = "\n				<span class=\"error\" ng-show=\"(##TABLENAME##.$submitted || ##TABLENAME##.##FIELD##.$touched) && (##TABLENAME##.##FIELD##.$pristine || ##TABLENAME##.##FIELD##.$invalid) && (##TABLENAME##.##FIELD##.$error.required)\">{{\"Enter ##FIELDFORMATTED##\"| translate }} </span>"
				+ "\n				<span class=\"error\" ng-show=\"(##TABLENAME##.$submitted || ##TABLENAME##.##FIELD##.$touched) && (##TABLENAME##.##FIELD##.$pristine || ##TABLENAME##.##FIELD##.$invalid) && (##TABLENAME##.##FIELD##.$error.maxlength)\">{{\"Maximum length is 25\"| translate}}</span>";
		String errorClass = "ng-class=\"{ 'has-error' : (##TABLENAME##.$submitted || ##TABLENAME##.##FIELD##.$touched) && (##TABLENAME##.##FIELD##.$pristine || ##TABLENAME##.##FIELD##.$invalid) && (##TABLENAME##.##FIELD##.$error.required)}\"";

		String errorClassFormatted = errorClass
				.replaceAll("##TABLENAME##", tableName)
				.replaceAll("##FIELD##", field)
				.replaceAll("##FIELDFORMATTED##", fieldFormat);

		String errorHtmlFormatted = errorHtml
				.replaceAll("##TABLENAME##", tableName)
				.replaceAll("##FIELD##", field)
				.replaceAll("##FIELDFORMATTED##", fieldFormat);

		String[] errorArr = { errorClassFormatted, errorHtmlFormatted };
		return errorArr;
	}

	public static String getOldIndexHtml(String dbName, String tableName,
			String labelFields, String formFeilds, int formFieldsLenght) {

		String htmlString = "<section>"
				+ "\n<div class=\"container\">"
				+ "\n	<div growl></div>"
				+ "\n    <div class=\"page-head clearfix\">"
				+ "\n        <h1 class=\"pull-left\">{{'##TABLENAMECAPSPACE##'| translate}}</h1>"
				+ "\n        <div class=\"pull-right search-table-field\" >"
				+ "\n            <a href=\"#/##TABLENAMESINGLE##/add\" class=\"btn btn-green btn-animate\"><i class=\"fa fa-plus-circle fa-fw\"></i>{{'Add ##TABLENAMECAPSPACE##'| translate}}</a>"
				+ "\n        </div>"
				+ "\n    </div>"
				+ "\n	<div class=\"row\">"
				+ "\n	 	<div class=\"col-md-12\">"
				+ "\n		 	<br><br>"
				+ "\n		 	<form class=\"form-inline\" name=\"refine_search\" ng-submit=\"refineSearch()\">"
				+ "\n				<div class=\"form-group\">"
				+ "\n					<input class=\"form-control\" ng-model=\"model.q\" type=\"text\" placeholder=\"{{'Keywords'| translate}}\">"
				+ "\n				</div>"
				+ "\n				<div class=\"form-group\">"
				+ "\n					<select class=\"form-control\" ng-model=\"model.statuss\">"
				+ "\n						<option value=\"\">{{'Select Status'| translate}}</option>"
				+ "\n						<option value=\"1\">{{'Active'| translate}}</option>"
				+ "\n						<option value=\"0\">{{'Inactive'| translate}}</option>"
				+ "\n					</select>"
				+ "\n				</div>"
				+ "\n				<div class=\"form-group\">"
				+ "\n			   		<select class=\"form-control\" ng-model=\"model.sortOrder\">"
				+ "\n						<option value=\"\">{{'Sort By'| translate}}</option>"
				+ "\n						<option value=\"asc\">{{'Ascending'| translate}}</option>"
				+ "\n						<option value=\"desc\">{{'Descending'| translate}}</option>"
				+ "\n					</select>"
				+ "\n				</div>"
				+ "\n				<button type=\"submit\" class=\"btn btn-blue btn-animate\">{{'Filter'| translate}}</button>"
				+ "\n				<button type=\"button\" ng-click=\"cleanFilter()\" class=\"btn btn-blue btn-animate\">{{'Clear Filter'| translate}}</button>"
				+ "\n		 	</form>"
				+ "\n		</div>"
				+ "\n	</div>"
				+ "\n    <div class=\"table-block\">"
				+ "\n        <div class=\"table-responsive\">"
				+ "\n            <table class=\"table table-hover table-bordered\">"
				+ "\n                <thead>" + "\n                    <tr>"
				+ "\n                        <th>{{'S.No'| translate}}</th>"
				+ labelFields
				+ "\n                        <th>{{'Action'| translate}}</th>"
				+ "\n                    </tr>"
				+ "\n                </thead>"
				+ "\n                <tbody>"
				+ "\n                    <tr ng-repeat=\"##TABLENAMESINGLE## in ##TABLENAME##\" >"
				+ "\n                        <td>{{$index + 1}}</td>"
				+ formFeilds
				+ "\n                       	<td>"
				+ "\n							<a href=\"#/##TABLENAMESINGLE##/view/{{##TABLENAMESINGLE##.id}}\" title=\"{{ 'View Details' | translate }}\" class=\"btn btn-blue btn-animate btn-xs\">"
				+ "\n								{{ 'View Details' | translate }}"
				+ "\n                                <i class=\"fa fa-angle-double-right fa-fw\"></i>"
				+ "\n							</a>"
				+ "\n							<a href=\"#/##TABLENAMESINGLE##/edit/{{##TABLENAMESINGLE##.id}}\" title=\"{{ 'View Details' | translate }}\" class=\"btn btn-blue btn-animate btn-xs\">"
				+ "\n								{{ 'Edit Details' | translate }}"
				+ "\n                                <i class=\"fa fa-angle-double-right fa-fw\"></i>"
				+ "\n							</a>"
				+ "\n							<a href=\"#/##TABLENAMESINGLE##/delete/{{##TABLENAMESINGLE##.id}}\" title=\"{{ 'View Details' | translate }}\" class=\"btn btn-blue btn-animate btn-xs\">"
				+ "\n								{{ 'Delete' | translate }}"
				+ "\n                                <i class=\"fa fa-angle-double-right fa-fw\"></i>"
				+ "\n							</a>"
				+ "\n                       	</td>"
				+ "\n                    </tr>"
				+ "\n                    <tr ng-if=\"##TABLENAME##.length == 0\">"
				+ "\n                        <td colspan=\""
				+ formFieldsLenght
				+ "\">"
				+ "\n                            <p class=\"hor-space alert alert-danger text-center\">{{'No Records For ##TABLENAMECAPSPACE##'| translate}}</p>"
				+ "\n                        </td>"
				+ "\n                    </tr>"
				+ "\n                </tbody>"
				+ "\n            </table>"
				+ "\n        </div>"
				+ "\n        <div class=\"paging clearfix text-center\" ng-if=\"##TABLENAME##.length != 0\">"
				+ "\n                <uib-pagination total-items=\"_metadata.total\" num-pages=\"_metadata.total_pages\" ng-model=\"currentPage\" max-size=\"maxSize\" class=\"pagination-sm\" boundary-links=\"true\" boundary-link-numbers=\"true\" rotate=\"false\" items-per-page=\"_metadata.per_page\" ng-change=\"paginate()\"></uib-pagination>"
				+ "\n        </div>"
				+ "\n    </div>"
				+ "\n</div>"
				+ "\n</section>";

		return htmlString;
	}

	public static String getOldAddHtml(String dbName, String tableName,
			String formFeilds) {

		String htmlString = "<section>"
				+ "\n    <div class=\"container\">"
				+ "\n        <div class=\"form-content\">"
				+ "\n                                        <!-- Form ##TABLENAME## Start-->                                                                "
				+ "\n            <form role=\"form\" class=\"clearfix\" enctype=\"multipart/form-data\" name=\"##TABLENAME##Add\" ng-submit=\"##TABLENAME##_create(##TABLENAME##.$valid)\" novalidate>"
				+ "\n                <div class=\"form-heading\">"
				+ "\n                    <h2><span>{{'Add ##TABLENAMECAPSPACE##'| translate}}</span></h2>"
				+ "\n                </div>"
				+ "\n                 "
				+ formFeilds
				+ ""
				+ "\n"
				+ "\n                <div class=\"form-footer education-btn\">"
				+ "\n                    <button class=\"btn btn-blue btn-animate wid-230 mr5\" type=\"submit\">{{'Create'| translate }}</button>"
				+ "\n                    <a href=\"#/##TABLENAME##\" class=\"btn btn-danger btn-animate wid-230\">{{'Cancel'| translate }}</a>"
				+ "\n                </div>"
				+ "\n"
				+ "\n            </form>"
				+ "\n                                        <!-- Form ##TABLENAMECAP## End-->                                                                "
				+ "\n        </div>" + "\n    </div>" + "\n</section>";

		return htmlString;
	}

	public static String getOldEditHtml(String dbName, String tableName,
			String formFeilds) {
		String htmlString = "<section>"
				+ "\n    <div class=\"container\">"
				+ "\n        <div class=\"form-content\">"
				+ "\n                                        <!-- Form ##TABLENAMECAP## Start-->                                                                "
				+ "\n            <form role=\"form\" class=\"clearfix\" enctype=\"multipart/form-data\" name=\"##TABLENAME##Update\" ng-submit=\"##TABLENAME##_update(##TABLENAME##.$valid)\" novalidate>"
				+ "\n                <div class=\"form-heading\">"
				+ "\n                    <h2><span>{{'Edit ##TABLENAMECAPSPACE##'| translate}}</span></h2>"
				+ "\n                </div>"
				+ "\n                 "
				+ formFeilds
				+ ""
				+ "\n"
				+ "\n                <div class=\"form-footer education-btn\">"
				+ "\n                    <button class=\"btn btn-blue btn-animate wid-230 mr5\" type=\"submit\">{{'Update'| translate }}</button>"
				+ "\n                    <a href=\"#/##TABLENAME##\" class=\"btn btn-danger btn-animate wid-230\">{{'Cancel'| translate }}</a>"
				+ "\n                </div>"
				+ "\n"
				+ "\n            </form>"
				+ "\n                                        <!-- Form ##TABLENAMECAP## End-->                                                                "
				+ "\n        </div>" + "\n    </div>" + "\n</section>";
		return htmlString;
	}

	public static String getOldViewHtml(String dbName, String tableName,
			String viewFeilds) {
		String htmlString = "<section>"
				+ "\n    <div class=\"container\">"
				+ "\n		<div class=\"panel panel-info\">"
				+ "\n			<div class=\"panel-heading\">"
				+ "\n				<h3 class=\"panel-title\">{{'##TABLENAMECAP## View Details'| translate}}</h3>"
				+ "\n			</div>"
				+ "\n		   <div class=\"panel-body\">"
				+ "\n			  <div class=\"row\">"
				+ "\n				<div class=\"col-md-3 col-lg-3 \" align=\"center\"> <img alt=\"User Pic\" src=\"http://babyinfoforyou.com/wp-content/uploads/2014/10/avatar-300x300.png\" class=\"img-circle img-responsive\"> </div>"
				+ "\n				<div class=\" col-md-9 col-lg-9 \">"
				+ "\n					<table class=\"table table-user-information\">"
				+ "\n					   <tbody>"
				+ viewFeilds
				+ "\n					   </tbody>"
				+ "\n					</table>"
				+ "\n				</div>"
				+ "\n			  </div>"
				+ "\n		   </div>"
				+ "\n		   <div class=\"panel-footer\">"
				+ "\n			  <span class=\"pull-right\">"
				+ "\n				  <a href=\"#/##TABLENAME##\" data-original-title=\"Cancel\" data-toggle=\"tooltip\" type=\"button\" class=\"btn btn-sm btn-warning\">{{'Cancel'| translate }}</a>"
				+ "\n				  <a href=\"#/##TABLENAMESINGLE##/edit/{{##TABLENAMESINGLE##.id}}\" data-original-title=\"Edit\" data-toggle=\"tooltip\" type=\"button\" class=\"btn btn-sm btn-warning\">{{'Edit'| translate }}</a>"
				+ "\n				  <a href=\"#/##TABLENAMESINGLE##/delete/{{##TABLENAMESINGLE##.id}}\" data-original-title=\"Remove\" data-toggle=\"tooltip\" type=\"button\" class=\"btn btn-sm btn-danger\">{{'Delete'| translate }}</a>"
				+ "\n			  </span>" + "\n		   </div>" + "\n		</div>"
				+ "\n    </div>" + "\n</section>";
		return htmlString;
	}

	public static String getNewIndexHtml(String dbName, String tableName,
			String labelFeilds, String formFeilds, int formFeildsLenght) {
		String htmlString = "<section>"
				+ "\n<div class=\"container\" ng-controller=\"##TABLENAME_SINGULAR##Controller\">"
				+ "\n	<div growl></div>"
				+ "\n    <div class=\"page-head clearfix\">"
				+ "\n        <h1 class=\"pull-left\">{{'##TABLENAMECAPSPACE##'| translate}}</h1>"
				+ "\n        <div class=\"pull-right search-table-field\" >"
				+ "\n            <a href=\"#/##TABLENAMESINGLE##/add\" class=\"btn btn-green btn-animate\"><i class=\"fa fa-plus-circle fa-fw\"></i>{{'Add ##TABLENAMECAPSPACE##'| translate}}</a>"
				+ "\n        </div>"
				+ "\n    </div>"
				+ "\n	<div class=\"row\">"
				+ "\n	 	<div class=\"col-md-12\">"
				+ "\n		 	<br><br>"
				+ "\n		 	<form class=\"form-inline\" name=\"refine_search\" ng-submit=\"refineSearch()\">"
				+ "\n				<div class=\"form-group\">"
				+ "\n					<input class=\"form-control\" ng-model=\"model.q\" type=\"text\" placeholder=\"{{'Keywords'| translate}}\">"
				+ "\n				</div>"
				+ "\n				<div class=\"form-group\">"
				+ "\n					<select class=\"form-control\" ng-model=\"model.statuss\">"
				+ "\n						<option value=\"\">{{'Select Status'| translate}}</option>"
				+ "\n						<option value=\"1\">{{'Active'| translate}}</option>"
				+ "\n						<option value=\"0\">{{'Inactive'| translate}}</option>"
				+ "\n					</select>"
				+ "\n				</div>"
				+ "\n				<div class=\"form-group\">"
				+ "\n			   		<select class=\"form-control\" ng-model=\"model.sortOrder\">"
				+ "\n						<option value=\"\">{{'Sort By'| translate}}</option>"
				+ "\n						<option value=\"asc\">{{'Ascending'| translate}}</option>"
				+ "\n						<option value=\"desc\">{{'Descending'| translate}}</option>"
				+ "\n					</select>"
				+ "\n				</div>"
				+ "\n				<button type=\"submit\" class=\"btn btn-blue btn-animate\">{{'Filter'| translate}}</button>"
				+ "\n				<button type=\"button\" ng-click=\"cleanFilter()\" class=\"btn btn-blue btn-animate\">{{'Clear Filter'| translate}}</button>"
				+ "\n		 	</form>"
				+ "\n		</div>"
				+ "\n	</div>"
				+ "\n    <div class=\"table-block\">"
				+ "\n        <div class=\"table-responsive\">"
				+ "\n            <table class=\"table table-hover table-bordered\">"
				+ "\n                <thead>" + "\n                    <tr>"
				+ "\n                        <th>{{'S.No'| translate}}</th>"
				+ labelFeilds
				+ "\n                        <th>{{'Action'| translate}}</th>"
				+ "\n                    </tr>"
				+ "\n                </thead>"
				+ "\n                <tbody>"
				+ "\n                    <tr ng-repeat=\"##TABLENAMESINGLE## in ##TABLENAME##\" >"
				+ "\n                        <td>{{$index + 1}}</td>"
				+ formFeilds
				+ "\n                       	<td>"
				+ "\n							<a href=\"#/##TABLENAMESINGLE##/view/{{##TABLENAMESINGLE##.id}}\" title=\"{{ 'View Details' | translate }}\" class=\"btn btn-blue btn-animate btn-xs\">"
				+ "\n								{{ 'View Details' | translate }}"
				+ "\n                                <i class=\"fa fa-angle-double-right fa-fw\"></i>"
				+ "\n							</a>"
				+ "\n							<a href=\"#/##TABLENAMESINGLE##/edit/{{##TABLENAMESINGLE##.id}}\" title=\"{{ 'View Details' | translate }}\" class=\"btn btn-blue btn-animate btn-xs\">"
				+ "\n								{{ 'Edit Details' | translate }}"
				+ "\n                                <i class=\"fa fa-angle-double-right fa-fw\"></i>"
				+ "\n							</a>"
				+ "\n							<a href=\"#/##TABLENAMESINGLE##/delete/{{##TABLENAMESINGLE##.id}}\" title=\"{{ 'View Details' | translate }}\" class=\"btn btn-blue btn-animate btn-xs\">"
				+ "\n								{{ 'Delete' | translate }}"
				+ "\n                                <i class=\"fa fa-angle-double-right fa-fw\"></i>"
				+ "\n							</a>"
				+ "\n                       	</td>"
				+ "\n                    </tr>"
				+ "\n                    <tr ng-if=\"##TABLENAME##.length == 0\">"
				+ "\n                        <td colspan=\""
				+ formFeildsLenght
				+ "\">"
				+ "\n                            <p class=\"hor-space alert alert-danger text-center\">{{'No Records For ##TABLENAMECAPSPACE##'| translate}}</p>"
				+ "\n                        </td>"
				+ "\n                    </tr>"
				+ "\n                </tbody>"
				+ "\n            </table>"
				+ "\n        </div>"
				+ "\n        <div class=\"paging clearfix text-center\" ng-if=\"##TABLENAME##.length != 0\">"
				+ "\n                <uib-pagination total-items=\"_metadata.total\" num-pages=\"_metadata.total_pages\" ng-model=\"currentPage\" max-size=\"maxSize\" class=\"pagination-sm\" boundary-links=\"true\" boundary-link-numbers=\"true\" rotate=\"false\" items-per-page=\"_metadata.per_page\" ng-change=\"paginate()\"></uib-pagination>"
				+ "\n        </div>"
				+ "\n    </div>"
				+ "\n</div>"
				+ "\n</section>";

		return htmlString;
	}

	public static String getNewAddHtml(String dbName, String tableName,
			String formFields) {

		String htmlString = "<section>"
				+ "\n    <div class=\"container\" ng-controller=\"##TABLENAME_SINGULAR##Add\">"
				+ "\n        <div class=\"form-content\">"
				+ "\n                                        <!-- Form ##TABLENAME## Start-->                                                                "
				+ "\n            <form role=\"form\" class=\"clearfix\" enctype=\"multipart/form-data\" name=\"##TABLENAME##Add\" ng-submit=\"##TABLENAME##_create(##TABLENAME##.$valid)\" novalidate>"
				+ "\n                <div class=\"form-heading\">"
				+ "\n                    <h2><span>{{'Add ##TABLENAMECAPSPACE##'| translate}}</span></h2>"
				+ "\n                </div>"
				+ "\n                 "
				+ formFields
				+ ""
				+ "\n"
				+ "\n                <div class=\"form-footer education-btn\">"
				+ "\n                    <button class=\"btn btn-blue btn-animate wid-230 mr5\" type=\"submit\">{{'Create'| translate }}</button>"
				+ "\n                    <a href=\"#/##TABLENAME##\" class=\"btn btn-danger btn-animate wid-230\">{{'Cancel'| translate }}</a>"
				+ "\n                </div>"
				+ "\n"
				+ "\n            </form>"
				+ "\n                                        <!-- Form ##TABLENAMECAP## End-->                                                                "
				+ "\n        </div>" + "\n    </div>" + "\n</section>";

		return htmlString;
	}

	public static String getNewEditHtml(String dbName, String tableName,
			String formFields) {
		String htmlString = "<section>"
				+ "\n    <div class=\"container\" ng-controller=\"##TABLENAME_SINGULAR##Edit\">"
				+ "\n        <div class=\"form-content\">"
				+ "\n                                        <!-- Form ##TABLENAMECAP## Start-->                                                                "
				+ "\n            <form role=\"form\" class=\"clearfix\" enctype=\"multipart/form-data\" name=\"##TABLENAME##Update\" ng-submit=\"##TABLENAME##_update(##TABLENAME##.$valid)\" novalidate>"
				+ "\n                <div class=\"form-heading\">"
				+ "\n                    <h2><span>{{'Edit ##TABLENAMECAPSPACE##'| translate}}</span></h2>"
				+ "\n                </div>"
				+ "\n                 "
				+ formFields
				+ ""
				+ "\n"
				+ "\n                <div class=\"form-footer education-btn\">"
				+ "\n                    <button class=\"btn btn-blue btn-animate wid-230 mr5\" type=\"submit\">{{'Update'| translate }}</button>"
				+ "\n                    <a href=\"#/##TABLENAME##\" class=\"btn btn-danger btn-animate wid-230\">{{'Cancel'| translate }}</a>"
				+ "\n                </div>"
				+ "\n"
				+ "\n            </form>"
				+ "\n                                        <!-- Form ##TABLENAMECAP## End-->                                                                "
				+ "\n        </div>" + "\n    </div>" + "\n</section>";
		return htmlString;
	}

	public static String getNewViewHtml(String dbName, String tableName,
			String viewFields) {
		String htmlString = "<section>"
				+ "\n    <div class=\"container\" ng-controller=\"##TABLENAME_SINGULAR##View\">"
				+ "\n		<div class=\"panel panel-info\">"
				+ "\n			<div class=\"panel-heading\">"
				+ "\n				<h3 class=\"panel-title\">{{'##TABLENAMECAP## View Details'| translate}}</h3>"
				+ "\n			</div>"
				+ "\n		   <div class=\"panel-body\">"
				+ "\n			  <div class=\"row\">"
				+ "\n				<div class=\"col-md-3 col-lg-3 \" align=\"center\"> <img alt=\"User Pic\" src=\"http://babyinfoforyou.com/wp-content/uploads/2014/10/avatar-300x300.png\" class=\"img-circle img-responsive\"> </div>"
				+ "\n				<div class=\" col-md-9 col-lg-9 \">"
				+ "\n					<table class=\"table table-user-information\">"
				+ "\n					   <tbody>"
				+ viewFields
				+ "\n					   </tbody>"
				+ "\n					</table>"
				+ "\n				</div>"
				+ "\n			  </div>"
				+ "\n		   </div>"
				+ "\n		   <div class=\"panel-footer\">"
				+ "\n			  <span class=\"pull-right\">"
				+ "\n				  <a href=\"#/##TABLENAME##\" data-original-title=\"Cancel\" data-toggle=\"tooltip\" type=\"button\" class=\"btn btn-sm btn-warning\">{{'Cancel'| translate }}</a>"
				+ "\n				  <a href=\"#/##TABLENAMESINGLE##/edit/{{##TABLENAMESINGLE##.id}}\" data-original-title=\"Edit\" data-toggle=\"tooltip\" type=\"button\" class=\"btn btn-sm btn-warning\">{{'Edit'| translate }}</a>"
				+ "\n				  <a href=\"#/##TABLENAMESINGLE##/delete/{{##TABLENAMESINGLE##.id}}\" data-original-title=\"Remove\" data-toggle=\"tooltip\" type=\"button\" class=\"btn btn-sm btn-danger\">{{'Delete'| translate }}</a>"
				+ "\n			  </span>" + "\n		   </div>" + "\n		</div>"
				+ "\n    </div>" + "\n</section>";
		return htmlString;
	}

	public static String getAgAdminEntity(String tableName) {
		tableName = tableName.replaceAll(" ", "");
		String agAdminEntity = "\nvar " + tableName + " = nga.entity(\""
				+ tableName + "\");" + "\nadmin.addEntity(" + tableName
				+ ");\n";
		return agAdminEntity;
	}

	public static String getAgAdmin(String dbName, String tableName,
			String viewFields, String agAdminFields, String paramsString) {
		String agAdmin = "\n        ##TABLENAME##.listView()"
				+ "\n                .fields(["
				+ agAdminFields.substring(0, agAdminFields.length() - 1)
				+ "\n                ])"
				+ "\n                .listActions([\"show\", \"edit\", \"delete\"])"
				+ "\n                .filters(["
				+ "\n                    nga.field(\"q\").label(\"Search\")"
				+ "\n                            .pinned(true)"
				+ "\n                            .template('<div class=\"input-group\"><input type=\"text\" ng-model=\"value\" placeholder=\"Search\" class=\"form-control\"/><span class=\"input-group-addon\"><i class=\"glyphicon glyphicon-search text-primary\"></i></span></div>'),"
				+ "\n                    nga.field(\"filter\", \"choice\").label(\"Status\").attributes({"
				+ "\n                        placeholder: \"Select Status\""
				+ "\n                    })"
				+ "\n                    .choices([{"
				+ "\n                        label: \"Active\","
				+ "\n                        value: \"active\""
				+ "\n                    }, {"
				+ "\n                        label: \"Inactive\","
				+ "\n                        value: \"inactive\""
				+ "\n                    }, ])"
				+ "\n                ]);"
				+ "\n			/**"
				+ paramsString
				+ "\n			**/"
				+ "\n        ##TABLENAME##.creationView()"
				+ "\n                .fields(["
				+ viewFields.substring(0, viewFields.length() - 1)
				+ "\n                ])"
				+ "\n                .onSubmitSuccess([\"progression\", \"notification\", \"$state\", \"entry\", \"entity\", function (progression, notification, $state, entry, entity) {"
				+ "\n                        progression.done();"
				+ "\n                        notification.log(entry.values.Success, {addnCls: \"humane-flatty-success\"});"
				+ "\n                        $state.go($state.get(\"list\"), {entity: entity.name()});"
				+ "\n                        return false;"
				+ "\n                    }])"
				+ "\n                .onSubmitError([\"error\", \"form\", \"progression\", \"notification\", function (error, form, progression, notification) {"
				+ "\n                        var errors_string = \"Please check below things \";"
				+ "\n                        angular.forEach(error.data.errors, function (value, key) {"
				+ "\n                            if (this[key]) {"
				+ "\n                                this[key].$valid = false;"
				+ "\n                            }"
				+ "\n                            errors_string+= key+\" \"+value+\" \";"
				+ "\n                        }, form);"
				+ "\n                        progression.done();"
				+ "\n                        notification.log(error.data.message+errors_string, {addnCls: \"humane-flatty-error\"});"
				+ "\n                        return false;"
				+ "\n                    }]);"
				+ "\n			/**"
				+ paramsString
				+ "\n			**/"
				+ "\n        ##TABLENAME##.editionView()"
				+ "\n            .fields(["
				+ viewFields.substring(0, viewFields.length() - 1)
				+ "\n				])"
				+ "\n                .onSubmitSuccess([\"progression\", \"notification\", \"$state\", \"entry\", \"entity\", function (progression, notification, $state, entry, entity) {"
				+ "\n                        progression.done();"
				+ "\n                        notification.log(entry.values.Success, {addnCls: \"humane-flatty-success\"});"
				+ "\n                        $state.go($state.get(\"list\"), {entity: entity.name()});"
				+ "\n                        return false;"
				+ "\n                    }])"
				+ "\n                .onSubmitError([\"error\", \"form\", \"progression\", \"notification\", function (error, form, progression, notification) {"
				+ "\n                        angular.forEach(error.data.errors, function (value, key) {"
				+ "\n                            if (this[key]) {"
				+ "\n                                this[key].$valid = false;"
				+ "\n                            }"
				+ "\n                        }, form);"
				+ "\n                        progression.done();"
				+ "\n                        notification.log(error.data.message, {addnCls: \"humane-flatty-error\"});"
				+ "\n                        return false;"
				+ "\n                    }]);"
				+ "\n		##TABLENAME##.showView().title(\"Show Details\")"
				+ "\n                .fields(["
				+ agAdminFields.substring(0, agAdminFields.length() - 1)
				+ "\n                ]);";
		return agAdmin;
	}
}
