/**
* @package		bozehour
* @author 		VEL007
* @copyright 	Copyright (c) 2017 vel
* @license		cool
* @since 		2017.02.16 00.21.28
*/
/**
* @ngdoc Service
* @name images.Service:ImageService
* @description
* This is images Service.
**/
(function (module) {
						/**			Factory For List				**/
    module.factory("Images", function ($resource, GENERAL_CONFIG) {
        return $resource(GENERAL_CONFIG.api_url + "/images", {}, {
            "get": {
               method: "GET"
            }
        });
    });
						/**			Factory For Add				**/
    module.factory("ImageAdd", function ($resource, GENERAL_CONFIG) {
        return $resource(GENERAL_CONFIG.api_url + "/image/add", {}, {
            "save": {
                method: "POST"
            }
        });
    });
						/**			Factory For Edit				**/
    module.factory("ImageEdit", function ($resource, GENERAL_CONFIG) {
        return $resource(GENERAL_CONFIG.api_url + "/image/edit/:id", {}, {
            "get": {
                method: "GET"
            },
            "update":{
                method: "PUT"
            }
        });
    });
						/**			Factory For View				**/
    module.factory("ImageView", function ($resource, GENERAL_CONFIG) {
        return $resource(GENERAL_CONFIG.api_url + "/image/view/:id", {
                id: "@id"
            }, {
                "get": {
                    method: "GET"
                }
            }
        );
    });
					/**			Factory For Delete				**/
    module.factory("ImageDelete", function ($resource, GENERAL_CONFIG) {
        return $resource(GENERAL_CONFIG.api_url + "/image/:id", {
                id: "@id"
            }, {
                "delete": {
                    method: "DELETE"
                }
           }
        );
    });
 })(angular.module("LumenBase.Image"));