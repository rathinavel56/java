/**
* @package		bozehour
* @author 		VEL007
* @copyright 	Copyright (c) 2017 vel
* @license		cool
* @since 		2017.02.16 00.21.28
*/
/**
 * This is the authors module. It provides the service for the authors controller and it's methods
 *
 * The angular.module is a global place for creating, registering and update Angular modules.
 * All modules that should be available to an application must be registered using this mechanism.
 * Passing one argument retrieves an existing angular.Module, whereas passing more than one argument creates a new angular.Module
 *
 * @param {string} LumenBase.authors name of the module
 * @param {!Array.<string>=} dependencies If specified then new module is being created. If unspecified then the module is being retrieved for further configuration.
 *        [
 *            "ui.router",
 *            "ngResource",
 *            "ui.bootstrap"
 *        ]
 * @param {Function=} configFn Optional configuration function for the module.
 * @returns {angular.Module} new LumenBase.authors module with the angular.Module api.
 **/
(function (module) {
    module.config(function ($stateProvider) {
        var getToken = {
            "TokenServiceData": function (TokenService, $q) {
                return $q.all({
                    AuthServiceData: TokenService.promiseAuth,
                    SettingServiceData: TokenService.promiseSettings
                });
            }
        };
        $stateProvider.state("Authors", {
            url: "/authors",
            authenticate: true,
            views:{
                "main":{
                    controller: "AuthorController"
                    templateUrl: "authors/index.html"
                    resolve: getToken
                }
            }
        }).state("AuthorAdd", {
            url: "/author/add",
            authenticate: true,
            views: {
                "main": {
                    controller: "AuthorAddController",
                    templateUrl: "authors/add.html",
                    resolve: getToken
                }
            }
        }).state("AuthorEdit", {
            url: "/author/edit/{id}",
            authenticate: true,
            views: {
                "main": {
                    controller: "AuthorEditController",
                    templateUrl: "authors/edit.html",
                    resolve: getToken
                }
            }
        }).state("AuthorView", {
            url: "/author/view/:id",
            authenticate: true,
            views: {
                "main": {
                    controller: "AuthorViewController",
                    templateUrl: "authors/view.html",
                    resolve: getToken
                }
            }
        });
    });

    /** The name of the module, followed by its dependencies (at the bottom to facilitate enclosure) **/
}(angular.module("LumenBase.Author", [
    "ui.router",
    "ngResource",
    "ui.bootstrap",
    "naif.base64"
])));