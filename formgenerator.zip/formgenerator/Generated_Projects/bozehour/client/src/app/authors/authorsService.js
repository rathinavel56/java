/**
* @package		bozehour
* @author 		VEL007
* @copyright 	Copyright (c) 2017 vel
* @license		cool
* @since 		2017.02.16 00.21.28
*/
/**
* @ngdoc Service
* @name authors.Service:AuthorService
* @description
* This is authors Service.
**/
(function (module) {
						/**			Factory For List				**/
    module.factory("Authors", function ($resource, GENERAL_CONFIG) {
        return $resource(GENERAL_CONFIG.api_url + "/authors", {}, {
            "get": {
               method: "GET"
            }
        });
    });
						/**			Factory For Add				**/
    module.factory("AuthorAdd", function ($resource, GENERAL_CONFIG) {
        return $resource(GENERAL_CONFIG.api_url + "/author/add", {}, {
            "save": {
                method: "POST"
            }
        });
    });
						/**			Factory For Edit				**/
    module.factory("AuthorEdit", function ($resource, GENERAL_CONFIG) {
        return $resource(GENERAL_CONFIG.api_url + "/author/edit/:id", {}, {
            "get": {
                method: "GET"
            },
            "update":{
                method: "PUT"
            }
        });
    });
						/**			Factory For View				**/
    module.factory("AuthorView", function ($resource, GENERAL_CONFIG) {
        return $resource(GENERAL_CONFIG.api_url + "/author/view/:id", {
                id: "@id"
            }, {
                "get": {
                    method: "GET"
                }
            }
        );
    });
					/**			Factory For Delete				**/
    module.factory("AuthorDelete", function ($resource, GENERAL_CONFIG) {
        return $resource(GENERAL_CONFIG.api_url + "/author/:id", {
                id: "@id"
            }, {
                "delete": {
                    method: "DELETE"
                }
           }
        );
    });
 })(angular.module("LumenBase.Author"));