/**
* @package		bozehour
* @author 		VEL007
* @copyright 	Copyright (c) 2017 vel
* @license		cool
* @since 		2017.02.16 00.21.28
*/
(function (module) {
		/**
     	* @ngdoc controller
     	* @name bozehourApp.controller:TestingViewController
     	* @description
     	* # TestingController
     	* controller of the bozehour
     	**/
    	module.controller("TestingViewController", ["$scope", "$filter", "$state", "$location", "Flash", "TestingView", function ($scope, $filter, $state, $location, Flash, TestingView) {
        	var model = this;
        	/**
         	* @ngdoc method
         	* @name setMetaData
         	* @methodOf testing.controller:TestingController
         	* @description
         	* This method will set the meta data dynamically by using the angular.element function.
         	* It defines the angular elements
         	**/
        	model.setMetaData = function () {
				var pageTitle = $filter("translate")("Testing"),
					fullUrl  = $location.absUrl(),
					appUrl   = $rootScope.settings["scheme_name"] + ":/" + $location.url(),
					metaData = "meta[property='al:ios:url'],"
								+"meta[property='al:ipad:url'],"
								+"meta[property='al:android:url'],"
								+"meta[property='al:windows_phone:url'],"
								+"html head meta[name='twitter:app:url:iphone'],"
								+"html head meta[name='twitter:app:url:ipad'],"
								+"html head meta[name='twitter:app:url:googleplay']";

            	angular.element("html head meta[property='og:title'], html head meta[name='twitter:title']").attr("content", $rootScope.settings["site.name"] + " | " + pageTitle);
            	angular.element(metaData).attr("content", appUrl);
            	angular.element("meta[property='og:url']").attr("content", fullUrl);
        	};
        
        	/**
         	* @ngdoc method
         	* @name init
         	* @methodOf testing.controller:TestingController
         	* @description
         	* This method will initialze the page. It returns the page title.
         	**/
        	model.init = function () {
				model.setMetaData();
				$rootScope.pageTitle = $rootScope.settings["site.name"] + " | " + $filter("translate")("Testing");
        	}; 
		
			/**
        	* @ngdoc method
         	* @name view
         	* @methodOf testing.controller:TestingController
         	* @description
         	* This method for View testing
         	**/
        	var params = {
				id: $state.params.id,
				page: $scope.currentPage
			};
			Testingview.get({id: $state.params.id}).$promise.then(function (response) {
            	model.Testingview = response.testing;
        	});
		
		}]);
		
}(angular.module("LumenBase.testing")));