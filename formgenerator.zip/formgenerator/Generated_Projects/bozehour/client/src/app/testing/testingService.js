/**
* @package		bozehour
* @author 		VEL007
* @copyright 	Copyright (c) 2017 vel
* @license		cool
* @since 		2017.02.16 00.21.28
*/
/**
* @ngdoc Service
* @name testing.Service:TestingService
* @description
* This is testing Service.
**/
(function (module) {
						/**			Factory For List				**/
    module.factory("Testing", function ($resource, GENERAL_CONFIG) {
        return $resource(GENERAL_CONFIG.api_url + "/testing", {}, {
            "get": {
               method: "GET"
            }
        });
    });
						/**			Factory For Add				**/
    module.factory("TestingAdd", function ($resource, GENERAL_CONFIG) {
        return $resource(GENERAL_CONFIG.api_url + "/testing/add", {}, {
            "save": {
                method: "POST"
            }
        });
    });
						/**			Factory For Edit				**/
    module.factory("TestingEdit", function ($resource, GENERAL_CONFIG) {
        return $resource(GENERAL_CONFIG.api_url + "/testing/edit/:id", {}, {
            "get": {
                method: "GET"
            },
            "update":{
                method: "PUT"
            }
        });
    });
						/**			Factory For View				**/
    module.factory("TestingView", function ($resource, GENERAL_CONFIG) {
        return $resource(GENERAL_CONFIG.api_url + "/testing/view/:id", {
                id: "@id"
            }, {
                "get": {
                    method: "GET"
                }
            }
        );
    });
					/**			Factory For Delete				**/
    module.factory("TestingDelete", function ($resource, GENERAL_CONFIG) {
        return $resource(GENERAL_CONFIG.api_url + "/testing/:id", {
                id: "@id"
            }, {
                "delete": {
                    method: "DELETE"
                }
           }
        );
    });
 })(angular.module("LumenBase.Testing"));