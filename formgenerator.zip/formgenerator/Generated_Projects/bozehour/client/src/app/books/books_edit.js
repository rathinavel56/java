/**
* @package		bozehour
* @author 		VEL007
* @copyright 	Copyright (c) 2017 vel
* @license		cool
* @since 		2017.02.16 00.21.28
*/
(function (module) {
		/**
     	* @ngdoc controller
     	* @name bozehourApp.controller:BookEditController
     	* @description
     	* # BookController
     	* controller of the bozehour
    	**/
    	module.controller("BookViewController", ["$scope", "$filter", "$state", "$location", "Flash", "BookEdit", "Author", function ($scope, $filter, $state, $location, Flash, BookEdit, Author) {
        	var model = this;
        	/**
         	* @ngdoc method
         	* @name setMetaData
         	* @methodOf books.controller:BookController
         	* @description
         	* This method will set the meta data dynamically by using the angular.element function.
         	* It defines the angular elements
         	**/
        	model.setMetaData = function () {
				var pageTitle = $filter("translate")("Book"),
					fullUrl  = $location.absUrl(),
					appUrl   = $rootScope.settings["scheme_name"] + ":/" + $location.url(),
					metaData = "meta[property='al:ios:url'],"
								+"meta[property='al:ipad:url'],"
								+"meta[property='al:android:url'],"
								+"meta[property='al:windows_phone:url'],"
								+"html head meta[name='twitter:app:url:iphone'],"
								+"html head meta[name='twitter:app:url:ipad'],"
								+"html head meta[name='twitter:app:url:googleplay']";

            	angular.element("html head meta[property='og:title'], html head meta[name='twitter:title']").attr("content", $rootScope.settings["site.name"] + " | " + pageTitle);
            	angular.element(metaData).attr("content", appUrl);
            	angular.element("meta[property='og:url']").attr("content", fullUrl);
        	};	/**
			* Foreign Key Data
			**/
			Author.get().$promise.then(function (response) {
         		$scope.authors = response.data;
         	});
        
			/**
         	* @ngdoc method
         	* @name edit
         	* @methodOf books.controller:BookController
         	* @description
         	* This method for Edit books
       	  	 * @param  id { INTEGER } 
       	  	 * @param  author_id { INTEGER } action Required
       	  	 * @param  title { CHARACTER VARYING } action Required
         	**/
	     	BookEdit.get({id: $state.params.id}).$promise.then(function (response) {
         		model.BookEdit = response.books;
         	});
         	$scope.Book_update = function () {
         		BookEdit.update({id: $state.params.id}, model.books).$promise.then(function (response) {
            		Flash.set($filter("translate")(response.Success), "success", true);
                	$state.go("Book");
           		});
         	};
		
		}]);
		
}(angular.module("LumenBase.books")));