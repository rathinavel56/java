/**
* @package		bozehour
* @author 		VEL007
* @copyright 	Copyright (c) 2017 vel
* @license		cool
* @since 		2017.02.16 00.21.28
*/
/**
 * This is the books module. It provides the service for the books controller and it's methods
 *
 * The angular.module is a global place for creating, registering and update Angular modules.
 * All modules that should be available to an application must be registered using this mechanism.
 * Passing one argument retrieves an existing angular.Module, whereas passing more than one argument creates a new angular.Module
 *
 * @param {string} LumenBase.books name of the module
 * @param {!Array.<string>=} dependencies If specified then new module is being created. If unspecified then the module is being retrieved for further configuration.
 *        [
 *            "ui.router",
 *            "ngResource",
 *            "ui.bootstrap"
 *        ]
 * @param {Function=} configFn Optional configuration function for the module.
 * @returns {angular.Module} new LumenBase.books module with the angular.Module api.
 **/
(function (module) {
    module.config(function ($stateProvider) {
        var getToken = {
            "TokenServiceData": function (TokenService, $q) {
                return $q.all({
                    AuthServiceData: TokenService.promiseAuth,
                    SettingServiceData: TokenService.promiseSettings
                });
            }
        };
        $stateProvider.state("Books", {
            url: "/books",
            authenticate: true,
            views:{
                "main":{
                    controller: "BookController"
                    templateUrl: "books/index.html"
                    resolve: getToken
                }
            }
        }).state("BookAdd", {
            url: "/book/add",
            authenticate: true,
            views: {
                "main": {
                    controller: "BookAddController",
                    templateUrl: "books/add.html",
                    resolve: getToken
                }
            }
        }).state("BookEdit", {
            url: "/book/edit/{id}",
            authenticate: true,
            views: {
                "main": {
                    controller: "BookEditController",
                    templateUrl: "books/edit.html",
                    resolve: getToken
                }
            }
        }).state("BookView", {
            url: "/book/view/:id",
            authenticate: true,
            views: {
                "main": {
                    controller: "BookViewController",
                    templateUrl: "books/view.html",
                    resolve: getToken
                }
            }
        });
    });

    /** The name of the module, followed by its dependencies (at the bottom to facilitate enclosure) **/
}(angular.module("LumenBase.Book", [
    "ui.router",
    "ngResource",
    "ui.bootstrap",
    "naif.base64"
])));