/**
* @package		bozehour
* @author 		VEL007
* @copyright 	Copyright (c) 2017 vel
* @license		cool
* @since 		2017.02.16 00.21.28
*/
/**
* @ngdoc Service
* @name books.Service:BookService
* @description
* This is books Service.
**/
(function (module) {
						/**			Factory For List				**/
    module.factory("Books", function ($resource, GENERAL_CONFIG) {
        return $resource(GENERAL_CONFIG.api_url + "/books", {}, {
            "get": {
               method: "GET"
            }
        });
    });
						/**			Factory For Add				**/
    module.factory("BookAdd", function ($resource, GENERAL_CONFIG) {
        return $resource(GENERAL_CONFIG.api_url + "/book/add", {}, {
            "save": {
                method: "POST"
            }
        });
    });
						/**			Factory For Edit				**/
    module.factory("BookEdit", function ($resource, GENERAL_CONFIG) {
        return $resource(GENERAL_CONFIG.api_url + "/book/edit/:id", {}, {
            "get": {
                method: "GET"
            },
            "update":{
                method: "PUT"
            }
        });
    });
						/**			Factory For View				**/
    module.factory("BookView", function ($resource, GENERAL_CONFIG) {
        return $resource(GENERAL_CONFIG.api_url + "/book/view/:id", {
                id: "@id"
            }, {
                "get": {
                    method: "GET"
                }
            }
        );
    });
					/**			Factory For Delete				**/
    module.factory("BookDelete", function ($resource, GENERAL_CONFIG) {
        return $resource(GENERAL_CONFIG.api_url + "/book/:id", {
                id: "@id"
            }, {
                "delete": {
                    method: "DELETE"
                }
           }
        );
    });
 })(angular.module("LumenBase.Book"));