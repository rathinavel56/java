/**
* @package		bozehour
* @author 		VEL007
* @copyright 	Copyright (c) 2017 vel
* @license		cool
* @since 		2017.02.16 00.21.29
*/
/**
 * This is the amenities module. It provides the service for the amenities controller and it's methods
 *
 * The angular.module is a global place for creating, registering and update Angular modules.
 * All modules that should be available to an application must be registered using this mechanism.
 * Passing one argument retrieves an existing angular.Module, whereas passing more than one argument creates a new angular.Module
 *
 * @param {string} LumenBase.amenities name of the module
 * @param {!Array.<string>=} dependencies If specified then new module is being created. If unspecified then the module is being retrieved for further configuration.
 *        [
 *            "ui.router",
 *            "ngResource",
 *            "ui.bootstrap"
 *        ]
 * @param {Function=} configFn Optional configuration function for the module.
 * @returns {angular.Module} new LumenBase.amenities module with the angular.Module api.
 **/
(function (module) {
    module.config(function ($stateProvider) {
        var getToken = {
            "TokenServiceData": function (TokenService, $q) {
                return $q.all({
                    AuthServiceData: TokenService.promiseAuth,
                    SettingServiceData: TokenService.promiseSettings
                });
            }
        };
        $stateProvider.state("Amenities", {
            url: "/amenities",
            authenticate: true,
            views:{
                "main":{
                    controller: "AmenityController"
                    templateUrl: "amenities/index.html"
                    resolve: getToken
                }
            }
        }).state("AmenityAdd", {
            url: "/amenity/add",
            authenticate: true,
            views: {
                "main": {
                    controller: "AmenityAddController",
                    templateUrl: "amenities/add.html",
                    resolve: getToken
                }
            }
        }).state("AmenityEdit", {
            url: "/amenity/edit/{id}",
            authenticate: true,
            views: {
                "main": {
                    controller: "AmenityEditController",
                    templateUrl: "amenities/edit.html",
                    resolve: getToken
                }
            }
        }).state("AmenityView", {
            url: "/amenity/view/:id",
            authenticate: true,
            views: {
                "main": {
                    controller: "AmenityViewController",
                    templateUrl: "amenities/view.html",
                    resolve: getToken
                }
            }
        });
    });

    /** The name of the module, followed by its dependencies (at the bottom to facilitate enclosure) **/
}(angular.module("LumenBase.Amenity", [
    "ui.router",
    "ngResource",
    "ui.bootstrap",
    "naif.base64"
])));