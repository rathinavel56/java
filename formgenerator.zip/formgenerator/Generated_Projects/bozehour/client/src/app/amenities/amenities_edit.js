/**
* @package		bozehour
* @author 		VEL007
* @copyright 	Copyright (c) 2017 vel
* @license		cool
* @since 		2017.02.16 00.21.29
*/
(function (module) {
		/**
     	* @ngdoc controller
     	* @name bozehourApp.controller:AmenityEditController
     	* @description
     	* # AmenityController
     	* controller of the bozehour
    	**/
    	module.controller("AmenityViewController", ["$scope", "$filter", "$state", "$location", "Flash", "AmenityEdit", function ($scope, $filter, $state, $location, Flash, AmenityEdit) {
        	var model = this;
        	/**
         	* @ngdoc method
         	* @name setMetaData
         	* @methodOf amenities.controller:AmenityController
         	* @description
         	* This method will set the meta data dynamically by using the angular.element function.
         	* It defines the angular elements
         	**/
        	model.setMetaData = function () {
				var pageTitle = $filter("translate")("Amenity"),
					fullUrl  = $location.absUrl(),
					appUrl   = $rootScope.settings["scheme_name"] + ":/" + $location.url(),
					metaData = "meta[property='al:ios:url'],"
								+"meta[property='al:ipad:url'],"
								+"meta[property='al:android:url'],"
								+"meta[property='al:windows_phone:url'],"
								+"html head meta[name='twitter:app:url:iphone'],"
								+"html head meta[name='twitter:app:url:ipad'],"
								+"html head meta[name='twitter:app:url:googleplay']";

            	angular.element("html head meta[property='og:title'], html head meta[name='twitter:title']").attr("content", $rootScope.settings["site.name"] + " | " + pageTitle);
            	angular.element(metaData).attr("content", appUrl);
            	angular.element("meta[property='og:url']").attr("content", fullUrl);
        	};
        
			/**
         	* @ngdoc method
         	* @name edit
         	* @methodOf amenities.controller:AmenityController
         	* @description
         	* This method for Edit amenities
       	  	 * @param  id { BIGINT } 
       	  	 * @param  created_at { TIMESTAMP WITHOUT TIME ZONE } 
       	  	 * @param  updated_at { TIMESTAMP WITHOUT TIME ZONE } 
       	  	 * @param  name { CHARACTER VARYING } 
         	**/
	     	AmenityEdit.get({id: $state.params.id}).$promise.then(function (response) {
         		model.AmenityEdit = response.amenities;
         	});
         	$scope.Amenity_update = function () {
         		AmenityEdit.update({id: $state.params.id}, model.amenities).$promise.then(function (response) {
            		Flash.set($filter("translate")(response.Success), "success", true);
                	$state.go("Amenity");
           		});
         	};
		
		}]);
		
}(angular.module("LumenBase.amenities")));