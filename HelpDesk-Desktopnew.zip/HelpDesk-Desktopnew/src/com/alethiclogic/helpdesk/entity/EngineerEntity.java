package com.alethiclogic.helpdesk.entity;

public class EngineerEntity {
	private String engineerId;
	private String engineerName;
	private String engineerlogin;
	private String engineerlastlogin;
	
	public EngineerEntity(String engineerId, String engineerName,String engineerlogin,String engineerlastlogin) {
		super();
		this.engineerId = engineerId;
		this.engineerName = engineerName;
		this.engineerlogin = engineerlogin;
		this.engineerlastlogin= engineerlastlogin;
	}
	
	public String getEngineer()
	{
		return engineerId;
	}
	
	public String getEngineerlogin() {
		return engineerlogin;
	}

	public String getEngineerlastlogin() {
		return engineerlastlogin;
	}

	public String toString()
	{
		return engineerName;
	}
}
