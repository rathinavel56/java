package com.alethiclogic.helpdesk.entity;

public class UserEntity
{
	
private String id;
private String fname;
private String lname;
private String username;
private String department;



private boolean bool=false;


public String getFname() {
	return fname;
}
public void setFname(String fname) {
	this.fname = fname;
}
public String getLname() {
	return lname;
}
public void setLname(String lname) {
	this.lname = lname;
}

public boolean isBool() {
	return bool;
}
public void setBool(boolean bool) {
	this.bool = bool;
}

public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getDepartment() {
	return department;
}
public void setDepartment(String department) {
	this.department = department;
}
public Object[] getuserdetails()
{
	Object[] temp=new Object[5];
	
	temp[0]=id;
	temp[1]=fname +" "+ lname;
	temp[2]=username;
	temp[3]=department;
	temp[4]=bool;
	return temp;
}

public String toString()
{
	return username;
}

}