package com.alethiclogic.helpdesk.ui;

import com.sun.xml.internal.bind.v2.model.core.ID;

public class UIhelperareaEntity

{
String id;
String name;

	public UIhelperareaEntity()
	{
	
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @param args
	 */
	public Object[] getareadetails()
	{
		Object[] temp=new Object[2];
		
		temp[0]=id;
		temp[1]=name;
		
		return temp;
	}
	public String toString()
	{
		return name;
		
	}

}
