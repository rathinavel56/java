package com.alethiclogic.helpdesk.ui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;

import sun.print.BackgroundLookupListener;

public class JobPanel extends JPanel
{
	private JLabel categoryLabel;
	private JLabel timeLabel;
	private JLabel customerLabel;
	private JLabel addressLabel;
	private JLabel codeLabel;
	private JLabel statusLabel;
	
	private String jobNo;
	private String jobId;
	
	private String jobDetails;
	
	
	public JobPanel(String jobDetails)
	{
		this.jobDetails = jobDetails;
		
		String[] detailArray = jobDetails.split("\\|");
		
		jobId = detailArray[0];
		jobNo = detailArray[1];
		
		categoryLabel = new JLabel(detailArray[2]);
		timeLabel = new JLabel(detailArray[3]);
		customerLabel = new JLabel(detailArray[6]);
		addressLabel = new JLabel(detailArray[4]);
		codeLabel = new JLabel("Code : " + detailArray[7]);
		statusLabel = new JLabel(detailArray[5]);
		
		setLayout(new GridLayout(0, 2));
		
		categoryLabel.setForeground(new Color(52, 152, 219));
		
		add(categoryLabel);
		add(timeLabel);
		add(addressLabel);
		add(statusLabel);
		add(customerLabel);
		add(codeLabel);
		
		
		
		
		setSize(220, 50);
		setPreferredSize(new Dimension(220, 50));
		setMinimumSize(new Dimension(220, 50));
		setMaximumSize(new Dimension(220, 50));
		setBorder(BorderFactory.createRaisedBevelBorder());
		setBackground(Color.white);
		setForeground(Color.black);
		
	}
	public String getJobNo() {
		return jobNo;
	}

	public void setJobNo(String jobNo) {
		this.jobNo = jobNo;
	}
	
	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}
	
	public void select(boolean selected)
	{
		if (selected)
		{
			setBackground(new Color(236, 233, 216));
			setForeground(Color.WHITE);
		}
		else
		{
			setBackground(Color.white);
			setForeground(Color.black);
		}
		
		updateUI();
	}
}
