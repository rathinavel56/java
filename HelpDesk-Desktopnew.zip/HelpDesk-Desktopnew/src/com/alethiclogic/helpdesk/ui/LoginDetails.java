package com.alethiclogic.helpdesk.ui;

public class LoginDetails {
	
	private static String userName;
	
	public static String getUserName()
	{
		return userName;
	}
	
	public static void setUserName(String userName)
	{
		LoginDetails.userName = userName;
	}
}
