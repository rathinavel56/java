package com.alethiclogic.helpdesk.ui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.ScrollPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

public class Attachnotes extends JDialog implements ActionListener
{
	private JPanel mainpanel = new JPanel(new BorderLayout());
	private JPanel emptypanel = new JPanel(new BorderLayout());
	private JPanel centerpanel = new JPanel(new BorderLayout());
	private JPanel center = new JPanel(new GridLayout());
	private JPanel southpanel = new JPanel(new BorderLayout());
	private JPanel southpanel1 = new JPanel(new BorderLayout());
	private JPanel emptypanel1 = new JPanel(new BorderLayout());

	private JTextArea txtarea = new JTextArea();
	private JButton butsearch = new JButton("Add");
	private int stat;
	private String tid;
	
	private JPanel holderPanel;
	
	public Attachnotes(int stat,String tid, JPanel holderPanel)
	{
		
		this.stat=stat;
		this.tid=tid;
		this.holderPanel = holderPanel;

		//txtarea.setPreferredSize(new Dimension(300,200));
		//butsearch.setPreferredSize(new Dimension(150,50));
		mainpanel.setPreferredSize(new Dimension(370,150));
		emptypanel.setPreferredSize(new Dimension(50,50));
		emptypanel1.setPreferredSize(new Dimension(150,50));
		centerpanel.setPreferredSize(new Dimension(370,150));
		southpanel.setPreferredSize(new Dimension(150,25));
		southpanel1.setPreferredSize(new Dimension(150,25));

		center.add(new JScrollPane(txtarea));
		
		centerpanel.add(center,BorderLayout.CENTER);
		southpanel.add(emptypanel1,BorderLayout.CENTER);
		southpanel1.add(butsearch,BorderLayout.SOUTH);
		southpanel.add(southpanel1,BorderLayout.EAST);
		mainpanel.add(emptypanel, BorderLayout.NORTH);
		mainpanel.add(centerpanel, BorderLayout.CENTER);
		mainpanel.add(southpanel, BorderLayout.SOUTH);
		
		butsearch.addActionListener(this);

		this.add(mainpanel);
		this.setSize(450, 200);
		this.setVisible(true);

	}

	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource().equals(butsearch))
		{
			try
			{

				String url = UIHelper.base + "query/javainsertnotes.php";
				
				HttpClient client = new DefaultHttpClient();
				HttpPost post = new HttpPost(url);
							
				List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
				
				nameValuePairs.add(new BasicNameValuePair("txthid",tid));
				nameValuePairs.add(new BasicNameValuePair("txtuser",UIHelper.getUser()));
				nameValuePairs.add(new BasicNameValuePair("txtdetail",txtarea.getText()));
				
				post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse response = client.execute(post);
				BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
				
				String line = "";
				
				while ((line = rd.readLine()) != null) 
				{
					System.out.println(line);
				}
				
				this.hide();
				
				holderPanel.removeAll();
				holderPanel.add(new JScrollPane(UIHelper.getJobDetails(stat, tid, holderPanel)));
				holderPanel.updateUI();
			}
			catch (Exception e11) 
			{
				e11.printStackTrace();
			}
		}
	}

		

}
