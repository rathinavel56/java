package com.alethiclogic.helpdesk.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class AttachmentPanel extends JPanel implements MouseListener
{
	private String fileId;
	private String fileName;
	
	private String base;
	
	public AttachmentPanel(String noteDetails, String base)
	{
		setLayout(new BorderLayout(10, 10));
		
		String[] noteArr = noteDetails.split("\\|");
		
		if (noteArr.length == 5)
		{
			this.fileId = noteArr[0];
			this.fileName = noteArr[4];
			
			this.base = base; 
			
			JPanel northPanel = new JPanel(new GridLayout(1, 2));
			
			JLabel userLabel = new JLabel(noteArr[2]);
			JLabel timeLabel = new JLabel(noteArr[3]);
			
			JLabel fileLabel = new JLabel(noteArr[4]);
			
			//northPanel.add(userLabel);
			//northPanel.add(timeLabel);
			
			timeLabel.setBackground(Color.white);
			
			JLabel viewLabel = new JLabel("View");
			viewLabel.setForeground(new Color(52,152,219));
			viewLabel.setBackground(Color.white);
			
			JLabel imageLabel = new JLabel(" Image");
			imageLabel.setBackground(Color.white);
			
			add(imageLabel, BorderLayout.WEST);
			add(timeLabel, BorderLayout.CENTER);
			add(viewLabel, BorderLayout.EAST);
			//add(fileLabel, BorderLayout.CENTER);
			
			addMouseListener(this);
			
			setBackground(Color.white);
			
			setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
			setPreferredSize(new Dimension(250, 45));
		}
	}

	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseClicked(java.awt.event.MouseEvent)
	 */
	@Override
	public void mouseClicked(MouseEvent e) {
		if (fileId != null && fileName != null)
		{
			String url = base + "query/upload/" + fileId + "_" + fileName;
			try {
				Desktop.getDesktop().browse(new URI(url));
			} catch (Exception e1) {
				e1.printStackTrace();
				JOptionPane.showMessageDialog(this, "Unable to open the uploaded image.");
			}
		}
	}

	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mousePressed(java.awt.event.MouseEvent)
	 */
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseReleased(java.awt.event.MouseEvent)
	 */
	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseEntered(java.awt.event.MouseEvent)
	 */
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseExited(java.awt.event.MouseEvent)
	 */
	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}
