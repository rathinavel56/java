package com.alethiclogic.helpdesk.ui;

public class CategoryEntity
{
	
private String id;
private String catname;
private boolean bool=false;


public CategoryEntity(String id, String catname) {
	super();
	this.id = id;
	this.catname = catname;
}

public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public boolean isBool() {
	return bool;
}
public void setBool(boolean bool) {
	this.bool = bool;
}
public String getCatname() {
	return catname;
}
public void setCatname(String catname) {
	this.catname = catname;
}


public Object[] getcatdetails()
{
	Object[] temp=new Object[3];
	
	temp[0]=id;
	temp[1]=catname;
	temp[2]=bool;
	return temp;
}


public String toString()
{
	return catname;
}

}

