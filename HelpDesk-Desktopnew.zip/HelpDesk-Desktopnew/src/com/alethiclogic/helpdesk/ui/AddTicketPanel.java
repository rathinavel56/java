package com.alethiclogic.helpdesk.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.border.TitledBorder;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import com.alethiclogic.customerentity;

public class AddTicketPanel extends JPanel implements ActionListener {

	private JPanel mainpanel =UIHelper.getBoxPanel(new BorderLayout(), Color.white,Color.black);

	private JPanel addmainpanel = UIHelper.getBoxPanel(new BorderLayout(),Color.white,Color.black);
	private JPanel mainnorthpanel = UIHelper.getBoxPanel(new BorderLayout(),Color.white,Color.black);

	public customerentity customer = new customerentity();

	private JPanel northpanel = UIHelper.getBoxPanel(new GridLayout(1, 2),new Color(236,233,216),Color.black);
	private JPanel northpanel1 = UIHelper.getBoxPanel(null,Color.white,Color.black);
	private JPanel northpanel2 = UIHelper.getBoxPanel(null, Color.white, Color.white);
	
	private JPanel centerpanel = UIHelper.getBoxPanel(new GridLayout(1, 2), Color.white,Color.black);

	private JPanel southpanel = UIHelper.getBoxPanel(new GridLayout(1, 2),Color.white,Color.black);
	private JPanel southpanela = UIHelper.getBoxPanel(null, Color.white, Color.black);
	private JPanel southpanelb = UIHelper.getBoxPanel(null, Color.white, Color.black);
	//private JPanel southpanelc = UIHelper.getBoxPanel(null, Color.white, Color.white);

	private JPanel centerpanel1 = UIHelper.getBoxPanel(new GridLayout(1, 2),Color.white,Color.black);
	private JPanel centerpanel1a = UIHelper.getBoxPanel(null,  Color.white, Color.black);
	private JPanel centerpanel1b = UIHelper.getBoxPanel(null,  Color.white, Color.black);

	private JPanel centerpanel2 = UIHelper.getBoxPanel(null, Color.white, Color.black);

	//
	private JLabel lstreet = new JLabel("Street");
	private JTextField tstreet = new JTextField();
	private JLabel lpostcode = new JLabel("Postcode");
	private JTextField tpostcode = new JTextField();
	private JLabel lfirstname = new JLabel("First Name");
	private JTextField tfirstname = new JTextField();
	private JLabel llastname = new JLabel("Last Name");
	private JTextField tlastname = new JTextField();
	private JLabel lempty = new JLabel();
	private JLabel lemptyeast = new JLabel();
	private JButton butfindcustomer = new JButton("Find Customer");
	private JComboBox ampm=new JComboBox();

	// Add Ticket
	
	

	private JLabel ldate = new JLabel("Date");
	private JLabel ldatelabel = new JLabel();
	private JLabel ltime = new JLabel("Time");
	private JLabel ltimelabel = new JLabel();

	private JLabel lfirstnameticket = new JLabel("First Name");
	private JTextField tfirstnameticket = new JTextField();
	private JLabel llastnameticket = new JLabel("Last Name");
	private JTextField tlastnameticket = new JTextField();
	private JLabel lhouse = new JLabel("House/Flat");
	private JTextField thouse = new JTextField();
	private JLabel lstreetticket = new JLabel("Street");
	private JTextField tstreetticket = new JTextField();
	private JLabel ltowmticket = new JLabel("Town");
	private JTextField ttowmticket = new JTextField();
	private JLabel lcityticket = new JLabel("City");
	private JTextField tcityticket = new JTextField();
	private JLabel lpostcodeticket = new JLabel("Postcode");
	private JTextField tpostcodeticket = new JTextField();
	private JLabel llandlineticket = new JLabel("Landline");
	private JTextField tlandlineticket = new JTextField();
	private JLabel lmobileticket = new JLabel("Mobile");
	private JTextField tmobileticket = new JTextField();
	private JLabel lcodeticket = new JLabel("Code");
	private JComboBox tcodeticket = new JComboBox();
	private JLabel lcatagoryticket = new JLabel("Category");
	
	
	private JLabel empty=new JLabel();
	private JLabel empty1=new JLabel();
	private JLabel empty2=new JLabel();
	private JLabel empty3=new JLabel();
	

	private JComboBox combocatagoryticket;
	private Vector<CategoryEntity> catvector = new Vector<CategoryEntity>();

	private JLabel lappointmentdate = new JLabel("AppointmentDate");
	private XDateChooser appdate = new XDateChooser(new Date());
	private JLabel lpropertydetailticket = new JLabel("Property Details");
	private JTextField tpropertydetailticket = new JTextField();
	private JLabel lstatusticket = new JLabel("Status");
	private JLabel combostatus = new JLabel("Open");
	private JLabel lpriorityticket = new JLabel("Priority");
	private JComboBox combopriority = new JComboBox();

	private JLabel lareaticket = new JLabel("Area");
	private JComboBox comboarea;
	private String cid = "";

	private JLabel lreportedbyticket = new JLabel("Reported by");
	private JTextField treportedbyticket = new JTextField();
	private JLabel lworkdetails = new JLabel("Work Details");
	private JTextArea workdetailsarea = new JTextArea();
	private JLabel ladditionalnotes = new JLabel("Additional Notes");
	private JTextArea areaadditional = new JTextArea();
	private JLabel lworkorderno = new JLabel("Work Order Number");
	private JTextField tworkorderno = new JTextField();
	private JLabel lprpdetails = new JLabel("Property Details");
	private JTextArea prparea = new JTextArea();
	private JPanel north1 = UIHelper.getBoxPanel(null, Color.white, Color.black);
	private JPanel summaryPanelHolder = UIHelper.getBoxPanel(new GridLayout(),new Color(52,152,219),Color.black);
	private JButton butsubmit = new JButton("Submit Ticket");
	private JLabel emptybuttonlabel = new JLabel();

	private JLabel lreportbyticket = new JLabel("Reported By");
	private JComboBox comboreport;
	private JLabel lassignticket = new JLabel("Assign To");
	private JComboBox comboassign = new JComboBox();
	private JLabel lrechartticket = new JLabel("Area");
	private JCheckBox chkrecharge = new JCheckBox("Recharge");

	private String sstreet;
	private String spostcode;
	private String sfirstname;
	private String slastname;

	private Vector<customerentity> custvector = new Vector<customerentity>();

	private Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();

	public AddTicketPanel() {

		int width = (int) dimension.getWidth();
		int height = (int) dimension.getHeight();

		northpanel1.setLayout(new BoxLayout(northpanel1, BoxLayout.PAGE_AXIS));
		northpanel2.setLayout(new BoxLayout(northpanel2, BoxLayout.PAGE_AXIS));
		
		tcodeticket.addItem("1");
		tcodeticket.addItem("2");
		tcodeticket.addItem("3");
		tcodeticket.addItem("4");
		tcodeticket.addItem("5");
		
		tcodeticket.setSelectedIndex(0);
		
		combopriority.addItem("Low");
		combopriority.addItem("Medium");
		combopriority.addItem("High");
		
		combopriority.setSelectedItem("Medium");
		
		comboassign.addItem("Axiom");
		comboassign.addItem("Garfields");
		
		comboassign.setSelectedItem("Axiom");


		Component box_1 = Box.createRigidArea(new Dimension(200, 10));
		Box box_2 = Box.createHorizontalBox();
		Component box_3 = Box.createRigidArea(new Dimension(200, 10));
		Box box_4 = Box.createHorizontalBox();
		Component box_5 = Box.createRigidArea(new Dimension(200, 10));
		Box box_6 = Box.createHorizontalBox();
		Component box_7 = Box.createRigidArea(new Dimension(200, 10));
		Box box_8 = Box.createHorizontalBox();
		Component box_9 = Box.createRigidArea(new Dimension(200, 10));
		Box box_10 = Box.createHorizontalBox();

		box_2.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox2 = UIHelper.getBoxPanel(new BorderLayout(),new Color(236,233,216),Color.black);
		lstreet.setPreferredSize(new Dimension(150, 25));
		lstreet.setMaximumSize(new Dimension(150, 25));
		tstreet.setPreferredSize(new Dimension(300, 25));
		tstreet.setMaximumSize(new Dimension(300, 25));
		pbox2.setMaximumSize(new Dimension(500, 25));
		pbox2.add(lstreet, BorderLayout.WEST);
		pbox2.add(tstreet, BorderLayout.CENTER);
		box_2.add(pbox2);
		northpanel1.setOpaque(true);
		pbox2.setForeground(Color.black);
		//pbox2.setBackground(Color.white);
		box_2.add(Box.createRigidArea(new Dimension(0, 10)));

		box_4.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox4 = UIHelper.getBoxPanel(new BorderLayout(),new Color(236,233,216),Color.black);
		lpostcode.setPreferredSize(new Dimension(150, 25));
		lpostcode.setMaximumSize(new Dimension(150, 25));
		tpostcode.setPreferredSize(new Dimension(300, 25));
		tpostcode.setMaximumSize(new Dimension(300, 25));
		pbox4.setMaximumSize(new Dimension(500, 25));
		pbox4.add(lpostcode, BorderLayout.WEST);
		pbox4.add(tpostcode, BorderLayout.CENTER);
		box_4.add(pbox4);
		northpanel1.setOpaque(true);
		pbox4.setForeground(Color.black);
		//pbox4.setBackground(Color.white);
		box_4.add(Box.createRigidArea(new Dimension(0, 10)));

		box_6.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox6 = UIHelper.getBoxPanel(new BorderLayout(),new Color(236,233,216),Color.black);
		lfirstname.setPreferredSize(new Dimension(150, 25));
		lfirstname.setMaximumSize(new Dimension(150, 25));
		tfirstname.setPreferredSize(new Dimension(300, 25));
		tfirstname.setMaximumSize(new Dimension(300, 25));
		pbox6.setMaximumSize(new Dimension(500, 25));
		pbox6.add(lfirstname, BorderLayout.WEST);
		pbox6.add(tfirstname, BorderLayout.CENTER);
		box_6.add(pbox6);
		northpanel2.setOpaque(true);
		pbox6.setForeground(Color.black);
		//pbox6.setBackground(Color.white);
		box_6.add(Box.createRigidArea(new Dimension(0, 10)));

		box_8.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox8 = UIHelper.getBoxPanel(new BorderLayout(),new Color(236,233,216),Color.black);
		llastname.setPreferredSize(new Dimension(150, 25));
		llastname.setMaximumSize(new Dimension(150, 25));
		tlastname.setPreferredSize(new Dimension(300, 25));
		tlastname.setMaximumSize(new Dimension(300, 25));
		pbox8.setMaximumSize(new Dimension(500, 25));
		pbox8.add(llastname, BorderLayout.WEST);
		pbox8.add(tlastname, BorderLayout.CENTER);
		box_8.add(pbox8);
		northpanel2.setOpaque(true);
		pbox8.setForeground(Color.black);
		//pbox8.setBackground(Color.white);
		box_8.add(Box.createRigidArea(new Dimension(0, 10)));

		box_10.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox10 = UIHelper.getBoxPanel(new BorderLayout(),new Color(236,233,216),Color.black);
		lempty.setPreferredSize(new Dimension(150, 25));
		lempty.setMaximumSize(new Dimension(150, 25));
		butfindcustomer.addActionListener(this);
		butfindcustomer.setPreferredSize(new Dimension(150, 25));
		butfindcustomer.setMaximumSize(new Dimension(150, 25));
		lemptyeast.setPreferredSize(new Dimension(150, 25));
		lemptyeast.setMaximumSize(new Dimension(150, 25));
		pbox10.setMaximumSize(new Dimension(500, 25));
		pbox10.add(lempty, BorderLayout.WEST);
		//pbox10.add(butfindcustomer, BorderLayout.CENTER);
		pbox10.add(butfindcustomer, BorderLayout.EAST);
		box_10.add(pbox10);
		Font f4 = new Font("sans", Font.BOLD, 12);
		butfindcustomer.setFont(f4);
		butfindcustomer.setForeground(new Color(52,152,219));
		box_10.add(Box.createRigidArea(new Dimension(0, 10)));

		northpanel1.add(box_1);
		northpanel1.add(box_2);
		northpanel1.add(box_3);
		northpanel1.add(box_4);

		northpanel2.add(box_5);
		northpanel2.add(box_6);
		northpanel2.add(box_7);
		northpanel2.add(box_8);
		northpanel2.add(box_9);
		northpanel2.add(box_10);
		
		northpanel.setOpaque(true);
		northpanel1.setBackground(new Color(236,233,216));
		northpanel2.setBackground(new Color(236,233,216));
		

		centerpanel1a.setLayout(new BoxLayout(centerpanel1a,
				BoxLayout.PAGE_AXIS));
		centerpanel1b.setLayout(new BoxLayout(centerpanel1b,
				BoxLayout.PAGE_AXIS));

		centerpanel2
				.setLayout(new BoxLayout(centerpanel2, BoxLayout.PAGE_AXIS));

		southpanela.setLayout(new BoxLayout(southpanela, BoxLayout.PAGE_AXIS));
		southpanelb.setLayout(new BoxLayout(southpanelb, BoxLayout.PAGE_AXIS));

		Component box_11a = Box.createRigidArea(new Dimension(200, 10));
		Box box_12a = Box.createHorizontalBox();
		Component box_11 = Box.createRigidArea(new Dimension(200, 10));
		Box box_12 = Box.createHorizontalBox();
		Component box_13 = Box.createRigidArea(new Dimension(200, 10));
		Box box_14 = Box.createHorizontalBox();
		Component box_15 = Box.createRigidArea(new Dimension(200, 10));
		Box box_16 = Box.createHorizontalBox();
		Component box_17 = Box.createRigidArea(new Dimension(200, 10));
		Box box_18 = Box.createHorizontalBox();
		Component box_19 = Box.createRigidArea(new Dimension(200, 10));
		Box box_20 = Box.createHorizontalBox();
		Component box_21 = Box.createRigidArea(new Dimension(200, 10));
		Box box_22 = Box.createHorizontalBox();
		Component box_23 = Box.createRigidArea(new Dimension(200, 10));
		Box box_24 = Box.createHorizontalBox();
		Component box_25 = Box.createRigidArea(new Dimension(200, 10));
		Box box_26 = Box.createHorizontalBox();
		Component box_27 = Box.createRigidArea(new Dimension(200, 10));
		Box box_28 = Box.createHorizontalBox();
		Component box_29 = Box.createRigidArea(new Dimension(200, 10));
		Box box_30 = Box.createHorizontalBox();
		Component box_31 = Box.createRigidArea(new Dimension(200, 10));
		Box box_32 = Box.createHorizontalBox();
		Component box_33 = Box.createRigidArea(new Dimension(200, 10));
		Box box_34 = Box.createHorizontalBox();
		Component box_35 = Box.createRigidArea(new Dimension(200, 10));
		Box box_36 = Box.createHorizontalBox();
		Component box_37 = Box.createRigidArea(new Dimension(200, 10));
		Box box_38 = Box.createHorizontalBox();
		Component box_39 = Box.createRigidArea(new Dimension(200, 10));
		Box box_40 = Box.createHorizontalBox();
		Component box_41 = Box.createRigidArea(new Dimension(200, 10));
		Box box_42 = Box.createHorizontalBox();
		Component box_43 = Box.createRigidArea(new Dimension(200, 10));
		Box box_44 = Box.createHorizontalBox();
		Component box_45 = Box.createRigidArea(new Dimension(200, 10));
		Box box_46 = Box.createHorizontalBox();
		Component box_47 = Box.createRigidArea(new Dimension(200, 10));
		Box box_48 = Box.createHorizontalBox();
		Component box_49 = Box.createRigidArea(new Dimension(200, 10));
		Box box_50 = Box.createHorizontalBox();
		Component box_51 = Box.createRigidArea(new Dimension(10, 170));
		Box box_52 = Box.createHorizontalBox();
		Component box_55 = Box.createRigidArea(new Dimension(200, 10));
		Box box_56 = Box.createHorizontalBox();

		Component box_57 = Box.createRigidArea(new Dimension(200, 10));
		Box box_58 = Box.createHorizontalBox();
		Component box_59 = Box.createRigidArea(new Dimension(200, 10));
		Box box_60 = Box.createHorizontalBox();
		Component box_61 = Box.createRigidArea(new Dimension(200, 10));
		Box box_62 = Box.createHorizontalBox();

		Component box_63 = Box.createRigidArea(new Dimension(200, 10));
		Box box_64 = Box.createHorizontalBox();
		Component box_65 = Box.createRigidArea(new Dimension(200, 10));
		Box box_66 = Box.createHorizontalBox();
		
		Date d=new Date();
		SimpleDateFormat sdf =new SimpleDateFormat("dd-MM-yyyy");
		ldatelabel.setText(sdf.format(d));
		box_12a.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox12a = UIHelper.getBoxPanel(new BorderLayout(), null, null);
		ldate.setPreferredSize(new Dimension(150, 25));
		ldate.setMaximumSize(new Dimension(150, 25));
		ldatelabel.setPreferredSize(new Dimension(300, 25));
		ldatelabel.setMaximumSize(new Dimension(300, 25));
		pbox12a.setMaximumSize(new Dimension(500, 25));
		pbox12a.add(ldate, BorderLayout.WEST);
		pbox12a.add(ldatelabel, BorderLayout.CENTER);
		box_12a.add(pbox12a);
		centerpanel1a.setOpaque(true);
		pbox12a.setForeground(Color.black);
		pbox12a.setBackground(Color.white);
		box_12a.add(Box.createRigidArea(new Dimension(0, 10)));

		box_12.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox12 = UIHelper.getBoxPanel(new BorderLayout(), null, null);
		lfirstnameticket.setPreferredSize(new Dimension(150, 25));
		lfirstnameticket.setMaximumSize(new Dimension(150, 25));
		tfirstnameticket.setPreferredSize(new Dimension(300, 25));
		tfirstnameticket.setMaximumSize(new Dimension(300, 25));
		pbox12.setMaximumSize(new Dimension(500, 25));
		pbox12.add(lfirstnameticket, BorderLayout.WEST);
		pbox12.add(tfirstnameticket, BorderLayout.CENTER);
		box_12.add(pbox12);
		centerpanel1a.setOpaque(true);
		pbox12.setForeground(Color.black);
		pbox12.setBackground(Color.white);
		box_12.add(Box.createRigidArea(new Dimension(0, 10)));

		box_14.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox14 = UIHelper.getBoxPanel(new BorderLayout(), null, null);
		lhouse.setPreferredSize(new Dimension(150, 25));
		lhouse.setMaximumSize(new Dimension(150, 25));
		thouse.setPreferredSize(new Dimension(300, 25));
		thouse.setMaximumSize(new Dimension(300, 25));
		pbox14.setMaximumSize(new Dimension(500, 25));
		pbox14.add(lhouse, BorderLayout.WEST);
		pbox14.add(thouse, BorderLayout.CENTER);
		box_14.add(pbox14);
		centerpanel1a.setOpaque(true);
		pbox14.setForeground(Color.black);
		pbox14.setBackground(Color.white);
		box_14.add(Box.createRigidArea(new Dimension(0, 10)));

		box_16.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox16 = UIHelper.getBoxPanel(new BorderLayout(), null, null);
		ltowmticket.setPreferredSize(new Dimension(150, 25));
		ltowmticket.setMaximumSize(new Dimension(150, 25));
		ttowmticket.setPreferredSize(new Dimension(300, 25));
		ttowmticket.setMaximumSize(new Dimension(300, 25));
		pbox16.setMaximumSize(new Dimension(500, 25));
		pbox16.add(ltowmticket, BorderLayout.WEST);
		pbox16.add(ttowmticket, BorderLayout.CENTER);
		box_16.add(pbox16);
		centerpanel1a.setOpaque(true);
		pbox16.setForeground(Color.black);
		pbox16.setBackground(Color.white);
		box_16.add(Box.createRigidArea(new Dimension(0, 10)));
		
		comboarea=arealoaddata();

		box_18.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox18 = UIHelper.getBoxPanel(new BorderLayout(), null, null);
		lpostcodeticket.setPreferredSize(new Dimension(150, 25));
		lpostcodeticket.setMaximumSize(new Dimension(150, 25));
		tpostcodeticket.setPreferredSize(new Dimension(300, 25));
		tpostcodeticket.setMaximumSize(new Dimension(300, 25));
		pbox18.setMaximumSize(new Dimension(500, 25));
		pbox18.add(lpostcodeticket, BorderLayout.WEST);
		pbox18.add(tpostcodeticket, BorderLayout.CENTER);
		box_18.add(pbox18);
		centerpanel1a.setOpaque(true);
		pbox18.setForeground(Color.black);
		pbox18.setBackground(Color.white);
		box_18.add(Box.createRigidArea(new Dimension(0, 10)));

		box_20.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox20 = UIHelper.getBoxPanel(new BorderLayout(), null, null);
		lmobileticket.setPreferredSize(new Dimension(150, 25));
		lmobileticket.setMaximumSize(new Dimension(150, 25));
		tmobileticket.setPreferredSize(new Dimension(300, 25));
		tmobileticket.setMaximumSize(new Dimension(300, 25));
		pbox20.setMaximumSize(new Dimension(500, 25));
		pbox20.add(lmobileticket, BorderLayout.WEST);
		pbox20.add(tmobileticket, BorderLayout.CENTER);
		box_20.add(pbox20);
		centerpanel1a.setOpaque(true);
		pbox20.setForeground(Color.black);
		pbox20.setBackground(Color.white);
		box_20.add(Box.createRigidArea(new Dimension(0, 10)));

		combocatagoryticket = catloaddata();

		box_22.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox22 = UIHelper.getBoxPanel(new BorderLayout(), null, null);
		lcatagoryticket.setPreferredSize(new Dimension(150, 25));
		lcatagoryticket.setMaximumSize(new Dimension(150, 25));
		combocatagoryticket.setPreferredSize(new Dimension(300, 25));
		combocatagoryticket.setMaximumSize(new Dimension(300, 25));
		pbox22.setMaximumSize(new Dimension(500, 25));
		pbox22.add(lcatagoryticket, BorderLayout.WEST);
		pbox22.add(combocatagoryticket, BorderLayout.CENTER);
		box_22.add(pbox22);
		centerpanel1a.setOpaque(true);
		pbox22.setForeground(Color.black);
		pbox22.setBackground(Color.white);
		box_22.add(Box.createRigidArea(new Dimension(0, 10)));

		box_24.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox24 = UIHelper.getBoxPanel(new BorderLayout(), null, null);
		lstatusticket.setPreferredSize(new Dimension(150, 25));
		lstatusticket.setMaximumSize(new Dimension(150, 25));
		combostatus.setPreferredSize(new Dimension(300, 25));
		combostatus.setMaximumSize(new Dimension(300, 25));
		pbox24.setMaximumSize(new Dimension(500, 25));
		pbox24.add(lstatusticket, BorderLayout.WEST);
		pbox24.add(combostatus, BorderLayout.CENTER);
		box_24.add(pbox24);
		centerpanel2.setOpaque(true);
		pbox24.setForeground(Color.black);
		pbox24.setBackground(Color.white);
		
		box_24.add(Box.createRigidArea(new Dimension(0, 10)));
		
		comboreport=reportloaddata();

		box_26.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox26 = UIHelper.getBoxPanel(new BorderLayout(), null, null);
		lreportedbyticket.setPreferredSize(new Dimension(150, 25));
		lreportedbyticket.setMaximumSize(new Dimension(150, 25));
		comboreport.setPreferredSize(new Dimension(300, 25));
		comboreport.setMaximumSize(new Dimension(300, 25));
		pbox26.setMaximumSize(new Dimension(500, 25));
		pbox26.add(lreportedbyticket, BorderLayout.WEST);
		pbox26.add(comboreport, BorderLayout.CENTER);
		box_26.add(pbox26);
		centerpanel2.setOpaque(true);
		pbox26.setForeground(Color.black);
		pbox26.setBackground(Color.white);
		box_26.add(Box.createRigidArea(new Dimension(0, 10)));

		box_56.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox56 = UIHelper.getBoxPanel(new BorderLayout(), null, null);
		lareaticket.setPreferredSize(new Dimension(150, 25));
		lareaticket.setMaximumSize(new Dimension(150, 25));
		comboarea.setPreferredSize(new Dimension(300, 25));
		comboarea.setMaximumSize(new Dimension(300, 25));
		pbox56.setMaximumSize(new Dimension(500, 25));
		pbox56.add(lareaticket, BorderLayout.WEST);
		pbox56.add(comboarea, BorderLayout.CENTER);
		box_56.add(pbox56);
		centerpanel2.setOpaque(true);
		pbox56.setForeground(Color.black);
		pbox56.setBackground(Color.white);
		box_56.add(Box.createRigidArea(new Dimension(0, 10)));

		JPanel workdetailsareapanel = UIHelper.getBoxPanel(new BorderLayout(), null, null);
		workdetailsareapanel.add(new JScrollPane(workdetailsarea));

		box_28.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox28 = UIHelper.getBoxPanel(new BorderLayout(), null, null);
		lworkdetails.setPreferredSize(new Dimension(150, 25));
		lworkdetails.setMaximumSize(new Dimension(150, 25));
		workdetailsareapanel.setPreferredSize(new Dimension(500, 60));
		workdetailsareapanel.setMaximumSize(new Dimension(500, 60));
		pbox28.setMaximumSize(new Dimension(700, 60));
		pbox28.add(lworkdetails, BorderLayout.WEST);
		pbox28.add(workdetailsareapanel, BorderLayout.CENTER);
		box_28.add(pbox28);
		southpanela.setOpaque(true);
		pbox18.setForeground(Color.black);
		pbox18.setBackground(Color.white);
		
		box_28.add(Box.createRigidArea(new Dimension(0, 10)));

		JPanel additionalpanel = UIHelper.getBoxPanel(new BorderLayout(), null, null);
		additionalpanel.add(new JScrollPane(areaadditional));

		box_30.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox30 = UIHelper.getBoxPanel(new BorderLayout(), null, null);
		ladditionalnotes.setPreferredSize(new Dimension(150, 25));
		ladditionalnotes.setMaximumSize(new Dimension(150, 25));
		additionalpanel.setPreferredSize(new Dimension(500, 60));
		additionalpanel.setMaximumSize(new Dimension(500, 60));
		pbox30.setMaximumSize(new Dimension(700, 60));
		pbox30.add(ladditionalnotes, BorderLayout.WEST);
		pbox30.add(additionalpanel, BorderLayout.CENTER);
		box_30.add(pbox30);
		southpanela.setOpaque(true);
		pbox18.setForeground(Color.black);
		pbox18.setBackground(Color.white);
		
		box_30.add(Box.createRigidArea(new Dimension(0, 10)));

		
		SimpleDateFormat sdf1 =new SimpleDateFormat("HH:mm:ss");
		ltimelabel.setText(sdf1.format(d));
		
		box_32.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox32 = UIHelper.getBoxPanel(new BorderLayout(), null, null);
		ltime.setPreferredSize(new Dimension(150, 25));
		ltime.setMaximumSize(new Dimension(150, 25));
		ltimelabel.setPreferredSize(new Dimension(300, 25));
		ltimelabel.setMaximumSize(new Dimension(300, 25));
		pbox32.setMaximumSize(new Dimension(500, 25));
		pbox32.add(ltime, BorderLayout.WEST);
		pbox32.add(ltimelabel, BorderLayout.CENTER);
		box_32.add(pbox32);
		centerpanel1b.setOpaque(true);
		pbox18.setForeground(Color.black);
		pbox18.setBackground(Color.white);
		
		box_32.add(Box.createRigidArea(new Dimension(0, 10)));

		box_34.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox34 = UIHelper.getBoxPanel(new BorderLayout(), null, null);
		llastnameticket.setPreferredSize(new Dimension(150, 25));
		llastnameticket.setMaximumSize(new Dimension(150, 25));
		tlastnameticket.setPreferredSize(new Dimension(300, 25));
		tlastnameticket.setMaximumSize(new Dimension(300, 25));
		pbox34.setMaximumSize(new Dimension(500, 25));
		pbox34.add(llastnameticket, BorderLayout.WEST);
		pbox34.add(tlastnameticket, BorderLayout.CENTER);
		box_34.add(pbox34);
		centerpanel1b.setOpaque(true);
		pbox34.setForeground(Color.black);
		pbox34.setBackground(Color.white);
		box_34.add(Box.createRigidArea(new Dimension(0, 10)));

		box_36.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox36 = UIHelper.getBoxPanel(new BorderLayout(), null, null);
		lstreetticket.setPreferredSize(new Dimension(150, 25));
		lstreetticket.setMaximumSize(new Dimension(150, 25));
		tstreetticket.setPreferredSize(new Dimension(300, 25));
		tstreetticket.setMaximumSize(new Dimension(300, 25));
		pbox36.setMaximumSize(new Dimension(500, 25));
		pbox36.add(lstreetticket, BorderLayout.WEST);
		pbox36.add(tstreetticket, BorderLayout.CENTER);
		box_36.add(pbox36);
		centerpanel1b.setOpaque(true);
		pbox36.setForeground(Color.black);
		pbox36.setBackground(Color.white);
		box_36.add(Box.createRigidArea(new Dimension(0, 10)));

		box_38.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox38 = UIHelper.getBoxPanel(new BorderLayout(), null, null);
		lcityticket.setPreferredSize(new Dimension(150, 25));
		lcityticket.setMaximumSize(new Dimension(150, 25));
		tcityticket.setPreferredSize(new Dimension(300, 25));
		tcityticket.setMaximumSize(new Dimension(300, 25));
		pbox38.setMaximumSize(new Dimension(500, 25));
		pbox38.add(lcityticket, BorderLayout.WEST);
		pbox38.add(tcityticket, BorderLayout.CENTER);
		box_38.add(pbox38);
		centerpanel1b.setOpaque(true);
		pbox38.setForeground(Color.black);
		pbox38.setBackground(Color.white);
		
		box_38.add(Box.createRigidArea(new Dimension(0, 10)));

		box_40.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox40 = UIHelper.getBoxPanel(new BorderLayout(), null, null);
		llandlineticket.setPreferredSize(new Dimension(150, 25));
		llandlineticket.setMaximumSize(new Dimension(150, 25));
		tlandlineticket.setPreferredSize(new Dimension(300, 25));
		tlandlineticket.setMaximumSize(new Dimension(300, 25));
		pbox40.setMaximumSize(new Dimension(500, 25));
		pbox40.add(llandlineticket, BorderLayout.WEST);
		pbox40.add(tlandlineticket, BorderLayout.CENTER);
		box_40.add(pbox40);
		centerpanel1b.setOpaque(true);
		pbox40.setForeground(Color.black);
		pbox40.setBackground(Color.white);
		
		box_40.add(Box.createRigidArea(new Dimension(0, 10)));

		box_42.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox42 = UIHelper.getBoxPanel(new BorderLayout(), null, null);
		lcodeticket.setPreferredSize(new Dimension(150, 25));
		lcodeticket.setMaximumSize(new Dimension(150, 25));
		tcodeticket.setPreferredSize(new Dimension(300, 25));
		tcodeticket.setMaximumSize(new Dimension(300, 25));
		pbox42.setMaximumSize(new Dimension(500, 25));
		pbox42.add(lcodeticket, BorderLayout.WEST);
		pbox42.add(tcodeticket, BorderLayout.CENTER);
		box_42.add(pbox42);
		centerpanel1b.setOpaque(true);
		pbox42.setForeground(Color.black);
		pbox42.setBackground(Color.white);
		
		box_42.add(Box.createRigidArea(new Dimension(0, 10)));

		ampm.addItem("AM");
		ampm.addItem("PM");
		
		box_44.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox44 = UIHelper.getBoxPanel(new BorderLayout(), null, null);
		lappointmentdate.setPreferredSize(new Dimension(150, 25));
		lappointmentdate.setMaximumSize(new Dimension(150, 25));
		appdate.setPreferredSize(new Dimension(150, 25));
		appdate.setMaximumSize(new Dimension(150, 25));
		ampm.setPreferredSize(new Dimension(60, 25));
		ampm.setMaximumSize(new Dimension(60, 25));
		pbox44.setMaximumSize(new Dimension(500, 25));
		ampm.addActionListener(this);
		
		pbox44.add(lappointmentdate, BorderLayout.WEST);
		pbox44.add(appdate, BorderLayout.CENTER);
		pbox44.add(ampm, BorderLayout.EAST);
		box_44.add(pbox44);
		
		centerpanel1b.setOpaque(true);
		pbox44.setForeground(Color.black);
		pbox44.setBackground(Color.white);
		
		box_44.add(Box.createRigidArea(new Dimension(0, 10)));

		box_46.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox46 = UIHelper.getBoxPanel(new BorderLayout(), null, null);
		lpriorityticket.setPreferredSize(new Dimension(150, 25));
		lpriorityticket.setMaximumSize(new Dimension(150, 25));
		combopriority.setPreferredSize(new Dimension(300, 25));
		combopriority.setMaximumSize(new Dimension(300, 25));
		pbox46.setMaximumSize(new Dimension(500, 25));
		pbox46.add(lpriorityticket, BorderLayout.WEST);
		pbox46.add(combopriority, BorderLayout.CENTER);
		box_46.add(pbox46);
		centerpanel2.setOpaque(true);
		pbox46.setForeground(Color.black);
		pbox46.setBackground(Color.white);
		
		box_46.add(Box.createRigidArea(new Dimension(0, 10)));

		box_48.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox48 = UIHelper.getBoxPanel(new BorderLayout(), null, null);
		lworkorderno.setPreferredSize(new Dimension(150, 25));
		lworkorderno.setMaximumSize(new Dimension(150, 25));
		tworkorderno.setPreferredSize(new Dimension(300, 25));
		tworkorderno.setMaximumSize(new Dimension(300, 25));
		pbox48.setMaximumSize(new Dimension(500, 25));
		pbox48.add(lworkorderno, BorderLayout.WEST);
		pbox48.add(tworkorderno, BorderLayout.CENTER);
		box_48.add(pbox48);
		centerpanel2.setOpaque(true);
		pbox48.setForeground(Color.black);
		pbox48.setBackground(Color.white);
		
		box_48.add(Box.createRigidArea(new Dimension(0, 10)));

		JPanel prppanel = UIHelper.getBoxPanel(new BorderLayout(), Color.white, Color.black);
		prppanel.add(new JScrollPane(prparea));

		box_50.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox50 = UIHelper.getBoxPanel(new BorderLayout(), null, null);
		lprpdetails.setPreferredSize(new Dimension(150, 25));
		lprpdetails.setMaximumSize(new Dimension(150, 25));
		additionalpanel.setPreferredSize(new Dimension(300, 100));
		additionalpanel.setMaximumSize(new Dimension(300, 100));
		pbox50.setMaximumSize(new Dimension(500, 100));
		pbox50.add(lprpdetails, BorderLayout.WEST);
		pbox50.add(prppanel, BorderLayout.CENTER);
		box_50.add(pbox50);
		centerpanel1b.setOpaque(true);
		pbox50.setForeground(Color.black);
		pbox50.setBackground(Color.white);
		
		box_50.add(Box.createRigidArea(new Dimension(0, 50)));

		box_52.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox52 =UIHelper.getBoxPanel(new BorderLayout(),Color.white,null);
		pbox52.setBorder(BorderFactory.createRaisedBevelBorder());
		emptybuttonlabel.setPreferredSize(new Dimension(150, 25));
		emptybuttonlabel.setMaximumSize(new Dimension(150, 25));
		butsubmit.setPreferredSize(new Dimension(300, 25));
		butsubmit.setMaximumSize(new Dimension(300, 25));
		pbox52.setMaximumSize(new Dimension(500, 25));
		pbox52.add(emptybuttonlabel, BorderLayout.WEST);
		pbox52.add(butsubmit, BorderLayout.CENTER);
		box_52.add(pbox52);
		Font f4a = new Font("sans", Font.BOLD, 11);
		butsubmit.setFont(f4a);
		butsubmit.setForeground(new Color(52,152,219));
		box_52.add(Box.createRigidArea(new Dimension(0, 10)));

		box_58.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox58 = UIHelper.getBoxPanel(new BorderLayout(), null, null);
		lassignticket.setPreferredSize(new Dimension(150, 25));
		lassignticket.setMaximumSize(new Dimension(150, 25));
		comboassign.setPreferredSize(new Dimension(300, 25));
		comboassign.setMaximumSize(new Dimension(300, 25));
		pbox58.setMaximumSize(new Dimension(500, 25));
		pbox58.add(lassignticket, BorderLayout.WEST);
		pbox58.add(comboassign, BorderLayout.CENTER);
		box_58.add(pbox58);
		southpanelb.setOpaque(true);
		pbox18.setForeground(Color.black);
		pbox18.setBackground(Color.white);
		box_58.add(Box.createRigidArea(new Dimension(0, 10)));

		box_60.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox60 = UIHelper.getBoxPanel(new BorderLayout(), null, null);
		emptybuttonlabel.setPreferredSize(new Dimension(150, 25));
		emptybuttonlabel.setMaximumSize(new Dimension(150, 25));
		chkrecharge.setPreferredSize(new Dimension(300, 25));
		chkrecharge.setMaximumSize(new Dimension(300, 25));
		pbox60.setMaximumSize(new Dimension(500, 25));
		pbox60.add(emptybuttonlabel, BorderLayout.WEST);
		pbox60.add(chkrecharge, BorderLayout.CENTER);
		box_60.add(pbox60);
		southpanelb.setOpaque(true);
		chkrecharge.setForeground(Color.black);
		chkrecharge.setBackground(Color.white);
		
		box_60.add(Box.createRigidArea(new Dimension(0, 10)));

		box_62.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox62 = UIHelper.getBoxPanel(new BorderLayout(), null, null);
		emptybuttonlabel.setPreferredSize(new Dimension(150, 25));
		emptybuttonlabel.setMaximumSize(new Dimension(150, 25));
		butsubmit.setPreferredSize(new Dimension(300, 25));
		butsubmit.setMaximumSize(new Dimension(300, 25));
		pbox62.setMaximumSize(new Dimension(250, 25));
		pbox62.add(emptybuttonlabel, BorderLayout.WEST);
		pbox62.add(butsubmit, BorderLayout.CENTER);
		box_62.add(pbox62);
		southpanelb.setOpaque(true);
		pbox18.setForeground(Color.black);
		pbox18.setBackground(Color.white);
		
		box_62.add(Box.createRigidArea(new Dimension(0, 10)));
		
		//south empty
		
		box_64.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox64 = UIHelper.getBoxPanel(new BorderLayout(), null, null);
		empty.setPreferredSize(new Dimension(150, 25));
		empty.setMaximumSize(new Dimension(150, 25));
		empty1.setPreferredSize(new Dimension(300, 25));
		empty1.setMaximumSize(new Dimension(300, 25));
		pbox64.setMaximumSize(new Dimension(250, 25));
		pbox64.add(empty1, BorderLayout.WEST);
		pbox64.add(empty1, BorderLayout.CENTER);
		box_64.add(pbox64);
		southpanelb.setOpaque(true);
		pbox18.setForeground(Color.black);
		pbox18.setBackground(Color.white);
		
		box_64.add(Box.createRigidArea(new Dimension(0, 10)));

		
		
		box_66.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox66 = UIHelper.getBoxPanel(new BorderLayout(), null, null);
		empty2.setPreferredSize(new Dimension(150, 25));
		empty2.setMaximumSize(new Dimension(150, 25));
		empty3.setPreferredSize(new Dimension(300, 25));
		empty3.setMaximumSize(new Dimension(300, 25));
		pbox66.setMaximumSize(new Dimension(250, 25));
		pbox66.add(empty2, BorderLayout.WEST);
		pbox66.add(empty3, BorderLayout.CENTER);
		box_66.add(pbox64);
		southpanelb.setOpaque(true);
		pbox66.setForeground(Color.black);
		pbox66.setBackground(Color.white);
		
		box_66.add(Box.createRigidArea(new Dimension(0, 10)));

		
				
		
		
		centerpanel1a.add(box_11a);
		centerpanel1a.add(box_12a);
		centerpanel1a.add(box_11);
		centerpanel1a.add(box_12);
		centerpanel1a.add(box_13);
		centerpanel1a.add(box_14);
		centerpanel1a.add(box_15);
		centerpanel1a.add(box_16);
		centerpanel1a.add(box_17);
		centerpanel1a.add(box_18);
		centerpanel1a.add(box_19);
		centerpanel1a.add(box_20);
		centerpanel1a.add(box_21);
		centerpanel1a.add(box_22);
		centerpanel1a.add(box_43);
		centerpanel1a.add(box_44);

		centerpanel1b.add(box_31);
		centerpanel1b.add(box_32);
		centerpanel1b.add(box_33);
		centerpanel1b.add(box_34);
		centerpanel1b.add(box_35);
		centerpanel1b.add(box_36);
		centerpanel1b.add(box_37);
		centerpanel1b.add(box_38);
		centerpanel1b.add(box_39);
		centerpanel1b.add(box_40);
		centerpanel1b.add(box_41);
		centerpanel1b.add(box_42);

		centerpanel1b.add(box_49);
		centerpanel1b.add(box_50);

		centerpanel2.add(box_47);
		centerpanel2.add(box_48);
		centerpanel2.add(box_49);
		centerpanel2.add(box_50);
		centerpanel2.add(box_23);
		centerpanel2.add(box_24);
		centerpanel2.add(box_45);
		centerpanel2.add(box_46);
		centerpanel2.add(box_25);
		centerpanel2.add(box_26);
		centerpanel2.add(box_55);
		centerpanel2.add(box_56);

		//southpanelb.add(box_57);
		//southpanelb.add(box_58);
		southpanelb.add(box_59);
		southpanelb.add(box_60);
		southpanelb.add(box_61);
		southpanelb.add(box_62);
		southpanelb.add(box_63);
		southpanelb.add(box_64);
		southpanelb.add(box_65);
		southpanelb.add(box_66);
		
		
		
		/*
		  southpanelb.add(box_51);
		  southpanelb.add(box_52);
		 */
		//southpanela.add(box_43);
		//southpanela.add(box_44);
		southpanela.add(box_27);
		southpanela.add(box_28);
		southpanela.add(box_29);
		southpanela.add(box_30);
		

		centerpanel.add(centerpanel1);
		centerpanel.add(centerpanel2);

		centerpanel1.add(centerpanel1a);
		centerpanel1.add(centerpanel1b);
		
		centerpanel1.setOpaque(true);
		centerpanel1a.setBackground(Color.white);
		centerpanel1b.setBackground(Color.white);
     
		northpanel.add(northpanel1);
		northpanel.add(northpanel2);
		if (butsubmit.getActionListeners().length == 0)
			butsubmit.addActionListener(this);
		
		
		northpanel.setBorder(BorderFactory.createRaisedBevelBorder());

		northpanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEmptyBorder(),"Customer Look up"));
		//centerpanel.setBorder(BorderFactory
				//.createTitledBorder( Border bor,"Add New Ticket",TitledBorder.LEADING ,5,5,5,5,"sana"));
		centerpanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2),"Add New Ticket",TitledBorder.LEADING,TitledBorder.ABOVE_TOP, new Font("sans", Font.BOLD, 14), new Color(52,152,219)));
   
		northpanel.setPreferredSize(new Dimension(width, 130));
		centerpanel.setPreferredSize(new Dimension(width,300));
		southpanel.setPreferredSize(new Dimension(width,110));
		// southpanelb.setBorder(BorderFactory.createTitledBorder("submit"));
		southpanel.add(southpanela, BorderLayout.WEST);
		southpanel.add(southpanelb, BorderLayout.CENTER);
		//southpanel.add(southpanelc,BorderLayout.SOUTH);

		mainpanel.add(northpanel, BorderLayout.NORTH);
		mainpanel.add(centerpanel, BorderLayout.CENTER);
		mainpanel.add(southpanel, BorderLayout.SOUTH);

		mainnorthpanel.setBorder(BorderFactory.createRaisedBevelBorder());

		north1.setPreferredSize(new Dimension(200, 120));

		mainnorthpanel.setPreferredSize(new Dimension(width, 120));

		mainpanel.setPreferredSize(new Dimension(width, 545));
		// mainpanel.setPreferredSize(new Dimension(width,height-300));
		addmainpanel.add(mainpanel);
		//north1.add(emptybuttonlabel);
		
		//mainnorthpanel.add(north1, BorderLayout.WEST);
		mainnorthpanel.add(summaryPanelHolder, BorderLayout.CENTER);

		setSize(width, height);
		
		setOpaque(true);
		
		mainnorthpanel.setForeground(Color.white);
		mainnorthpanel.setBackground(new Color(52,152,219));

		loadScreen();
		
		summaryPanelHolder.add(UIHelper.getSummaryPanel());
	}
	
	/*private JPanel getBoxPanel(LayoutManager layoutManager, Color backgroundColor, Color foregroundColor)
	{
		
		JPanel panel = null;
		
		if(layoutManager == null)
			panel = new JPanel();
		else
			panel = new JPanel(layoutManager);
		
		panel.setOpaque(true);
		
		if (foregroundColor == null)
			panel.setForeground(Color.BLACK);
		else
			panel.setForeground(foregroundColor);
		
		if (backgroundColor == null)
			panel.setBackground(Color.WHITE);
		else
			panel.setBackground(backgroundColor);
		
		return panel;
	}*/
	
	@Override
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource().equals(butfindcustomer))
		{
			sstreet =tstreet.getText();
			spostcode =tpostcode.getText();
			sfirstname =tfirstname.getText();
			slastname =tlastname.getText();
			
			FindCustomerDialog f =new FindCustomerDialog(sstreet,spostcode,sfirstname,slastname, this);
		}
		else if(e.getSource().equals(butsubmit))
		{

			try
			{
				
				String checkono=tworkorderno.getText().toString();
				
				if(checkono == null || checkono.equals("") || checkono.isEmpty() )
				{
				JOptionPane.showMessageDialog(this, "Please Enter the Work Order No");
				}
				else if(cid == null || cid.equals("") || cid.isEmpty() )
				{
					
					if((tfirstnameticket.getText() == null || tfirstnameticket.getText().equals("") || tfirstnameticket.getText().isEmpty()) || (tlastnameticket.getText() == null || tlastnameticket.getText().equals("") || tlastnameticket.getText().isEmpty()) || (thouse.getText() == null || thouse.getText().equals("") || thouse.getText().isEmpty()) || (tstreetticket.getText() == null || tstreetticket.getText().equals("") || tstreetticket.getText().isEmpty()) || (ttowmticket.getText() == null || ttowmticket.getText().equals("") || ttowmticket.getText().isEmpty()) || (tcityticket.getText() == null || tcityticket.getText().equals("") || tcityticket.getText().isEmpty()) || (tpostcodeticket.getText() == null || tpostcodeticket.getText().equals("") || tpostcodeticket.getText().isEmpty()) || (prparea.getText() == null || prparea.getText().equals("") || prparea.getText().isEmpty()) || (tlandlineticket.getText() == null || tlandlineticket.getText().equals("") || tlandlineticket.getText().isEmpty()) || (tmobileticket.getText() == null || tmobileticket.getText().equals("") || tmobileticket.getText().isEmpty()))
					{
						JOptionPane.showMessageDialog(this, "Please Enter all Customer Details");
					}
					else
					{
						String url = UIHelper.getBase() + "query/javainsertcust.php";
						
						HttpClient client = new DefaultHttpClient();
						HttpPost post = new HttpPost(url);
						
						List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
						
						nameValuePairs.add(new BasicNameValuePair("txtfname",tfirstnameticket.getText()));
						nameValuePairs.add(new BasicNameValuePair("txtlname",tlastnameticket.getText()));
						nameValuePairs.add(new BasicNameValuePair("txtflat",thouse.getText()));
						nameValuePairs.add(new BasicNameValuePair("txtstreet",tstreetticket.getText()));
						nameValuePairs.add(new BasicNameValuePair("txtown",ttowmticket.getText()));
						nameValuePairs.add(new BasicNameValuePair("txtcity",tcityticket.getText()));
						nameValuePairs.add(new BasicNameValuePair("txtpcode",tpostcodeticket.getText()));
						nameValuePairs.add(new BasicNameValuePair("txtdetail",prparea.getText()));
						nameValuePairs.add(new BasicNameValuePair("txtll",tlandlineticket.getText()));
						nameValuePairs.add(new BasicNameValuePair("txtmble",tmobileticket.getText()));
						
						post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
						HttpResponse response = client.execute(post);
						BufferedReader rd = new BufferedReader(new InputStreamReader(
						response.getEntity().getContent()));
						
						String line = "";
						String ss = "";
						if ((line = rd.readLine()) != null) 
						{
							ss=line;	
						}
						insertticket(ss);
					}
				}
				else
				{
					insertticket(cid);
				}
			}
			catch(Exception ee)
			{
				ee.printStackTrace();
			}
		}
		
	}
	
	private void insertticket(String custid)
	{
		

		try
		{
			String id=custid;
			
			String rec="N";
			if(chkrecharge.isSelected())
			{
				rec="Y";
			}
			
			String url = UIHelper.getBase() + "query/javainserticket.php";
			
			HttpClient client = new DefaultHttpClient();
			HttpPost post = new HttpPost(url);
			
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
			
			SimpleDateFormat sdf =new SimpleDateFormat("yyyy-MM-dd");
			
			nameValuePairs.add(new BasicNameValuePair("txtono",tworkorderno.getText()));
			nameValuePairs.add(new BasicNameValuePair("selcust",id));
			nameValuePairs.add(new BasicNameValuePair("selcat",((CategoryEntity)combocatagoryticket.getSelectedItem()).getId()));
			nameValuePairs.add(new BasicNameValuePair("txtadate",sdf.format(appdate.getDate())));
			nameValuePairs.add(new BasicNameValuePair("txtdesc",workdetailsarea.getText()));
			nameValuePairs.add(new BasicNameValuePair("txtreport",((EmployeeEntity) comboreport.getSelectedItem()).getEmployee()));
			nameValuePairs.add(new BasicNameValuePair("selarea",((AreaEntity) comboarea.getSelectedItem()).getArea()));
			nameValuePairs.add(new BasicNameValuePair("selcode",tcodeticket.getSelectedItem().toString()));
			nameValuePairs.add(new BasicNameValuePair("selstat",combostatus.getText()));
			nameValuePairs.add(new BasicNameValuePair("selprior",combopriority.getSelectedItem().toString()));
			nameValuePairs.add(new BasicNameValuePair("txtraise",UIHelper.getUser()));
			nameValuePairs.add(new BasicNameValuePair("txtraiseuid",UIHelper.getLoguid()));
			nameValuePairs.add(new BasicNameValuePair("txtnotes",areaadditional.getText()));
			nameValuePairs.add(new BasicNameValuePair("chkrecharge",rec));
			nameValuePairs.add(new BasicNameValuePair("daystat",ampm.getSelectedItem().toString()));
			
			nameValuePairs.add(new BasicNameValuePair("txtcfname",tfirstnameticket.getText()));
			nameValuePairs.add(new BasicNameValuePair("txtclname",tlastnameticket.getText()));
			nameValuePairs.add(new BasicNameValuePair("txtflat",thouse.getText()));
			nameValuePairs.add(new BasicNameValuePair("txtstreet",tstreetticket.getText()));
			nameValuePairs.add(new BasicNameValuePair("txtown",ttowmticket.getText()));
			nameValuePairs.add(new BasicNameValuePair("txtcity",tcityticket.getText()));
			nameValuePairs.add(new BasicNameValuePair("txtpcode",tpostcodeticket.getText()));
			nameValuePairs.add(new BasicNameValuePair("txtdetail",prparea.getText()));
			nameValuePairs.add(new BasicNameValuePair("txtll",tlandlineticket.getText()));
			nameValuePairs.add(new BasicNameValuePair("txtmble",tmobileticket.getText()));
			
			post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			HttpResponse response = client.execute(post);
			BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));
			
			
			StringBuffer buffer1 = new StringBuffer();
	
			String line = "";
			String ss = "";
			while ((line = rd.readLine()) != null) {
				buffer1.append(line);
				ss = ss + line;
				System.out.println(ss);
			}
			if(ss.equals("Given Ticket No is Already Existing"))
			{
				JOptionPane.showMessageDialog(this, "Given Ticket No is Already Existing");
				clr();
				
			}
			clr();
		}
		catch (Exception e11) 
		{
			e11.printStackTrace();
		}
	
	}
	
	private void clr()
	{
		tworkorderno.setText("");
		workdetailsarea.setText("");
		areaadditional.setText("");
				cid="";
		tfirstnameticket.setText("");
		tlastnameticket.setText("");
		thouse.setText("");
		tstreetticket.setText("");
		ttowmticket.setText("");
		tcityticket.setText("");
		tpostcodeticket.setText("");
		prparea.setText("");
		tlandlineticket.setText("");
		tmobileticket.setText("");
		combocatagoryticket.setSelectedIndex(0);
		comboreport.setSelectedIndex(0);
		comboarea.setSelectedIndex(0);
		tcodeticket.setSelectedIndex(0);

		comboreport.setSelectedIndex(0);
		
		
	}

	public JComboBox catloaddata() {

		combocatagoryticket = new JComboBox();

		try {
			String url = UIHelper.getBase() + "query/javacat.php";

			HttpClient client = new DefaultHttpClient();
			HttpGet request = new HttpGet(url);
			HttpResponse response = client.execute(request);
			BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));

			StringBuffer stringBuffer = new StringBuffer();
			String line = null;

			while ((line = rd.readLine()) != null) {
				stringBuffer.append(line);
			}

			String[] cats = stringBuffer.toString().split("--");

			for (String cat : cats) {
				String[] catdetail = cat.split("\\|");
				if (catdetail != null && catdetail.length > 1)
					combocatagoryticket.addItem(new CategoryEntity(
							catdetail[0], catdetail[1]));

			}
		} catch (Exception exception) {
			exception.printStackTrace();
		}

		combocatagoryticket.setSelectedIndex(0);

		return combocatagoryticket;

	}
	
	
	
	public JComboBox reportloaddata() {

		comboreport = new JComboBox();

		try {
			String url = UIHelper.getBase() + "query/javaemp.php";

			HttpClient client = new DefaultHttpClient();
			HttpGet request = new HttpGet(url);
			HttpResponse response = client.execute(request);
			BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));

			StringBuffer stringBuffer = new StringBuffer();
			String line = null;

			while ((line = rd.readLine()) != null) {
				stringBuffer.append(line);
			}

			String[] emps = stringBuffer.toString().split("--");

			for (String emp : emps) {
				String[] empdetail = emp.split("\\|");
				if (empdetail != null && empdetail.length > 1)
					comboreport.addItem(new EmployeeEntity(empdetail[0], empdetail[1]));
			}
		} catch (Exception exception) {
			exception.printStackTrace();
		}

		comboreport.setSelectedIndex(0);

		return comboreport;

	}
	
	public JComboBox arealoaddata() {

		comboarea = new JComboBox();

		try {
			String url = UIHelper.getBase() + "query/javaarea.php";

			HttpClient client = new DefaultHttpClient();
			HttpGet request = new HttpGet(url);
			HttpResponse response = client.execute(request);
			BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));

			StringBuffer stringBuffer = new StringBuffer();
			String line = null;

			while ((line = rd.readLine()) != null) {
				stringBuffer.append(line);
			}

			String[] areas = stringBuffer.toString().split("--");
			
			System.out.println("areas " + areas[0]);

			for (String area : areas) {
				String[] areadetail = area.split("\\|");
				if (areadetail != null && areadetail.length > 1)
					comboarea.addItem(new AreaEntity(areadetail[0], areadetail[1]));
			}
		} catch (Exception exception) {
			exception.printStackTrace();
		}

		comboarea.setSelectedIndex(0);

		return comboarea;

	}

	public void setCustomer(int customerId) {
		try {
			cid = String.valueOf(customerId);

			String url = UIHelper.getBase() + "query/javacustpopup1.php";

			HttpClient client = new DefaultHttpClient();
			HttpPost post = new HttpPost(url);

			// String[] names = label_.getText().split(" ");
			// String a=names.length >= 0 ? names[0] : "";
			// String b=names.length > 0 ? names[1] : "";

			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);

			nameValuePairs.add(new BasicNameValuePair("id", String
					.valueOf(customerId)));

			post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			HttpResponse response = client.execute(post);
			BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));

			StringBuffer buffer1 = new StringBuffer();

			String line = "";
			String ss = "";
			while ((line = rd.readLine()) != null) {
				buffer1.append(line);
				ss = ss + line;
				System.out.println(ss);

			}

			if (!ss.isEmpty()) {

				String[] namevaluePairs = buffer1.toString().split("\\-\\-");

				for (String namevaluePair : namevaluePairs) {
					if (namevaluePair.contains("|")) {
						String[] pairArray = namevaluePair.split("\\|");

						tfirstnameticket.setText(pairArray[1]);
						tlastnameticket.setText(pairArray[2]);
						prparea.setText(pairArray[3]);
						thouse.setText(pairArray[4]);
						tstreetticket.setText(pairArray[5]);
						ttowmticket.setText(pairArray[6]);
						tcityticket.setText(pairArray[7]);
						tlandlineticket.setText(pairArray[8]);
						tmobileticket.setText(pairArray[9]);
						tcodeticket.setSelectedItem(pairArray[10]);
						tpostcodeticket.setText(pairArray[11]);
					}
				}
			}

		} catch (IOException e3) {
			e3.printStackTrace();
		}

	}
	
	public void loadScreen()
	{
		removeAll();
		
		add(mainnorthpanel, BorderLayout.NORTH);
		add(addmainpanel, BorderLayout.CENTER);
		
		updateUI();
	}

}
