package com.alethiclogic.helpdesk.ui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

public class LoginScreen extends JDialog implements ActionListener 
{
private	JPanel mainPanel= new JPanel();

private JLabel lbluname=new JLabel("User Name");
private JLabel lblpword=new JLabel("Password");
private JLabel lblempty=new JLabel("");

private JTextField txtuname=new JTextField("");
private JPasswordField txtpword=new JPasswordField("");

private JButton butsubmit=new JButton("Submit");


	public LoginScreen() 
	{
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.PAGE_AXIS));
		
		Component box_1 = Box.createRigidArea(new Dimension(200, 20));
		Box box_2 = Box.createHorizontalBox();
		
		Component box_3 = Box.createRigidArea(new Dimension(200, 20));
		Box box_4 = Box.createHorizontalBox();
		
		Component box_5 = Box.createRigidArea(new Dimension(200, 20));
		Box box_6 = Box.createHorizontalBox();

		box_2.add(Box.createRigidArea(new Dimension(10, 0)));
		JPanel pbox1 = new JPanel(new BorderLayout());
		lbluname.setPreferredSize(new Dimension(95, 30));
		lbluname.setMaximumSize(new Dimension(95, 30));
		txtuname.setPreferredSize(new Dimension(300, 30));
		txtuname.setMaximumSize(new Dimension(300, 30));
		pbox1.setMaximumSize(new Dimension(500, 30));
		pbox1.add(lbluname, BorderLayout.WEST);
		pbox1.add(txtuname, BorderLayout.CENTER);
		box_2.add(pbox1);
		box_2.add(Box.createRigidArea(new Dimension(20, 10)));
		
		box_4.add(Box.createRigidArea(new Dimension(10, 0)));
		JPanel pbox2 = new JPanel(new BorderLayout());
		lblpword.setPreferredSize(new Dimension(95, 30));
		lblpword.setMaximumSize(new Dimension(95, 30));
		txtpword.setPreferredSize(new Dimension(300, 30));
		txtpword.setMaximumSize(new Dimension(300, 30));
		pbox2.setMaximumSize(new Dimension(500, 30));
		pbox2.add(lblpword, BorderLayout.WEST);
		pbox2.add(txtpword, BorderLayout.CENTER);
		box_4.add(pbox2);
		box_4.add(Box.createRigidArea(new Dimension(20, 10)));
		
		box_6.add(Box.createRigidArea(new Dimension(10, 0)));
		JPanel pbox3 = new JPanel(new BorderLayout());
		lblempty.setPreferredSize(new Dimension(95, 30));
		lblempty.setMaximumSize(new Dimension(95, 30));
		butsubmit.setPreferredSize(new Dimension(100, 30));
		butsubmit.setMaximumSize(new Dimension(100, 30));
		pbox3.setMaximumSize(new Dimension(500, 30));
		pbox3.add(lblempty, BorderLayout.CENTER);
		pbox3.add(butsubmit, BorderLayout.EAST);
		box_6.add(pbox3);
		box_6.add(Box.createRigidArea(new Dimension(20, 10)));
		
		
		butsubmit.addActionListener(this);
		
		mainPanel.add(box_1);
		mainPanel.add(box_2);
		mainPanel.add(box_3);
		mainPanel.add(box_4);
		mainPanel.add(box_5);
		mainPanel.add(box_6);
		
		this.add(mainPanel);
		
		this.setTitle("Login");
		this.setVisible(true);
		this.setSize(350, 200);
		this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

	}
	public static void main(String[] args) 
	{
		
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		new LoginScreen();

	}
	private void clr()
	{
		txtuname.setText("");
		txtpword.setText("");
		txtuname.requestFocusInWindow();
	}
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource().equals(butsubmit))
		{
			try {
				HttpClient client = new DefaultHttpClient();
				HttpPost post = new HttpPost( UIHelper.base + "query/javalogin.php");

				List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
				nameValuePairs.add(new BasicNameValuePair("addedit", "-1"));
				nameValuePairs.add(new BasicNameValuePair("uname", txtuname.getText()));
				nameValuePairs.add(new BasicNameValuePair("pword", txtpword.getText()));

				post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse response = client.execute(post);
				BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

				StringBuffer buffer1 = new StringBuffer();
				String line = "";
				String ss = "";
				String user="";
				String stat="";
				String eid="";
				
				while ((line = rd.readLine()) != null) 
				{
					buffer1.append(line);
					ss = ss + line;
				}

				if (!ss.isEmpty()) 
				{

					String[] namevaluePairs = buffer1.toString().split("\\-\\-");

					for (String namevaluePair : namevaluePairs) 
					{
						if (namevaluePair.contains("|")) 
						{
							String[] pairArray = namevaluePair.split("\\|");
							eid=pairArray[0];
							user=pairArray[1];
							stat=pairArray[2];
						}
					}
				}
											
				
				if(stat.equals("1"))
				{
				UIHelper.setUser(user);
				UIHelper.setLoguid(eid);
				new HelpDeskMain();
				this.dispose();
				}
				else 
				{
					JOptionPane.showMessageDialog(this, "Invalid User Name or Password");		
					clr();
				}
				
			} catch (IOException e3) {
				e3.printStackTrace();
			}
			
		}
	}

}
