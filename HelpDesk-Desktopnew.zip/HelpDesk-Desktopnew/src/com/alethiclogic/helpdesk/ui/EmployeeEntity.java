package com.alethiclogic.helpdesk.ui;

public class EmployeeEntity 
{
	private String empid;
	private String empname;
	
	public EmployeeEntity(String empid, String empname) {
		super();
		this.empid = empid;
		this.empname = empname;
	}
	
	public String getEmployee()
	{
		return empid;
	}
	
	public String toString()
	{
		return empname;
	}
}
