package com.alethiclogic.helpdesk.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;


import com.alethiclogic.helpdesk.entity.EngEntity;
import com.alethiclogic.helpdesk.entity.UserEntity;





public class Miscpanel extends JPanel implements ActionListener,MouseListener
{
	private Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
	private int width = (int) dimension.getWidth();
	private int height = (int) dimension.getHeight();
	
	private JPanel mainpanel =UIHelper.getBoxPanel(new BorderLayout(),Color.white,Color.black);
	private JPanel northpanel =UIHelper.getBoxPanel(new GridLayout(1,2),Color.white,Color.black);
	private JPanel northpanel1 =UIHelper.getBoxPanel(null,Color.white,Color.black);
	private JPanel northpanel2 =UIHelper.getBoxPanel(new BorderLayout(),Color.white,Color.black);
	private JPanel centerpanel =UIHelper.getBoxPanel(new GridLayout(1,2),Color.white,Color.black);
	private JPanel centerpanel1 =UIHelper.getBoxPanel(null,Color.white,Color.black);
	private JPanel centerpanel2 =UIHelper.getBoxPanel(new BorderLayout(),Color.white,Color.black);
	
	
	private Object[] columnNames = new Object[] { "Id","Department","" };
	private DefaultTableModel model;
	private JTable table1;
	private JPanel tablepanel1 = UIHelper.getBoxPanel(new GridLayout(),Color.white,Color.black);
	
	
	private Object[] columnNames1 = new Object[] { "Id","Name","User Name","Department","" };
	private DefaultTableModel model1;
	private JTable table11;
	private JPanel tablepanel11 = UIHelper.getBoxPanel(new GridLayout(),Color.white,Color.black);
	
	
	private JLabel ldepartmentname =new JLabel("Department Name");
	private JTextField fielddepatment =new JTextField();
	private JLabel lempty =new JLabel("");
	private JButton butadddepartment =new JButton("Save");
	private JButton butdeletedept =new JButton("Delete");
	
	private Vector<DepartmentEntity>departmentvector =new Vector<DepartmentEntity>();
	
	private String burl=UIHelper.getBase();
	
	private Boolean deptbool = true;
	private int deptid = 0;
	
	private JLabel lfname =new JLabel("First Name");
	private JLabel llname =new JLabel("Last Name");
	private JLabel ldepartment =new JLabel("Department");
	private JLabel lusername =new JLabel("User Name");
	private JLabel lpassword =new JLabel("Password");
	private JTextField fieldfname =new JTextField();
	private JTextField fieldlname =new JTextField();
	
	private DefaultComboBoxModel dcm =new DefaultComboBoxModel();
	private JComboBox combodepartment =new JComboBox();
	private JCheckBox chbox =new JCheckBox("Is Engineer");
	
	private JTextField fieldusername =new JTextField();
	private JTextField fieldpassword =new JTextField();
	private JLabel lemp =new JLabel("");
	private JButton butaddduser =new JButton("Save");
	private JButton butdeleteuser =new JButton("Delete");
	
	private Boolean userbool = true;
	private int userid = 0;
   private Vector<UserEntity>uservector =new Vector<UserEntity>();
   
   private Vector<EngEntity>EngEntityvector =new Vector<EngEntity>();
	
	public Miscpanel()
	{
		departmentloaddata();
		userloaddata();
		
		northpanel1.setLayout(new BoxLayout(northpanel1, BoxLayout.PAGE_AXIS));

        Component box_1 = Box.createRigidArea(new Dimension(10, 20));
        Box box_2 = Box.createHorizontalBox();
        Component box_3 = Box.createRigidArea(new Dimension(10, 20));
        Box box_4 = Box.createHorizontalBox();
        
        box_2.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox2 = UIHelper.getBoxPanel(new BorderLayout(),Color.white,Color.black);
		JLabel la =new JLabel();
		ldepartmentname.setPreferredSize(new Dimension(150, 25));
		ldepartmentname.setMaximumSize(new Dimension(150, 25));
		fielddepatment.setPreferredSize(new Dimension(250, 25));
		fielddepatment.setMaximumSize(new Dimension(250, 25));
		la.setPreferredSize(new Dimension(150, 25));
		la.setMaximumSize(new Dimension(150, 25));
		pbox2.setMaximumSize(new Dimension(650, 25));
		pbox2.add(ldepartmentname, BorderLayout.WEST);
		pbox2.add(fielddepatment, BorderLayout.CENTER);
		pbox2.add(la, BorderLayout.EAST);
		box_2.add(pbox2);
		box_2.add(Box.createRigidArea(new Dimension(0, 10)));
		
		box_4.add(Box.createRigidArea(new Dimension(20, 0)));
	    JPanel pbox4 = UIHelper.getBoxPanel(new BorderLayout(),Color.white,Color.black);
	    if (butadddepartment.getActionListeners().length == 0)
	    butadddepartment.addActionListener(this);
	    if (butdeletedept.getActionListeners().length == 0)
	    butdeletedept.addActionListener(this);
	    
	    butadddepartment.setPreferredSize(new Dimension(150, 25));
		butadddepartment.setMaximumSize(new Dimension(150, 25));
		butdeletedept.setPreferredSize(new Dimension(150, 25));
		butdeletedept.setMaximumSize(new Dimension(150, 25));
		lempty.setPreferredSize(new Dimension(150, 25));
		lempty.setMaximumSize(new Dimension(150, 25));
		pbox4.setMaximumSize(new Dimension(350, 25));
		pbox4.add(butadddepartment, BorderLayout.WEST);
		pbox4.add(lempty, BorderLayout.CENTER);
		pbox4.add(butdeletedept, BorderLayout.EAST);
		box_4.add(pbox4);
		Font f4=new Font("sana",Font.BOLD,12);
		butdeletedept.setFont(f4);
		butdeletedept.setForeground(new Color(52,152,219));
		Font f5=new Font("sana",Font.BOLD,12);
		butadddepartment.setFont(f5);
		butadddepartment.setForeground(new Color(52,152,219));
		
		box_4.add(Box.createRigidArea(new Dimension(0, 10)));
		
		northpanel1.add(box_1);
		northpanel1.add(box_2);
		northpanel1.add(box_3);
		northpanel1.add(box_4);
	
		table1.addMouseListener(this);
		tablepanel1.add(new JScrollPane(table1));
		northpanel2.add(tablepanel1,BorderLayout.CENTER);
		
		centerpanel1.setLayout(new BoxLayout(centerpanel1, BoxLayout.PAGE_AXIS));

        Component box_5 = Box.createRigidArea(new Dimension(10, 20));
        Box box_6 = Box.createHorizontalBox();
        Component box_7 = Box.createRigidArea(new Dimension(10, 20));
        Box box_8 = Box.createHorizontalBox();
        Component box_9 = Box.createRigidArea(new Dimension(10, 20));
        Box box_10 = Box.createHorizontalBox();
        Component box_11 = Box.createRigidArea(new Dimension(10, 20));
        Box box_12 = Box.createHorizontalBox();
        Component box_13 = Box.createRigidArea(new Dimension(10, 20));
        Box box_14 = Box.createHorizontalBox();
        Component box_15 = Box.createRigidArea(new Dimension(10, 20));
        Box box_16 = Box.createHorizontalBox();
        Component box_17 = Box.createRigidArea(new Dimension(10, 20));
        Box box_18 = Box.createHorizontalBox();
        
        box_6.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox6 = UIHelper.getBoxPanel(new BorderLayout(),Color.white,Color.black);
		JLabel la1 =new JLabel();
		lfname.setPreferredSize(new Dimension(150, 25));
		lfname.setMaximumSize(new Dimension(150, 25));
		fieldfname.setPreferredSize(new Dimension(250, 25));
		fieldfname.setMaximumSize(new Dimension(250, 25));
		la1.setPreferredSize(new Dimension(150, 25));
		la1.setMaximumSize(new Dimension(150, 25));
		pbox6.setMaximumSize(new Dimension(650, 25));
		pbox6.add(lfname, BorderLayout.WEST);
		pbox6.add(fieldfname, BorderLayout.CENTER);
		pbox6.add(la1, BorderLayout.EAST);
		box_6.add(pbox6);
		box_6.add(Box.createRigidArea(new Dimension(0, 10)));
		
	
		box_8.add(Box.createRigidArea(new Dimension(20, 0)));
		JLabel la2 =new JLabel();
		JPanel pbox8 = UIHelper.getBoxPanel(new BorderLayout(),Color.white,Color.black);
		llname.setPreferredSize(new Dimension(150, 25));
		llname.setMaximumSize(new Dimension(150, 25));
		fieldlname.setPreferredSize(new Dimension(250, 25));
		fieldlname.setMaximumSize(new Dimension(250, 25));
		la2.setPreferredSize(new Dimension(150, 25));
		la2.setMaximumSize(new Dimension(150, 25));
		pbox8.setMaximumSize(new Dimension(650, 25));
		pbox8.add(llname, BorderLayout.WEST);
		pbox8.add(fieldlname, BorderLayout.CENTER);
		pbox8.add(la2, BorderLayout.EAST);
		box_8.add(pbox8);
		box_8.add(Box.createRigidArea(new Dimension(0, 10)));
		
	
		box_10.add(Box.createRigidArea(new Dimension(20, 0)));
		JLabel la3 =new JLabel();
		JPanel pbox10 = UIHelper.getBoxPanel(new BorderLayout(),Color.white,Color.black);
		ldepartment.setPreferredSize(new Dimension(150, 25));
		ldepartment.setMaximumSize(new Dimension(150, 25));
		combodepartment.setPreferredSize(new Dimension(250, 25));
		combodepartment.setMaximumSize(new Dimension(250, 25));
		la3.setPreferredSize(new Dimension(150, 25));
		la3.setMaximumSize(new Dimension(150, 25));
		pbox10.setMaximumSize(new Dimension(650, 25));
		pbox10.add(ldepartment, BorderLayout.WEST);
		pbox10.add(combodepartment, BorderLayout.CENTER);
		pbox10.add(la3, BorderLayout.EAST);
		box_10.add(pbox10);
		box_10.add(Box.createRigidArea(new Dimension(0, 10)));
		
	
		box_12.add(Box.createRigidArea(new Dimension(20, 0)));
		JLabel la4 =new JLabel();
		JPanel pbox12 = UIHelper.getBoxPanel(new BorderLayout(),Color.white,Color.black);
		lusername.setPreferredSize(new Dimension(150, 25));
		lusername.setMaximumSize(new Dimension(150, 25));
		fieldusername.setPreferredSize(new Dimension(250, 25));
		fieldusername.setMaximumSize(new Dimension(250, 25));
		la4.setPreferredSize(new Dimension(150, 25));
		la4.setMaximumSize(new Dimension(150, 25));
		pbox12.setMaximumSize(new Dimension(650, 25));
		pbox12.add(lusername, BorderLayout.WEST);
		pbox12.add(fieldusername, BorderLayout.CENTER);
		pbox12.add(la4, BorderLayout.EAST);
		box_12.add(pbox12);
		box_12.add(Box.createRigidArea(new Dimension(0, 10)));
		
		
		box_14.add(Box.createRigidArea(new Dimension(20, 0)));
		JLabel la5 =new JLabel();
		JPanel pbox14 = UIHelper.getBoxPanel(new BorderLayout(),Color.white,Color.black);
		lpassword.setPreferredSize(new Dimension(150, 25));
		lpassword.setMaximumSize(new Dimension(150, 25));
		fieldpassword.setPreferredSize(new Dimension(250, 25));
		fieldpassword.setMaximumSize(new Dimension(250, 25));
		la5.setPreferredSize(new Dimension(150, 25));
		la5.setMaximumSize(new Dimension(150, 25));
		pbox14.setMaximumSize(new Dimension(650, 25));
		pbox14.add(lpassword, BorderLayout.WEST);
		pbox14.add(fieldpassword, BorderLayout.CENTER);
		pbox14.add(la5, BorderLayout.EAST);
		box_14.add(pbox14);
		box_14.add(Box.createRigidArea(new Dimension(0, 10)));
		
		
		box_18.add(Box.createRigidArea(new Dimension(20, 0)));
		JLabel la6 =new JLabel();
		JLabel la7 =new JLabel();
		JPanel pbox18 = UIHelper.getBoxPanel(new BorderLayout(),Color.white,Color.black);
		la7.setPreferredSize(new Dimension(150, 25));
		la7.setMaximumSize(new Dimension(150, 25));
		chbox.setPreferredSize(new Dimension(250, 25));
		chbox.setMaximumSize(new Dimension(250, 25));
		chbox.setBackground(Color.white);
		la6.setPreferredSize(new Dimension(150, 25));
		la6.setMaximumSize(new Dimension(150, 25));
		pbox18.setMaximumSize(new Dimension(650, 25));
		pbox18.add(la7, BorderLayout.WEST);
		pbox18.add(chbox, BorderLayout.CENTER);
		pbox18.add(la6, BorderLayout.EAST);
		box_18.add(pbox18);
		box_18.add(Box.createRigidArea(new Dimension(0, 10)));
		
		box_16.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox16 = UIHelper.getBoxPanel(new BorderLayout(),Color.white,Color.black);
		if(butaddduser.getActionListeners().length == 0)
		butaddduser.addActionListener(this);
		if(butdeleteuser.getActionListeners().length == 0)
		butdeleteuser.addActionListener(this);
		
		butaddduser.setPreferredSize(new Dimension(150, 25));
		butaddduser.setMaximumSize(new Dimension(150, 25));
		butdeleteuser.setPreferredSize(new Dimension(150, 25));
		butdeleteuser.setMaximumSize(new Dimension(150, 25));
		lemp.setPreferredSize(new Dimension(250, 25));
		lemp.setMaximumSize(new Dimension(250, 25));
		pbox16.setMaximumSize(new Dimension(350, 25));
		pbox16.add(butaddduser, BorderLayout.WEST);
		pbox16.add(lemp, BorderLayout.CENTER);
		pbox16.add(butdeleteuser, BorderLayout.EAST);
		box_16.add(pbox16);
		Font f16=new Font("sana",Font.BOLD,12);
		butaddduser.setFont(f16);
		butaddduser.setForeground(new Color(52,152,219));
		Font f17=new Font("sana",Font.BOLD,12);
		butdeleteuser.setFont(f17);
		butdeleteuser.setForeground(new Color(52,152,219));
		box_16.add(Box.createRigidArea(new Dimension(0, 10)));
		
	
		centerpanel1.add(box_5);
		centerpanel1.add(box_6);
		centerpanel1.add(box_7);
		centerpanel1.add(box_8);
		centerpanel1.add(box_9);
		centerpanel1.add(box_10);
		centerpanel1.add(box_11);
		centerpanel1.add(box_12);
		centerpanel1.add(box_13);
		centerpanel1.add(box_14);
		centerpanel1.add(box_17);
		centerpanel1.add(box_18);
		centerpanel1.add(box_15);
		centerpanel1.add(box_16);
		
		table11.addMouseListener(this);
		tablepanel11.add(new JScrollPane(table11));
		centerpanel2.add(tablepanel11,BorderLayout.CENTER);
		
		northpanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEmptyBorder(),"Department"));
		centerpanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEmptyBorder(),"User"));
		//northpanel1.setBorder(BorderFactory.createRaisedBevelBorder());
		//northpanel2.setBorder(BorderFactory.createRaisedBevelBorder());
		//centerpanel1.setBorder(BorderFactory.createRaisedBevelBorder());
		//centerpanel2.setBorder(BorderFactory.createRaisedBevelBorder());
		
		northpanel.add(northpanel1);
		northpanel.add(northpanel2);
		centerpanel.add(centerpanel1);
		centerpanel.add(centerpanel2);
		
		northpanel.setPreferredSize(new Dimension(width,height-600));
		centerpanel.setPreferredSize(new Dimension(width,height-290));
		mainpanel.add(northpanel,BorderLayout.NORTH);
		mainpanel.add(centerpanel,BorderLayout.CENTER);
		
		add(mainpanel);
		mainpanel.setOpaque(true);
		setSize(width, height);
		setVisible(true);
			
	}
	private void departmentloaddata()
	{
		departmentvector.clear();
		try {
			
			dcm.removeAllElements();
			HttpClient client = new DefaultHttpClient();
			HttpGet request = new HttpGet(
					burl + "query/javadept.php");
			HttpResponse response = client.execute(request);
			BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));

			StringBuffer buffer = new StringBuffer();

			String line = "";
			String ss = "";
			while ((line = rd.readLine()) != null) {
				buffer.append(line);
				ss = ss + line;
			}

			if (!ss.isEmpty()) {

				String[] namevaluePairs = buffer.toString().split("\\-\\-");

				for (String namevaluePair : namevaluePairs) {
					if (namevaluePair.contains("|")) {
						String[] pairArray = namevaluePair.split("\\|");
						
						DepartmentEntity ce = new DepartmentEntity();
					
						ce.setId(pairArray[0]);
						ce.setDepartment(pairArray[1]);
						
						dcm.addElement(ce);
						combodepartment = new JComboBox(dcm);
						
						departmentvector.add(ce);
				
					}
				}
			}

		} catch (IOException e3) {
			e3.printStackTrace();
		}

		int address = departmentvector.size();

		Object[][] columnData = new Object[address][3];

		for (int i = 0; i < address; i++) {
			columnData[i] = departmentvector.get(i).getdepartmentdetails();
		}

		if (model == null) {
			model = new DefaultTableModel(columnData, columnNames) {
				@Override
				public boolean isCellEditable(int row, int col1) {
					if (col1 < 2)
						return false;
					return true;
				}

				@Override
				public Class getColumnClass(int c) {
					try {
						return getValueAt(0, c).getClass();
					} catch (Exception exception) {
						return String.class;
					}
				}
			};
		} else {
			model.setDataVector(columnData, columnNames);
		}
		if (table1 == null)
			table1 = new JTable(model);

		table1.updateUI();
	
	}
	
	private void userloaddata()
	{
		try {
			EngEntityvector.clear();
			HttpClient client = new DefaultHttpClient();
			HttpGet request = new HttpGet(
					burl + "query/javamisceng.php");
			HttpResponse response = client.execute(request);
			BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));

			//uservector = new Vector<UserEntity>();
			StringBuffer buffer = new StringBuffer();

			String line = "";
			String ss = "";
			while ((line = rd.readLine()) != null) {
				buffer.append(line);
				ss = ss + line;
			}

			if (!ss.isEmpty()) {

				String[] namevaluePairs = buffer.toString().split("\\-\\-");

				for (String namevaluePair : namevaluePairs) {
					if (namevaluePair.contains("|")) {
						String[] pairArray = namevaluePair.split("\\|");

						EngEntity ce = new EngEntity();

						ce.setId(pairArray[0]);
						ce.setFname(pairArray[1]);
						ce.setLname(pairArray[2]);
						ce.setUsername(pairArray[3]);
						ce.setDepartment(pairArray[4]);
					
						EngEntityvector.add(ce);
					}
				}
			}

		} catch (IOException e3) {
			e3.printStackTrace();
		}

		int address = EngEntityvector.size();

		Object[][] columnData = new Object[address][5];

		for (int i = 0; i < address; i++) {
			columnData[i] = EngEntityvector.get(i).getengdetails();
		}

		if (model1 == null) {
			model1 = new DefaultTableModel(columnData, columnNames1) {
				@Override
				public boolean isCellEditable(int row, int col1) {
					if (col1 < 4)
						return false;
					return true;
				}

				@Override
				public Class getColumnClass(int c) {
					try {
						return getValueAt(0, c).getClass();
					} catch (Exception exception) {
						return String.class;
					}
				}
			};
		} else {
			model1.setDataVector(columnData, columnNames1);
		}
		if (table11 == null)
			table11 = new JTable(model1);

		table11.updateUI();
		
	}
	
	public static void main(String args[])
	{
		Miscpanel miscpanel =new Miscpanel();
	}
	
	@Override
	public void mouseClicked(MouseEvent e) 
	{
		if(e.getSource().equals(table1))
		{
			int selectedRow = table1.getSelectedRow();

			if (selectedRow > -1) {
				int tableId = 0;
				try {

					if (selectedRow > -1) {
						tableId = (int) Integer.parseInt((table1.getValueAt(
								selectedRow, 0)).toString());
						deptid = tableId;
					}
				
					HttpClient client = new DefaultHttpClient();
					HttpPost post = new HttpPost(
							burl + "query/javagdept.php");

					List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
					nameValuePairs.add(new BasicNameValuePair("id",String.valueOf(deptid)));
					post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
					HttpResponse response = client.execute(post);
					BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));

					StringBuffer buffer = new StringBuffer();

					String line = "";
					while ((line = rd.readLine()) != null) {
						buffer.append(line);
					}
        
					String[] namevaluePairs = buffer.toString().split("\\-\\-");

					for (String namevaluePair : namevaluePairs) {
						String[] pairArray = namevaluePair.split("\\|");

						
						fielddepatment.setText(pairArray[0]);
					}

					deptbool = false;

				} catch (IOException e3) {
					e3.printStackTrace();
				}
			}
		
		}	
		else if(e.getSource().equals(table11))
		{
			
			fieldusername.setEditable(false);
			fieldpassword.setEditable(false);
			
			int selectedRow = table11.getSelectedRow();

			if (selectedRow > -1) {
				int tableId = 0;
				try {

					if (selectedRow > -1) {
						tableId = (int) Integer.parseInt((table11.getValueAt(
								selectedRow, 0)).toString());
						userid = tableId;
					}
					
					HttpClient client = new DefaultHttpClient();
					HttpPost post = new HttpPost(
							burl + "query/javagengine.php");

					List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
					nameValuePairs.add(new BasicNameValuePair("id",String.valueOf(userid)));
					post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
					HttpResponse response = client.execute(post);
					BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));

					StringBuffer buffer = new StringBuffer();

					String line = "";
					while ((line = rd.readLine()) != null) {
						buffer.append(line);
					}
				
					String[] namevaluePairs = buffer.toString().split("\\-\\-");

					for (String namevaluePair : namevaluePairs) {
						String[] pairArray = namevaluePair.split("\\|");

						fieldfname.setText(pairArray[0]);
						fieldlname.setText(pairArray[1]);
						combodepartment.setSelectedItem(pairArray[2]);
						chbox.setSelected(true);
					}

					userbool = false;

				} catch (IOException e3) {
					e3.printStackTrace();
				}
			}
		
		}
	}
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource().equals(butadddepartment))
		{

			if(deptbool)
			{				
				HttpClient client = new DefaultHttpClient();
				HttpPost post = new HttpPost(
						burl + "query/insertdepartment.php");
	
				try {
	
					List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
					
					nameValuePairs.add(new BasicNameValuePair("addedit", "-1"));
					nameValuePairs.add(new BasicNameValuePair("txtdeptname",fielddepatment.getText()));
				
					post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
					HttpResponse response = client.execute(post);
					BufferedReader rd = new BufferedReader(new InputStreamReader(
							response.getEntity().getContent()));
	
					String line = "";
					while ((line = rd.readLine()) != null) {
					
					}
					fielddepatment.setText("");
					
					departmentloaddata();
				
				} catch (IOException e3) {
					e3.printStackTrace();
				}
			}
			else	
			{
				
				
				HttpClient client = new DefaultHttpClient();
				HttpPost post = new HttpPost(
						burl + "query/insertdepartment.php");
	
				try {
	
					List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
					
					nameValuePairs.add(new BasicNameValuePair("addedit",String.valueOf(deptid)));
					nameValuePairs.add(new BasicNameValuePair("txtdeptname",fielddepatment.getText()));
				
					post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
					HttpResponse response = client.execute(post);
					BufferedReader rd = new BufferedReader(new InputStreamReader(
							response.getEntity().getContent()));
	
					String line = "";
					while ((line = rd.readLine()) != null) {
					
					}
					fielddepatment.setText("");
					
					deptbool = true;
					departmentloaddata();
				
				} catch (IOException e3) {
					e3.printStackTrace();
				}
			
				
			}
			
		}
		else if(e.getSource().equals(butdeletedept))
		{
			String line = "";
			int tableId = 0;
			try {

				int srow = table1.getSelectedRow();
				if (srow > -1) {
					tableId = (int) Integer.parseInt((table1.getValueAt(
							srow, 0)).toString());
				}
				
				HttpClient client = new DefaultHttpClient();
				HttpPost request = new HttpPost(
						burl + "query/javadeletedept.php");
				List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(
						1);
				nameValuePairs.add(new BasicNameValuePair("id", Integer.toString(tableId)));

				request.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse response = client.execute(request);
				BufferedReader rd = new BufferedReader(new InputStreamReader(response
						.getEntity().getContent()));
				
				fielddepatment.setText("");
				
			departmentloaddata();

			} catch (ClientProtocolException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			} catch (IOException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
		}
		else if(e.getSource().equals(butdeleteuser))
		{
			String line = "";
			int tableId = 0;
			try {

				int srow = table11.getSelectedRow();
				if (srow > -1) {
					tableId = (int) Integer.parseInt((table11.getValueAt(
							srow, 0)).toString());
				}
				
				HttpClient client = new DefaultHttpClient();
				HttpPost request = new HttpPost(
						burl + "query/javadeleteengine.php");
				List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(
						1);
				nameValuePairs.add(new BasicNameValuePair("id", Integer.toString(tableId)));

				request.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse response = client.execute(request);
				BufferedReader rd = new BufferedReader(new InputStreamReader(response
						.getEntity().getContent()));
				
				fieldfname.setText("");
				fieldlname.setText("");
				chbox.setSelected(false);
				combodepartment.setSelectedIndex(0);
			
		     	userloaddata();

			} catch (ClientProtocolException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			} catch (IOException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
			
			
		}
		else if(e.getSource().equals(butaddduser))
		{
			if(chbox.isSelected())
			{
				if (userbool) 
				{
					
					HttpClient client = new DefaultHttpClient();
					HttpPost post = new HttpPost(
							burl + "query/insertengine.php");
	
					try {
	
						List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(
								1);
						nameValuePairs.add(new BasicNameValuePair("addedit", "-1"));
						nameValuePairs.add(new BasicNameValuePair("txtefname",
								fieldfname.getText()));
						nameValuePairs.add(new BasicNameValuePair("txtelname",
								fieldlname.getText()));
	
						nameValuePairs.add(new BasicNameValuePair("seledept",
								((DepartmentEntity) combodepartment.getSelectedItem())
										.getId()));
						nameValuePairs.add(new BasicNameValuePair("txteuname",
								fieldusername.getText()));
						nameValuePairs.add(new BasicNameValuePair("txtepword",
								fieldpassword.getText()));
						// cbudept.getSelectedItem().toString()
	
						post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
						HttpResponse response = client.execute(post);
						BufferedReader rd = new BufferedReader(
								new InputStreamReader(response.getEntity()
										.getContent()));
	
						String line = "";
						while ((line = rd.readLine()) != null) {
							System.out.println(line);
	
						}
	
						fieldfname.setText("");
						fieldlname.setText("");
						fieldusername.setText("");
						fieldpassword.setText("");
						chbox.setSelected(false);
							
						userloaddata();
	
					} catch (IOException e3) {
						e3.printStackTrace();
					}
				} else {
					
					fieldusername.setEditable(true);
					fieldpassword.setEditable(true);
					
					HttpClient client = new DefaultHttpClient();
					HttpPost post = new HttpPost(
							burl + "query/insertengine.php");
	
					try {
	
						List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(
								1);
						nameValuePairs.add(new BasicNameValuePair("addedit", String
								.valueOf(userid)));
						nameValuePairs.add(new BasicNameValuePair("txtefname",
								fieldfname.getText()));
						nameValuePairs.add(new BasicNameValuePair("txtelname",
								fieldlname.getText()));
	
						nameValuePairs.add(new BasicNameValuePair("seledept",
								((DepartmentEntity) combodepartment.getSelectedItem())
										.getId()));
					
	
						post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
						HttpResponse response = client.execute(post);
						BufferedReader rd = new BufferedReader(
								new InputStreamReader(response.getEntity()
										.getContent()));
	
						String line = "";
						while ((line = rd.readLine()) != null) {
							System.out.println(line);
	
						}
	
						fieldfname.setText("");
						fieldlname.setText("");
						fieldusername.setText("");
						fieldpassword.setText("");
						chbox.setSelected(false);
						userloaddata();
						userbool = true;
						userid = 0;
						
	
					} catch (IOException e3) {
						e3.printStackTrace();
					}
				}
			}
			else
			{
				if (userbool) 
				{
					
					HttpClient client = new DefaultHttpClient();
					HttpPost post = new HttpPost(
							burl + "query/insertemp.php");
	
					try {
	
						List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(
								1);
						nameValuePairs.add(new BasicNameValuePair("addedit", "-1"));
						nameValuePairs.add(new BasicNameValuePair("txtufname",
								fieldfname.getText()));
						nameValuePairs.add(new BasicNameValuePair("txtulname",
								fieldlname.getText()));
	
						nameValuePairs.add(new BasicNameValuePair("seludept",
								((DepartmentEntity) combodepartment.getSelectedItem())
										.getId()));
						nameValuePairs.add(new BasicNameValuePair("txtuuname",
								fieldusername.getText()));
						nameValuePairs.add(new BasicNameValuePair("txtupword",
								fieldpassword.getText()));
						// cbudept.getSelectedItem().toString()
	
						post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
						HttpResponse response = client.execute(post);
						BufferedReader rd = new BufferedReader(
								new InputStreamReader(response.getEntity()
										.getContent()));
	
						String line = "";
						while ((line = rd.readLine()) != null) {
							System.out.println(line);
	
						}
	
						fieldfname.setText("");
						fieldlname.setText("");
						fieldusername.setText("");
						fieldpassword.setText("");
						chbox.setSelected(false);
							
						userloaddata();
	
					} catch (IOException e3) {
						e3.printStackTrace();
					}
				} else {
					
					fieldusername.setEditable(true);
					fieldpassword.setEditable(true);
					
					HttpClient client = new DefaultHttpClient();
					
					HttpPost post = new HttpPost(burl + "query/insertemp.php");
	
					try {
	
						List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(
								1);
						nameValuePairs.add(new BasicNameValuePair("addedit", String
								.valueOf(userid)));
						nameValuePairs.add(new BasicNameValuePair("txtufname",
								fieldfname.getText()));
						nameValuePairs.add(new BasicNameValuePair("txtulname",
								fieldlname.getText()));
	
						nameValuePairs.add(new BasicNameValuePair("seludept",
								((DepartmentEntity) combodepartment.getSelectedItem())
										.getId()));
					
	
						post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
						HttpResponse response = client.execute(post);
						BufferedReader rd = new BufferedReader(
								new InputStreamReader(response.getEntity()
										.getContent()));
	
						String line = "";
						while ((line = rd.readLine()) != null) {
							System.out.println(line);
	
						}
	
						fieldfname.setText("");
						fieldlname.setText("");
						fieldusername.setText("");
						fieldpassword.setText("");
						chbox.setSelected(false);
	
						userloaddata();
						userbool = true;
						userid = 0;
						
	
					} catch (IOException e3) {
						e3.printStackTrace();
					}
				}
			}
				
			
		}
		
	}

/*	public void loadScreen()
	{
		removeAll();
		add(mainpanel);
		add(UIHelper.getJobPanel(UIHelper.STATUS_CLOSED, this),BorderLayout.WEST);
		updateUI();
	}*/

}


