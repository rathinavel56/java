package com.alethiclogic.helpdesk.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.LayoutManager;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListCellRenderer;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import sun.reflect.ReflectionFactory.GetReflectionFactoryAction;

import com.alethiclogic.helpdesk.entity.EngineerEntity;
import com.sun.awt.AWTUtilities;

public class UIHelper

{

	private static Dimension dimension = Toolkit.getDefaultToolkit()
			.getScreenSize();

	private static int width = (int) dimension.getWidth();
	private static int height = (int) dimension.getHeight();
	private static String jno;
	private static int stat;
	private static int noteHeight;
	private static int attachmentHeight;
	private static int stats;
	
	// private static JDateChooser datecub=new JDateChooser();


	
	public static String base;
	public static String user;
	public static String loguid;

	static {
		File file = new File("helpdesk.props");
		Properties properties = new Properties();

		if (file.exists()) {
			try {
				properties.load(new FileInputStream(file));
				base = (String) properties.get("base");

				if (base == null) {
					base = JOptionPane
							.showInputDialog("Please enter the base server link: eg:www.helpdesk.com/");

					if (base == null) {
						JOptionPane
								.showMessageDialog(null,
										"Unable to open applicatoon. Please contact adminsitrator");
						System.exit(0);
					}

					FileOutputStream fileOutputStream = new FileOutputStream(
							file);

					properties.put("base", base);
					properties.save(fileOutputStream, "Help Desk Proeprties");

					fileOutputStream.close();
				}
			} catch (Exception e) {
				e.printStackTrace();

				JOptionPane
						.showMessageDialog(null,
								"Unable to open applicatoon. Please contact adminsitrator");
				System.exit(0);
			}
		} else {
			try {
				base = JOptionPane
						.showInputDialog("Please enter the base server link: eg:www.helpdesk.com/");

				if (base == null) {
					JOptionPane
							.showMessageDialog(null,
									"Unable to open applicatoon. Please contact adminsitrator");
					System.exit(0);
				}

				FileOutputStream fileOutputStream = new FileOutputStream(file);

				properties.put("base", base);
				properties.save(fileOutputStream, "Help Desk Proeprties");

				fileOutputStream.close();
			} catch (Exception e) {
				e.printStackTrace();

				JOptionPane
						.showMessageDialog(null,
								"Unable to open applicatoon. Please contact adminsitrator");
				System.exit(0);
			}
		}
	}

	public static JPanel getJobPanel(final int status,
			final MouseListener mouseListener) {

		return getJobPanel(status, mouseListener, null);
	}

	public static JPanel getJobPanel(final int status,
			final MouseListener mouseListener, final String eid) {
		JPanel westPanel = UIHelper.getBoxPanel(new BorderLayout(),
				Color.white, Color.black);
		final JPanel holderPanel = UIHelper.getBoxPanel(new VerticalFlowLayout(
				FlowLayout.LEFT), Color.white, Color.black);

		JPanel searchPanel = UIHelper.getBoxPanel(new BorderLayout(),
				Color.white, Color.black);
		final JTextField searchField = new JTextField();
		JButton searchButton = new JButton("Go");

		searchPanel.add(searchField, BorderLayout.CENTER);
		searchPanel.add(searchButton, BorderLayout.EAST);

		stats=status;
		
		try {
			String url = "";

			switch (status) {
			case STATUS_HOME:
				url = base + "query/javamainpage.php";
				break;
			case STATUS_ASSIGNED:
				url = base + "query/javaassigned.php"
						+ (eid == null ? "" : "?eid=" + eid);
				break;
			case STATUS_COMPLETED:
				url = base + "query/javacompleted.php";
				break;
			case STATUS_CLOSED:
				url = base + "query/javaclosed.php";
				break;
			}

			HttpClient client = new DefaultHttpClient();
			HttpGet request = new HttpGet(url);
			HttpResponse response = client.execute(request);
			BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));

			StringBuffer stringBuffer = new StringBuffer();
			String line = null;

			while ((line = rd.readLine()) != null) {
				stringBuffer.append(line);
			}

			String[] jobs = stringBuffer.toString().split("--");

			for (String job : jobs) {
				if (job.contains("|")) {

					JobPanel jobPanel = new JobPanel(job);
					holderPanel.add(jobPanel);
					jobPanel.addMouseListener(mouseListener);
					
					if (mouseListener instanceof HomePanel)
					{
						((HomePanel) mouseListener).addJob(jobPanel);
					}
					else if (mouseListener instanceof Assignedpanel)
					{
						((Assignedpanel) mouseListener).addJob(jobPanel);
					}
					else if (mouseListener instanceof CompletedPanel)
					{
						((CompletedPanel) mouseListener).addJob(jobPanel);
					}
					else if (mouseListener instanceof ClosedPanel)
					{
						((ClosedPanel) mouseListener).addJob(jobPanel);
					}
				}
			}

		} catch (Exception exception) {
			exception.printStackTrace();
		}

		searchButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				holderPanel.removeAll();

				String searchTerm = searchField.getText();

				try {
					String url = "";
					
					switch (status) {
					case 0:
						url = base + "query/javasearchmainpage.php?input="
								+ searchTerm.replaceAll(" ", "%20");
						break;
						
					case 1:
						url = base + "query/javasearchassigned.php?input="
								+ searchTerm.replaceAll(" ", "%20");
						break;
					case 2:
						url = base + "query/javasearchcompleted.php?input="
								+ searchTerm.replaceAll(" ", "%20");
						break;
					case 3:
						url = base + "query/javasearchclosed.php?input="
								+ searchTerm.replaceAll(" ", "%20");
						break;
						
					}
					
					System.out.println(url);

					HttpClient client = new DefaultHttpClient();
					HttpGet request = new HttpGet(url);
					HttpResponse response = client.execute(request);
					BufferedReader rd = new BufferedReader(
							new InputStreamReader(response.getEntity()
									.getContent()));

					StringBuffer stringBuffer = new StringBuffer();
					String line = null;

					while ((line = rd.readLine()) != null) {
						stringBuffer.append(line);
					}

					String[] jobs = stringBuffer.toString().split("--");

					for (String job : jobs) {
						if (job.contains("|")) {
							System.out.println(job);
							JobPanel jobPanel = new JobPanel(job);
							holderPanel.add(jobPanel);
							jobPanel.addMouseListener(mouseListener);
						}
					}

					holderPanel.updateUI();
				} catch (Exception exception) {
					exception.printStackTrace();
				}
			}
		});

		westPanel.add(new JScrollPane(holderPanel), BorderLayout.CENTER);
		westPanel.add(searchPanel, BorderLayout.SOUTH);

		westPanel.setPreferredSize(new Dimension(250, height - 120));

		return westPanel;
	}

	public static JPanel getJobDetails(int status, String jobNo, final JPanel holderPanel) {
		jno = jobNo;
		stat=status;
		final XDateChooser datecub = new XDateChooser();
		JButton save = new JButton("Edit");
		final JLabel comdate=new JLabel("Demo");
		final JLabel label_name = new JLabel("Name");
		final JLabel proplabel = new JLabel("");
		final JLabel empproperty1 = new JLabel("");
		final JLabel empproperty2 = new JLabel("");
		final JLabel empproperty3 = new JLabel("Completion Date : ");
		final JTextField label_name1 = new JTextField();
		final JLabel label_street = new JLabel("Street");
		final JTextField label_street1 = new JTextField("Street1");
		final JLabel label_town = new JLabel("Town");
		final JTextField label_town1 = new JTextField("Town1");
		final JLabel label_city = new JLabel("City");
		final JTextField label_city1 = new JTextField("City1");
		final JLabel label_repair = new JLabel("Repair");

		final MultipleVisitButton label_img;

		final JLabel label_time = new JLabel("");
		final JLabel label_date = new JLabel("");
		final JLabel label_code = new JLabel("Code :");
		final JComboBox label_code1 = new JComboBox();
		final JLabel label_status = new JLabel("Status :");
		final JLabel label_status1 = new JLabel("Status1");
		final JLabel label1 = new JLabel("");
		final JLabel label2 = new JLabel("");
		final JLabel label_priority = new JLabel("Priority :");
		final JComboBox ampm=new JComboBox();
		final JComboBox label_priority1 = new JComboBox();
		final JLabel label_area = new JLabel("Area :");
		final JComboBox label_area1 = arealoaddata();
		final JLabel label_date1 = new JLabel("");
		// JLabel label_date2 =new JLabel("");
		final JLabel label_date3 = new JLabel("Appointment Date : ");
		final JLabel label_date4 = new JLabel("Date");
		final JLabel add=new JLabel("Edit");
		final JLabel add1=new JLabel("Edit");
		final JLabel add2=new JLabel("Edit");
		

		final JLabel messageLabel = new JLabel();
		messageLabel.setForeground(new Color(52, 152, 219));

		label_code1.addItem("1");
		label_code1.addItem("2");
		label_code1.addItem("3");
		label_code1.addItem("4");
		label_code1.addItem("5");
		
		label_name1.setEditable(false);

		JLabel label_centttime = new JLabel("Time");
		JLabel label_centdate = new JLabel("Date");
		JLabel label_centraised = new JLabel("Raised by :");
		JLabel label_centraised1 = new JLabel("raised");
		JLabel label_reportedby = new JLabel("Reported by :");
		JLabel label_reportedby1 = new JLabel("Reported");
		JLabel label_centworkorder = new JLabel("Works Order no :");
		JLabel label_centworkorder1 = new JLabel("work");

		final JTextArea workDescriptionArea = new JTextArea();
		JPanel areapanel1 = UIHelper.getBoxPanel(new GridLayout(), Color.white,
				null);
		JPanel noteDetailPanel = getNotePanels(jobNo);

		noteDetailPanel.setBackground(Color.white);
		noteDetailPanel.setForeground(Color.black);

		JPanel jobDetailPanel = UIHelper.getBoxPanel(null,
				new Color(236, 233, 216), Color.black);
		JPanel centercenterpanel1 = UIHelper.getBoxPanel(new BorderLayout(),
				new Color(236, 233, 216), Color.black);
		JPanel centercenterpanel1a = UIHelper.getBoxPanel(new GridLayout(6, 3),
				new Color(236, 233, 216), Color.black);
		JPanel centercenterpanel1b = UIHelper.getBoxPanel(new GridLayout(4,4),
				new Color(236, 233, 216), Color.black);
		JPanel centercenterpanel1c = UIHelper.getBoxPanel(new FlowLayout(
				FlowLayout.LEFT, 25, 5), new Color(236, 233, 216), Color.black);

		JPanel centercenterpanel2 = UIHelper.getBoxPanel(new BorderLayout(), Color.white, Color.black);
		JPanel centercenterpanel2areapanel1 = UIHelper.getBoxPanel(
				new BorderLayout(), Color.white, Color.black);
		JPanel centercenterpanel2areapanel2 = UIHelper.getBoxPanel(
				new BorderLayout(), Color.white, Color.black);

		JPanel centercenterpanel3 = UIHelper.getBoxPanel(new BorderLayout(),
				Color.white, Color.black);
		JPanel attachmentDetailsPanel = UIHelper.getAttachmentsPanels(jobNo);

		JPanel centercenterpanel3panel1a = UIHelper.getBoxPanel(null,
				Color.white, Color.black);
		JPanel centercenterpanel3panel1b = UIHelper.getBoxPanel(null,
				Color.white, Color.black);
		JPanel centercenterpanel3panel1c = UIHelper.getBoxPanel(null,
				Color.white, Color.black);
		JPanel centerinner = UIHelper.getBoxPanel(new BorderLayout(),
				Color.white, Color.black);

		final JTextArea area = new JTextArea();
		area.setPreferredSize(new Dimension(405, 100));
		JButton save1 = new JButton("Save");
		save1.setPreferredSize(new Dimension(75, 25));
		JButton save2 = new JButton("Save");
		final JTextArea area2 = new JTextArea();
		save2.setPreferredSize(new Dimension(75, 25));
		area2.setPreferredSize(new Dimension(405, 100));
		// area.setBorder(BorderFactory.createRaisedBevelBorder());
		// area2.setBorder(BorderFactory.createRaisedBevelBorder());

		// area.setEditable(false);

		JPanel centercenterpanel3panel2 = UIHelper.getBoxPanel(new GridLayout(
				1, 1), Color.white, Color.black);
		JPanel centercenterpanel3panel2a = UIHelper.getBoxPanel(
				new BorderLayout(), Color.white, Color.black);
		JPanel centercenterpanel3panel2b = UIHelper.getBoxPanel(null,
				Color.white, Color.black);

		centercenterpanel1.setBorder(BorderFactory.createRaisedBevelBorder());
		centercenterpanel3.setBorder(BorderFactory.createRaisedBevelBorder());

		centercenterpanel1.setPreferredSize(new Dimension(width - 300, 150));
		//centercenterpanel2.setPreferredSize(new Dimension(width - 300, 300));
		centercenterpanel3.setPreferredSize(new Dimension(width - 300, attachmentHeight + 250));

		JPanel center = UIHelper.getBoxPanel(new GridLayout(), Color.white,
				Color.black);
		JPanel centerwest = UIHelper.getBoxPanel(new BorderLayout(),
				Color.white, Color.black);
		JPanel centersouth = UIHelper.getBoxPanel(new BorderLayout(),
				Color.white, Color.black);
		JPanel centersouth2 = UIHelper.getBoxPanel(new BorderLayout(),
				Color.white, Color.black);
		JPanel centersouth1 = UIHelper.getBoxPanel(new BorderLayout(),
				Color.white, Color.black);
		JPanel centercenter = UIHelper.getBoxPanel(new BorderLayout(),
				Color.white, Color.black);
		center.setPreferredSize(new Dimension(width - 200, 200));
		centerwest.setPreferredSize(new Dimension(width - 100, 100));
		centercenter.setPreferredSize(new Dimension(width - 100, 100));
		centersouth.setPreferredSize(new Dimension(75, 28));
		centersouth2.setPreferredSize(new Dimension(75, 25));
		centersouth1.setPreferredSize(new Dimension(75, 25));

		/*
		 * centercenterpanel1b.add(property1,BorderLayout.WEST);
		 * centercenterpanel2areapanel1
		 * .setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		 */
		//centercenterpanel2areapanel1.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEmptyBorder(),"Work Details"));
		
		JPanel addpanel2 = UIHelper.getBoxPanel(new BorderLayout(),	Color.white, Color.black);
		JPanel worksbutpanel=new JPanel(new BorderLayout());
		
		JLabel wimage=new JLabel("Work Details : ");
		add2.setForeground(new Color(52,152,219));
		add2.setBackground(Color.white);
		wimage.setBackground(Color.white);
		worksbutpanel.setBackground(Color.white);
		
		add2.setOpaque(true);
		wimage.setOpaque(true);
		
		worksbutpanel.add(wimage,BorderLayout.WEST);
		worksbutpanel.add(add2,BorderLayout.EAST);
		addpanel2.setPreferredSize(new Dimension(200,30));
		addpanel2.add(worksbutpanel,BorderLayout.WEST);
		centercenterpanel2areapanel1.add(addpanel2,BorderLayout.NORTH);
		centercenterpanel2areapanel1.add(areapanel1,BorderLayout.CENTER);
		
		
		//workDescriptionArea.setEditable(false);
		areapanel1.add(new JScrollPane(workDescriptionArea));
		centercenterpanel2areapanel1.add(areapanel1, BorderLayout.CENTER);
		
		JPanel addpanel1 = UIHelper.getBoxPanel(new BorderLayout(),	Color.white, Color.black);
		JPanel notesbutpanel=new JPanel(new BorderLayout());
		
		JLabel nimage=new JLabel("Attached Notes : ");
		add.setForeground(new Color(52,152,219));
		add.setBackground(Color.white);
		nimage.setBackground(Color.white);
		notesbutpanel.setBackground(Color.white);
		
		add.setOpaque(true);
		nimage.setOpaque(true);
		
		notesbutpanel.add(nimage,BorderLayout.WEST);
		notesbutpanel.add(add,BorderLayout.EAST);
		addpanel1.setPreferredSize(new Dimension(200,30));
		addpanel1.add(notesbutpanel,BorderLayout.WEST);
		
		centercenterpanel2areapanel2.add(addpanel1,BorderLayout.NORTH);
		centercenterpanel2areapanel2.add(noteDetailPanel, BorderLayout.CENTER);
		

		 //centercenterpanel2areapanel2.setBorder(BorderFactory.createTitledBorder("Additional Notes"));
		//centercenterpanel2areapanel2.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEmptyBorder(),"Additional Notes"));
		
		/*centercenterpanel2areapanel2.add(addpanel1,BorderLayout.NORTH);
		centercenterpanel2areapanel2.add(attachmentDetailsPanel,BorderLayout.CENTER);*/
		
		// addpanel1.setBorder(BorderFactory.createRaisedBevelBorder());
		//addpanel1.add(add, BorderLayout.SOUTH);
	   	
		
		centercenterpanel2areapanel1.setPreferredSize(new Dimension(
				width - 315, 150));
		centercenterpanel2areapanel2.setPreferredSize(new Dimension(
				width - 315, noteHeight+30));
		
		centercenterpanel2.add(centercenterpanel2areapanel1, BorderLayout.NORTH);
		centercenterpanel2.add(messageLabel, BorderLayout.CENTER);
		centercenterpanel2.add(centercenterpanel2areapanel2, BorderLayout.SOUTH);
		
		centercenterpanel2.setPreferredSize(new Dimension(width - 300, noteHeight + 220));
		
		//centercenterpanel2areapanel2.add(addpanel1, BorderLayout.EAST);

		centerwest.add(area, BorderLayout.CENTER);
		centersouth2.add(save1, BorderLayout.SOUTH);
		centercenter.add(area2, BorderLayout.CENTER);
		centersouth1.add(save2, BorderLayout.EAST);

		centersouth.add(centersouth2, BorderLayout.EAST);
		center.add(centerwest, BorderLayout.WEST);
		centerwest.add(centersouth, BorderLayout.SOUTH);
		centercenter.add(centersouth1, BorderLayout.SOUTH);
		center.add(centercenter, BorderLayout.CENTER);

		// center.setBorder(BorderFactory.createRaisedBevelBorder());
		// centerwest.setBorder(BorderFactory.createRaisedBevelBorder());
		// centercenter.setBorder(BorderFactory.createRaisedBevelBorder());
		// centersouth.setBorder(BorderFactory.createRaisedBevelBorder());

		centerwest.setBorder(BorderFactory.createTitledBorder("Van Stock"));
		centercenter.setBorder(BorderFactory
				.createTitledBorder("Merchant Item"));

		// centercenterpanel3panel1a.setBorder(BorderFactory.createRaisedBevelBorder());
		// centercenterpanel3panel1b.setBorder(BorderFactory.createRaisedBevelBorder());
		// centercenterpanel3panel1c.setBorder(BorderFactory.createRaisedBevelBorder());
		/*
		 * centercenterpanel3panel2a.add(new JScrollPane(area2));
		 * centercenterpanel3panel2a.add(save2);
		 * centercenterpanel3panel2a.add(new JScrollPane(area));
		 * centercenterpanel3panel2a.add(save1);
		 */
		centercenterpanel3panel2a.add(center);
		centercenterpanel3panel2.add(centercenterpanel3panel2a);
		// centercenterpanel3panel2.add(centercenterpanel3panel2b);

		//attachmentDetailsPanel.setBorder(BorderFactory.createTitledBorder(	BorderFactory.createEmptyBorder(), "Attached Images"));
		JPanel addpanel = UIHelper.getBoxPanel(new BorderLayout(), Color.white,
				Color.black);
		addpanel.setPreferredSize(new Dimension(150, 50));
		// addpanel.setBorder(BorderFactory.createRaisedBevelBorder());
		//add1 = new JButton(new ImageIcon(UIHelper.class.getResource("icon/blueaddbtn.png")));
		
		addpanel.add(add1, BorderLayout.SOUTH);

		switch (status) {
		case STATUS_HOME:
			centercenterpanel3panel2a.setBorder(BorderFactory
					.createTitledBorder(BorderFactory.createEmptyBorder(),
							"Parts Required"));
			break;
		case STATUS_ASSIGNED:
			centercenterpanel3panel2a.setBorder(BorderFactory
					.createTitledBorder(BorderFactory.createEmptyBorder(),
							"Parts Required"));
			break;
		case STATUS_COMPLETED:
			centercenterpanel3panel2a.setBorder(BorderFactory
					.createTitledBorder(BorderFactory.createEmptyBorder(),
							"Parts Used"));
			break;
		case STATUS_CLOSED:
			centercenterpanel3panel2a.setBorder(BorderFactory
					.createTitledBorder(BorderFactory.createEmptyBorder(),
							"Parts Used"));
			break;
		}
		
		attachmentDetailsPanel.setPreferredSize(new Dimension(width - 315, attachmentHeight + 30));

		centercenterpanel3.add(attachmentDetailsPanel, BorderLayout.NORTH);
		
		JPanel imagesavepanel=new JPanel(new BorderLayout());
		JPanel imagebutpanel=new JPanel(new BorderLayout());
		JLabel aimage=new JLabel("Attached Images : ");
		add1.setForeground(new Color(52,152,219));
		add1.setBackground(Color.white);
		aimage.setBackground(Color.white);
		imagesavepanel.setBackground(Color.white);
		
		add1.setOpaque(true);
		aimage.setOpaque(true);
		
		imagebutpanel.add(aimage,BorderLayout.WEST);
		imagebutpanel.add(add1,BorderLayout.EAST);
		imagesavepanel.setPreferredSize(new Dimension(200,30));
		imagesavepanel.add(imagebutpanel,BorderLayout.WEST);
		attachmentDetailsPanel.add(imagesavepanel, BorderLayout.NORTH);
		centercenterpanel3.add(centercenterpanel3panel2, BorderLayout.CENTER);

		centercenterpanel3.setOpaque(true);
		attachmentDetailsPanel.setBackground(Color.white);
		centercenterpanel3.setBackground(Color.white);

		Font f2f = new Font("sans", Font.BOLD, 18);
		label_repair.setFont(f2f);
		JPanel label_panel = new JPanel(new BorderLayout());
		JLabel property=new JLabel("Property Details : ");
		 
		
		Font f1 = new Font("sans", Font.BOLD, 12);
		property.setFont(f1);
		property.setForeground(new Color(52,152,219));
		
		Font f4 = new Font("sans", Font.BOLD, 12);
		save.setFont(f4);
		
		save.setBackground(Color.white);
		save.setForeground(new Color(52,152,219));
				
		centercenterpanel1a.add(label_name);
		centercenterpanel1a.add(label_name1);
		centercenterpanel1a.add(label_street);
		centercenterpanel1a.add(label_street1);
		centercenterpanel1a.add(label_town);
		centercenterpanel1a.add(label_town1);
		centercenterpanel1a.add(label_city);
		centercenterpanel1a.add(label_city1);
		centerinner.add(label_repair, BorderLayout.WEST);
		centerinner.setBackground(new Color(236, 233, 216));
		label_repair.setForeground(new Color(52, 152, 219));
		// centerinner.add(label_img,BorderLayout.EAST);
		centercenterpanel1a.add(centerinner);
		// centercenterpanel1a.add(label_time);
		// centercenterpanel1a.add(label_date);
		label_priority1.addItem("High");
		label_priority1.addItem("Medium");
		label_priority1.addItem("Low");
		centercenterpanel1b.add(property);
		centercenterpanel1b.add(proplabel);
		centercenterpanel1b.add(empproperty1);
		centercenterpanel1b.add(empproperty1);
		centercenterpanel1b.add(empproperty1);
		centercenterpanel1b.add(label_code);
		centercenterpanel1b.add(label_code1);
		centercenterpanel1b.add(label_status);
		centercenterpanel1b.add(label_status1);
		centercenterpanel1b.add(label1);
		centercenterpanel1b.add(label_priority);
		centercenterpanel1b.add(label_priority1);
		centercenterpanel1b.add(label_area);
		centercenterpanel1b.add(label_area1);
		centercenterpanel1b.add(label_date1);
		// centercenterpanel1b.add(label_date2);
		centercenterpanel1b.add(label_date3);
		// centercenterpanel1b.add(label_date4);
		
		JPanel datepanel=new JPanel(new BorderLayout());
			
		
		ampm.addItem("AM");
		ampm.addItem("PM");
		
		datepanel.add(datecub,BorderLayout.CENTER);
		datepanel.add(ampm,BorderLayout.EAST);
		
		
		
		centercenterpanel1b.add(datepanel);
		centercenterpanel1b.add(label2);
		centercenterpanel1b.add(save);
		
		
		if(stats == 2 || stats == 3)
		{
			centercenterpanel1b.add(empproperty2);
			centercenterpanel1b.add(empproperty3);
			centercenterpanel1b.add(comdate);
		}

		final StringBuilder b1 = new StringBuilder();
		final StringBuilder c1 = new StringBuilder();
		final StringBuilder tno = new StringBuilder();
		
		add1.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mousePressed(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseExited(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseEntered(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseClicked(MouseEvent arg0) 
			{
				new AttachImage(stat,jno.toString(), holderPanel);
				
			}
		
		});
		
		datecub.getDateEditor().addPropertyChangeListener(new PropertyChangeListener() {
			
			@Override
			public void propertyChange(PropertyChangeEvent changeEvent) {
				if (changeEvent.getPropertyName().equals("date"))
				{
					/*try {
						String url = base + "query/javahomeupdate.php";

						HttpClient client = new DefaultHttpClient();
						HttpPost post = new HttpPost(url);

						String[] names = label_name1.getText().split(" ");
						String a = names.length >= 0 ? names[0] : "";
						String b = names.length > 0 ? names[1] : "";

						SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

						List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(
								1);
						nameValuePairs.add(new BasicNameValuePair("fname", a));
						nameValuePairs.add(new BasicNameValuePair("lname", b));
						nameValuePairs.add(new BasicNameValuePair("street",
								label_street1.getText()));
						nameValuePairs.add(new BasicNameValuePair("town",
								label_town1.getText()));
						nameValuePairs.add(new BasicNameValuePair("city",
								label_city1.getText()));
						nameValuePairs.add(new BasicNameValuePair("cid", c1
								.toString()));
						nameValuePairs.add(new BasicNameValuePair("aname",
								((AreaEntity) label_area1.getSelectedItem())
										.getArea()));
						// nameValuePairs.add(new
						// BasicNameValuePair("aid",UIHelper.a1));
						nameValuePairs.add(new BasicNameValuePair("prior",
								label_priority1.getSelectedItem().toString()));
						
						nameValuePairs.add(new BasicNameValuePair("ampm",ampm.getSelectedItem().toString()));
						
						nameValuePairs.add(new BasicNameValuePair("adate", sdf
								.format(datecub.getDate())));
						System.out.println("Ticket ID : -------" + jno);
						nameValuePairs.add(new BasicNameValuePair("tid", jno ));
						nameValuePairs.add(new BasicNameValuePair("tcode",
								(String) label_code1.getSelectedItem()));

						post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
						HttpResponse response = client.execute(post);
						BufferedReader rd = new BufferedReader(
								new InputStreamReader(response.getEntity()
										.getContent()));

						String line = "";

						while ((line = rd.readLine()) != null) {
							System.out.println(line);

						}

					} catch (IOException e3) {
						e3.printStackTrace();
					}*/
				}
			}
		});
		
		add2.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mousePressed(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseExited(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseEntered(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseClicked(MouseEvent arg0) 
			{

				try {

					String url = base + "query/javainsertdetails.php";
					HttpClient client = new DefaultHttpClient();
					HttpPost post = new HttpPost(url);
					List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
					nameValuePairs.add(new BasicNameValuePair("txthid", jno.toString()));
					nameValuePairs.add(new BasicNameValuePair("edititemdiv",workDescriptionArea.getText()));
					post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
					HttpResponse response = client.execute(post);
					BufferedReader rd = new BufferedReader(
							new InputStreamReader(response.getEntity()
									.getContent()));

					String stringBuffer = "";
					String line = null;

					while ((line = rd.readLine()) != null) 
					{
						stringBuffer = line;
					}
					
					holderPanel.removeAll();
					holderPanel.add(new JScrollPane(UIHelper.getJobDetails(stat, jno, holderPanel)));
					holderPanel.updateUI();
					
				} catch (Exception e4) {
					e4.printStackTrace();
				}
				
			}
		});
			
		add.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mousePressed(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseExited(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseEntered(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseClicked(MouseEvent arg0) 
			{
				new Attachnotes(stat,jno.toString(), holderPanel);
				
			}
		});
			
			

		save1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {

					String url = base + "query/javainsertitems.php";
					HttpClient client = new DefaultHttpClient();
					HttpPost post = new HttpPost(url);
					List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(
							1);
					nameValuePairs.add(new BasicNameValuePair("txthid", jno.toString()));
					nameValuePairs.add(new BasicNameValuePair("edititemdiv",
							area.getText()));
					post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
					HttpResponse response = client.execute(post);
					BufferedReader rd = new BufferedReader(
							new InputStreamReader(response.getEntity()
									.getContent()));

					String stringBuffer = "";
					String line = null;

					while ((line = rd.readLine()) != null) {
						stringBuffer = line;
					}

					holderPanel.removeAll();
					holderPanel.add(new JScrollPane(UIHelper.getJobDetails(stat, jno, holderPanel)));
					holderPanel.updateUI();

				} catch (Exception e4) {
					e4.printStackTrace();
				}
			}

		});

		save2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {

					String url = base + "query/javainsertitems1.php";
					HttpClient client = new DefaultHttpClient();
					HttpPost post = new HttpPost(url);
					List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(
							1);
					nameValuePairs.add(new BasicNameValuePair("txthid", jno
							.toString()));
					nameValuePairs.add(new BasicNameValuePair("edititemdiv",
							area2.getText()));
					post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
					HttpResponse response = client.execute(post);
					BufferedReader rd = new BufferedReader(
							new InputStreamReader(response.getEntity()
									.getContent()));

					String stringBuffer = "";
					String line = null;

					while ((line = rd.readLine()) != null) {
						stringBuffer = line;
					}

					holderPanel.removeAll();
					holderPanel.add(new JScrollPane(UIHelper.getJobDetails(stat, jno, holderPanel)));
					holderPanel.updateUI();

				} catch (Exception e4) {
					e4.printStackTrace();
				}
			}

		});

		save.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					String url = base + "query/javahomeupdate.php";

					HttpClient client = new DefaultHttpClient();
					HttpPost post = new HttpPost(url);

					String[] names = label_name1.getText().split(" ");
					String a = names.length >= 0 ? names[0] : "";
					String b = names.length > 0 ? names[1] : "";

					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

					List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(
							1);
					nameValuePairs.add(new BasicNameValuePair("fname", a));
					nameValuePairs.add(new BasicNameValuePair("lname", b));
					nameValuePairs.add(new BasicNameValuePair("street",
							label_street1.getText()));
					nameValuePairs.add(new BasicNameValuePair("town",
							label_town1.getText()));
					nameValuePairs.add(new BasicNameValuePair("city",
							label_city1.getText()));
					nameValuePairs.add(new BasicNameValuePair("cid", c1
							.toString()));
					nameValuePairs.add(new BasicNameValuePair("aname",
							((AreaEntity) label_area1.getSelectedItem())
									.getArea()));
					// nameValuePairs.add(new
					// BasicNameValuePair("aid",UIHelper.a1));
					nameValuePairs.add(new BasicNameValuePair("prior",
							label_priority1.getSelectedItem().toString()));
					
					nameValuePairs.add(new BasicNameValuePair("ampm",ampm.getSelectedItem().toString()));
					
					nameValuePairs.add(new BasicNameValuePair("adate", sdf
							.format(datecub.getDate())));
					System.out.println("Ticket ID : -------" + jno);
					nameValuePairs.add(new BasicNameValuePair("tid", jno ));
					nameValuePairs.add(new BasicNameValuePair("tcode",
							(String) label_code1.getSelectedItem()));

					post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
					HttpResponse response = client.execute(post);
					BufferedReader rd = new BufferedReader(
							new InputStreamReader(response.getEntity()
									.getContent()));

					String line = "";

					while ((line = rd.readLine()) != null) {
						System.out.println(line);

					}

				} catch (IOException e3) {
					e3.printStackTrace();
				}
			}
		});
		centercenterpanel1c.add(label_centttime);
		centercenterpanel1c.add(label_centdate);
		centercenterpanel1c.add(label_centraised);
		centercenterpanel1c.add(label_centraised1);
		centercenterpanel1c.add(label_reportedby);
		centercenterpanel1c.add(label_reportedby1);
		centercenterpanel1c.add(label_centworkorder);
		centercenterpanel1c.add(label_centworkorder1);

		centercenterpanel1a.setPreferredSize(new Dimension(300, 150));
		centercenterpanel1b.setPreferredSize(new Dimension(width - 600, 150));
		centercenterpanel1c.setPreferredSize(new Dimension(width - 600, 25));

		centercenterpanel1c.setBorder(BorderFactory.createRaisedBevelBorder());

		centercenterpanel1b.setBorder(BorderFactory.createEmptyBorder(5, 5, 5,
				5));
		
		centercenterpanel1.add(centercenterpanel1a, BorderLayout.WEST);
		centercenterpanel1.add(centercenterpanel1b, BorderLayout.CENTER);
		centercenterpanel1.add(centercenterpanel1c, BorderLayout.SOUTH);
		
		jobDetailPanel.setLayout(new BoxLayout(jobDetailPanel, BoxLayout.PAGE_AXIS));

		jobDetailPanel.add(centercenterpanel1/*, BorderLayout.NORTH*/);
		jobDetailPanel.add(centercenterpanel2/*, BorderLayout.CENTER*/);
		jobDetailPanel.add(centercenterpanel3/*, BorderLayout.SOUTH*/);

		jobDetailPanel.setBorder(BorderFactory.createRaisedBevelBorder());
		/*jobDetailPanel
				.setPreferredSize(new Dimension(width - 300, height - 120));*/

		/**
		 * Population
		 */

		try {
			String url = "";

			switch (status) {
			case STATUS_HOME:
				url = base + "query/javasmainpage.php?id=" + jobNo;
				break;
			case STATUS_ASSIGNED:
				url = base + "query/javasassigned.php?id=" + jobNo;
				break;
			case STATUS_COMPLETED:
				url = base + "query/javascompleted.php?id=" + jobNo;
				break;
			case STATUS_CLOSED:
				url = base + "query/javasclosed.php?id=" + jobNo;
				break;
			}
			System.out.println(url);

			HttpClient client = new DefaultHttpClient();
			HttpGet request = new HttpGet(url);
			HttpResponse response = client.execute(request);
			BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));

			StringBuffer stringBuffer = new StringBuffer();
			String line = null;

			while ((line = rd.readLine()) != null) {
				stringBuffer.append(line);
			}

			String[] jobs = stringBuffer.toString().split("--");

			if (jobs.length > 0) {
				String[] jobDetail = jobs[0].split("\\|");

				label_name1.setText(jobDetail[3]);
				label_street1.setText(jobDetail[4]);
				label_town1.setText(jobDetail[5]);
				label_city1.setText(jobDetail[6]);
				proplabel.setText(jobDetail[8]);
				label_code1.setSelectedItem(jobDetail[9]);
				label_status1.setText(jobDetail[10]);
				label_priority1.setSelectedItem(jobDetail[11]);
				label_area1.setSelectedItem(new AreaEntity("0", jobDetail[12]));
				label_repair.setText(jobDetail[13]);
				label_date4.setText(jobDetail[14]);
				label_centraised1.setText(jobDetail[15]);
				label_reportedby1.setText(jobDetail[16]);
				label_centworkorder1.setText(jobDetail[17]);
				workDescriptionArea.setText(jobDetail[18]);
				label_centdate.setText(jobDetail[19]);
				area.setText(jobDetail[22]);
				area2.setText(jobDetail[23]);
				messageLabel.setText(jobDetail[24]);
				ampm.setSelectedItem(jobDetail[25]);

				boolean boole;
				if(jobDetail[21].equals("false"))
				{
				boole=false;
				}
				else
				{
					boole=true;
				}
				
				comdate.setText(jobDetail[26]);
				
				label_img = new MultipleVisitButton(Integer.parseInt(jobNo), boole);

				centerinner.add(label_img, BorderLayout.EAST);

				b1.setLength(0);
				c1.setLength(0);
				tno.setLength(0);

				b1.append(jobDetail[0]);
				c1.append(jobDetail[2]);
				tno.append(jobDetail[1]);

				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

				String s21 = label_date4.getText();
				if (s21 == null || s21.isEmpty())
				{
					datecub.setDate(new Date());
				}
				else
				{
					Date dd1 = null;
					dd1 = sdf.parse(s21);
					datecub.setDate(dd1);	
				}
				
			}
		} catch (Exception exception) {
			exception.printStackTrace();
		}

		/*jobDetailPanel.setSize(800, 1200);
		jobDetailPanel.setPreferredSize(new Dimension(800, 1000));
		jobDetailPanel.setMaximumSize(new Dimension(800, 1000));
		jobDetailPanel.setMinimumSize(new Dimension(800, 1000));*/

		return jobDetailPanel;
	}

	public static JPanel getSummaryPanel() {
		final JPanel summaryPanel = UIHelper.getBoxPanel(new BorderLayout(),
				null, null);

		// Home
		JLabel label1 = new JLabel("Open");
		final JLabel totalOpen = new JLabel();
		JLabel label2 = new JLabel("Assigned");
		final JLabel totalAssigned = new JLabel();

		JPanel northpanel2 = UIHelper.getBoxPanel(new GridLayout(1, 2),
				new Color(52, 152, 219), Color.white);
		JPanel northpanel2labelpanel1 = UIHelper.getBoxPanel(new GridLayout(2,
				1), null, null);
		JPanel northpanel2labelpanel2 = UIHelper.getBoxPanel(new GridLayout(2,
				1), null, null);

		JPanel northpanel2labelpanel1a = UIHelper.getBoxPanel(null, new Color(
				52, 152, 219), Color.white);
		JPanel northpanel2labelpanel1b = UIHelper.getBoxPanel(null, new Color(
				52, 152, 219), Color.white);
		JPanel northpanel2labelpanel2a = UIHelper.getBoxPanel(null, new Color(
				52, 152, 219), Color.white);
		JPanel northpanel2labelpanel2b = UIHelper.getBoxPanel(null, new Color(
				52, 152, 219), Color.white);

		JPanel northpanel3 = UIHelper.getBoxPanel(new BorderLayout(),
				new Color(52, 152, 219), Color.white);

		Object[] columnNames3 = new Object[] { "", "" };
		Object[][] columnData3 = new Object[][] { { "Total Tickets Today" },
				{ "Total Tickets This Week" },
				{ "Total Tickets Closed Today" },
				{ "Total Tickets Closed This week" } };
		DefaultTableModel model3 = new DefaultTableModel(columnData3,
				columnNames3);
		final JTable summaryTable = new JTable(model3);

		northpanel3.add(summaryTable);

		Font f1 = new Font("sans", Font.BOLD, 18);
		label1.setFont(f1);
		label1.setForeground(Color.white);

		Font f2 = new Font("sans", Font.BOLD, 18);
		label2.setFont(f2);
		label2.setForeground(Color.white);

		Font f1a = new Font("sans", Font.BOLD, 30);
		totalOpen.setFont(f1a);
		totalOpen.setForeground(Color.white);

		Font f2a = new Font("sans", Font.BOLD, 30);
		totalAssigned.setFont(f2a);
		totalAssigned.setForeground(Color.white);

		Font f3 = new Font("sans", Font.BOLD, 12);
		summaryTable.setFont(f2);
		summaryTable.setForeground(Color.white);

		northpanel2labelpanel1a.add(label1);
		northpanel2labelpanel1b.add(totalOpen);
		northpanel2labelpanel2a.add(label2);
		northpanel2labelpanel2b.add(totalAssigned);

		northpanel2labelpanel1.add(northpanel2labelpanel1a);
		northpanel2labelpanel1.add(northpanel2labelpanel1b);
		northpanel2labelpanel2.add(northpanel2labelpanel2a);
		northpanel2labelpanel2.add(northpanel2labelpanel2b);

		northpanel2.add(northpanel2labelpanel1);
		northpanel2.add(northpanel2labelpanel2);

		// northpanel3.setBorder(BorderFactory.createRaisedBevelBorder());

		northpanel2.setPreferredSize(new Dimension(500, 800));
		northpanel3.setPreferredSize(new Dimension(500, 150));

		summaryTable.setBackground(new Color(52, 152, 219));
		summaryTable.setForeground(Color.white);
		summaryPanel.add(northpanel2, BorderLayout.CENTER);
		summaryPanel.add(northpanel3, BorderLayout.EAST);
		summaryPanel.setOpaque(true);
		new Thread(new Runnable() {
			public void run() {
				while (true) {
					try {
						String url = base + "query/javagetotalticket.php";

						HttpClient client = new DefaultHttpClient();
						HttpGet request = new HttpGet(url);
						HttpResponse response = client.execute(request);
						BufferedReader rd = new BufferedReader(
								new InputStreamReader(response.getEntity()
										.getContent()));

						StringBuffer stringBuffer = new StringBuffer();
						String line = null;

						while ((line = rd.readLine()) != null) {
							stringBuffer.append(line);
						}

						totalOpen.setText(stringBuffer.toString());
						url = base + "query/javagetassignticket.php";

						client = new DefaultHttpClient();
						request = new HttpGet(url);
						response = client.execute(request);
						rd = new BufferedReader(new InputStreamReader(response
								.getEntity().getContent()));

						stringBuffer = new StringBuffer();
						line = null;

						while ((line = rd.readLine()) != null) {
							stringBuffer.append(line);
						}

						totalAssigned.setText(stringBuffer.toString());

						url = base + "query/javagettdayticket.php";

						client = new DefaultHttpClient();
						request = new HttpGet(url);
						response = client.execute(request);
						rd = new BufferedReader(new InputStreamReader(response
								.getEntity().getContent()));

						stringBuffer = new StringBuffer();
						line = null;

						while ((line = rd.readLine()) != null) {
							stringBuffer.append(line);
						}

						summaryTable.setValueAt(stringBuffer.toString(), 0, 1);

						url = base + "query/javagetweekticket.php";

						client = new DefaultHttpClient();
						request = new HttpGet(url);
						response = client.execute(request);
						rd = new BufferedReader(new InputStreamReader(response
								.getEntity().getContent()));

						stringBuffer = new StringBuffer();
						line = null;

						while ((line = rd.readLine()) != null) {
							stringBuffer.append(line);
						}

						summaryTable.setValueAt(stringBuffer.toString(), 1, 1);

						url = base + "query/javagettdaycloseticket.php";

						client = new DefaultHttpClient();
						request = new HttpGet(url);
						response = client.execute(request);
						rd = new BufferedReader(new InputStreamReader(response
								.getEntity().getContent()));

						stringBuffer = new StringBuffer();
						line = null;

						while ((line = rd.readLine()) != null) {
							stringBuffer.append(line);
						}

						summaryTable.setValueAt(stringBuffer.toString(), 2, 1);

						url = base + "query/javagetweekcloseticket.php";

						client = new DefaultHttpClient();
						request = new HttpGet(url);
						response = client.execute(request);
						rd = new BufferedReader(new InputStreamReader(response
								.getEntity().getContent()));

						stringBuffer = new StringBuffer();
						line = null;

						while ((line = rd.readLine()) != null) {
							stringBuffer.append(line);
						}

						summaryTable.setValueAt(stringBuffer.toString(), 3, 1);
					} catch (Exception exception) {
						exception.printStackTrace();
					}

					summaryTable.updateUI();
					summaryPanel.updateUI();

					try {
						Thread.sleep(15000);
					} catch (Exception exception) {
						exception.printStackTrace();
					}
				}
			}
		}).start();

		return summaryPanel;
	}

	private static JTable getBoxPanel(Color color, Color white) {
		// TODO Auto-generated method stub
		return null;
	}

	public static JList getEngineers() {
		JList engineerCombo = null;
		DefaultListModel dl = new DefaultListModel();

		try {
			String url = base + "query/javaengine.php";

			HttpClient client = new DefaultHttpClient();
			HttpGet request = new HttpGet(url);
			HttpResponse response = client.execute(request);
			BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));

			StringBuffer stringBuffer = new StringBuffer();
			String line = null;

			while ((line = rd.readLine()) != null) {
				stringBuffer.append(line);
			}

			System.out.println(stringBuffer);

			String[] engineers = stringBuffer.toString().split("--");

			for (String engineer : engineers) {
				String[] engDetails = engineer.split("\\|");
				if (engDetails != null && engDetails.length > 1)
					dl.addElement(new EngineerEntity(engDetails[0],
							engDetails[1], engDetails[2], engDetails[3]));

			}
			engineerCombo = new JList(dl);

			engineerCombo.setCellRenderer(new ListCellRenderer() {
				public Component getListCellRendererComponent(JList list,
						Object value, int index, boolean isSelected,
						boolean cellHasFocus) {
					EngineerEntity engineerEntity = (EngineerEntity) value;

					ImageIcon image = null;

					try {
						if (engineerEntity.getEngineerlogin().equals("N")) {
							image = new ImageIcon(UIHelper.class
									.getResource("icon/grey.png"));
						} else if (Integer.parseInt(engineerEntity
								.getEngineerlastlogin()) > 1) {
							image = new ImageIcon(UIHelper.class
									.getResource("icon/orange.png"));
						} else {
							image = new ImageIcon(UIHelper.class
									.getResource("icon/green.png"));
						}
					} catch (Exception exception) {
						exception.printStackTrace();
						image = new ImageIcon(UIHelper.class
								.getResource("icon/grey.png"));
					}

					JLabel jLabel = new JLabel(value.toString());
					jLabel.setHorizontalTextPosition(SwingConstants.TRAILING);
					jLabel.setAlignmentX(SwingConstants.LEFT);
					jLabel.setIcon(image);

					if (isSelected) {
						Font f1 = new Font("sans", Font.BOLD, 12);
						jLabel.setBackground(new Color(52, 152, 219));
						jLabel.setForeground(new Color(52, 152, 219));
						jLabel.setFont(f1);

					} else {
						jLabel.setBackground(Color.white);
						jLabel.setForeground(Color.black);
					}

					return jLabel;
				}
			});
		} catch (Exception exception) {
			exception.printStackTrace();
		}

		engineerCombo.setSelectedIndex(-1);

		return engineerCombo;
	}

	public static JComboBox getEngineers1() {
		JComboBox engineerCombo = new JComboBox();

		try {
			String url = base + "query/javaengine.php";

			HttpClient client = new DefaultHttpClient();
			HttpGet request = new HttpGet(url);
			HttpResponse response = client.execute(request);
			BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));

			StringBuffer stringBuffer = new StringBuffer();
			String line = null;

			while ((line = rd.readLine()) != null) {
				stringBuffer.append(line);
			}

			System.out.println(stringBuffer);

			String[] engineers = stringBuffer.toString().split("--");

			for (String engineer : engineers) {
				String[] engDetails = engineer.split("\\|");
				if (engDetails != null && engDetails.length > 1)
					engineerCombo.addItem(new EngineerEntity(engDetails[0],
							engDetails[1], engDetails[2], engDetails[3]));

			}
		} catch (Exception exception) {
			exception.printStackTrace();
		}

		engineerCombo.setSelectedIndex(0);

		return engineerCombo;
	}

	public static void assignJob(String jobId, String engineerId) {
		try {
			String url = base + "query/javaassign.php?jid=" + jobId + "&eid="
					+ engineerId;

			HttpClient client = new DefaultHttpClient();
			HttpGet request = new HttpGet(url);
			HttpResponse response = client.execute(request);
			BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));

			StringBuffer stringBuffer = new StringBuffer();
			String line = null;

			while ((line = rd.readLine()) != null) {
				stringBuffer.append(line);
				System.out.println(line);
			}
		} catch (Exception exception) {
			exception.printStackTrace();
		}
	}

	public static void assignJob1(String jobId, String engineerId) {
		try {
			String url = base + "query/javaassign1.php?jid=" + jobId + "&eid="
					+ engineerId;

			HttpClient client = new DefaultHttpClient();
			HttpGet request = new HttpGet(url);
			HttpResponse response = client.execute(request);
			BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));

			StringBuffer stringBuffer = new StringBuffer();
			String line = null;

			while ((line = rd.readLine()) != null) {
				stringBuffer.append(line);
				System.out.println(line);
			}
		} catch (Exception exception) {
			exception.printStackTrace();
		}
	}

	public static void completeJob(String jobId) {
		try {
			String url = base + "query/javacompletejob.php?jid=" + jobId;

			HttpClient client = new DefaultHttpClient();
			HttpGet request = new HttpGet(url);
			HttpResponse response = client.execute(request);
			BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));

			StringBuffer stringBuffer = new StringBuffer();
			String line = null;

			while ((line = rd.readLine()) != null) {
				stringBuffer.append(line);
			}
		} catch (Exception exception) {
			exception.printStackTrace();
		}
	}

	public static void closeJob(String jobId) {
		try {
			String url = base + "query/javaclosejob.php?jid=" + jobId;

			HttpClient client = new DefaultHttpClient();
			HttpGet request = new HttpGet(url);
			HttpResponse response = client.execute(request);
			BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));

			StringBuffer stringBuffer = new StringBuffer();
			String line = null;

			while ((line = rd.readLine()) != null) {
				stringBuffer.append(line);
			}
		} catch (Exception exception) {
			exception.printStackTrace();
		}
	}

	public static void reopenJob(String jobId) {
		try {
			String url = base + "query/javareopenjob.php?jid=" + jobId;

			HttpClient client = new DefaultHttpClient();
			HttpGet request = new HttpGet(url);
			HttpResponse response = client.execute(request);
			BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));

			StringBuffer stringBuffer = new StringBuffer();
			String line = null;

			while ((line = rd.readLine()) != null) {
				System.out.println(line);
				stringBuffer.append(line);
			}
		} catch (Exception exception) {
			exception.printStackTrace();
		}
	}

	private static JPanel getNotePanels(String jobId) {
		JPanel noteDetailPanel = UIHelper.getBoxPanel(new FlowLayout(FlowLayout.LEFT, 25, 5),
				null, null);
		final JPanel holderPanel = UIHelper.getBoxPanel(new FlowLayout(FlowLayout.LEFT, 75, 5),
				null, null);
		noteHeight = 0;
		
		try {
			String url = base + "query/javasmainpagenotes.php?id=" + jobId;

			HttpClient client = new DefaultHttpClient();
			HttpGet request = new HttpGet(url);
			HttpResponse response = client.execute(request);
			BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));

			StringBuffer stringBuffer = new StringBuffer();
			String line = null;

			while ((line = rd.readLine()) != null) {
				stringBuffer.append(line);
			}

			String[] notes = stringBuffer.toString().split("--");
			
			int count = 0;
			
			for (String noteDetails : notes) {
				NotePanel notePanel = new NotePanel(noteDetails);
				noteDetailPanel.add(notePanel);
				
				if (count % 3 == 0)
					noteHeight = noteHeight + 130;
				
				count++;
			}

			//noteDetailPanel.add(new JScrollPane(holderPanel));
			//noteDetailPanel.add(holderPanel);
		} catch (Exception exception) {
			exception.printStackTrace();
		}
		
		//noteDetailPanel.setPreferredSize(new Dimension(800, hght));

		return noteDetailPanel;
	}

	private static JPanel getAttachmentsPanels(String jobId) {
		JPanel attachmentDetailPanel = UIHelper.getBoxPanel(new BorderLayout(),
				null, null);
		final JPanel holderPanel = UIHelper.getBoxPanel(new FlowLayout(FlowLayout.LEFT, 75, 5),
				null, null);

		try {
			String url = base + "query/javasmainpageattachments.php?id="
					+ jobId;

			HttpClient client = new DefaultHttpClient();
			HttpGet request = new HttpGet(url);
			HttpResponse response = client.execute(request);
			BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));

			StringBuffer stringBuffer = new StringBuffer();
			String line = null;

			while ((line = rd.readLine()) != null) {
				stringBuffer.append(line);
			}
			
			attachmentHeight = 0;
			
			int count = 0;

			String[] attachments = stringBuffer.toString().split("--");

			for (String attachmentDetails : attachments) {
				AttachmentPanel attachmentPanel = new AttachmentPanel(
						attachmentDetails, base);
				holderPanel.add(attachmentPanel);
				
				if (count%3 == 0)
					attachmentHeight = attachmentHeight + 50;
				
				count++;
			}

			//attachmentDetailPanel.add(new JScrollPane(holderPanel));
			attachmentDetailPanel.add(holderPanel, BorderLayout.CENTER);
		} catch (Exception exception) {
			exception.printStackTrace();
		}

		return attachmentDetailPanel;
	}

	/**
	 * @return the base
	 */
	public static String getBase() {
		return base;
	}
	
	public static String getUser() {
		return user;
	}

	public static void setUser(String user) {
		UIHelper.user = user;
	}
	
	
	public static String getLoguid() {
		return loguid;
	}

	public static void setLoguid(String loguid) {
		UIHelper.loguid = loguid;
	}

	public static JPanel getBoxPanel(LayoutManager layoutManager,
			Color backgroundColor, Color foregroundColor) {

		JPanel panel = null;

		if (layoutManager == null)
			panel = new JPanel();
		else
			panel = new JPanel(layoutManager);

		panel.setOpaque(true);

		if (foregroundColor == null)
			panel.setForeground(Color.BLACK);
		else
			panel.setForeground(foregroundColor);

		if (backgroundColor == null)
			panel.setBackground(Color.WHITE);
		else
			panel.setBackground(backgroundColor);

		return panel;
	}

	public static JComboBox arealoaddata() {

		JComboBox comboarea = new JComboBox();

		try {
			String url = UIHelper.getBase() + "query/javaarea.php";

			HttpClient client = new DefaultHttpClient();
			HttpGet request = new HttpGet(url);
			HttpResponse response = client.execute(request);
			BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));

			StringBuffer stringBuffer = new StringBuffer();
			String line = null;

			while ((line = rd.readLine()) != null) {
				stringBuffer.append(line);
			}

			String[] areas = stringBuffer.toString().split("--");

			for (String area : areas) {
				String[] areadetail = area.split("\\|");
				if (areadetail != null && areadetail.length > 1)
					comboarea.addItem(new AreaEntity(areadetail[0],
							areadetail[1]));
			}
		} catch (Exception exception) {
			exception.printStackTrace();
		}

		comboarea.setSelectedIndex(0);

		return comboarea;

	}

	public static final int STATUS_HOME = 0;
	public static final int STATUS_ASSIGNED = 1;
	public static final int STATUS_COMPLETED = 2;
	public static final int STATUS_CLOSED = 3;
}
