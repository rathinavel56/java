package com.alethiclogic.helpdesk.ui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import com.alethiclogic.customerentity;

public class FindCustomerDialog extends JDialog  implements ActionListener,MouseListener{

	private JPanel mainpanel = new JPanel(new BorderLayout());
	private JPanel northpanel = new JPanel();
	private JPanel centerpanel = new JPanel(new BorderLayout());

	private JLabel labfname = new JLabel("FirstName");
	private JLabel lablname = new JLabel("LastName");
	private JLabel labstreet = new JLabel("Street");
	private JLabel labpost = new JLabel("Post code");
	private JLabel empty = new JLabel();
	private int custid=0;

	private JTextField txtfname = new JTextField();
	private JTextField txtlname = new JTextField();
	private JTextField txtstreet = new JTextField();
	private JTextField txtpost = new JTextField();

	private JButton butsearch = new JButton("Search");
	private String burl=UIHelper.getBase();
	
	
	private Vector<customerentity>custvector = new Vector<customerentity>();
	
	private AddTicketPanel addTicketPanel;
	
	
	private JTable customertable;
	private DefaultTableModel customermodel;
	Object[] columnNames = new Object[] { "Id", "Name", "Property Details", "House/Flat", "Street",
			"Town", "City", "Landline" , "Mobile", "country" ,"Postcode", "" };
	

	public FindCustomerDialog(String a,String b,String c,String d, AddTicketPanel addTicketPanel)
	{
		
		this.addTicketPanel = addTicketPanel;
		
		loaddata(a,b,c,d);
		

		northpanel.setLayout(new BoxLayout(northpanel, BoxLayout.PAGE_AXIS));

		Component box_1 = Box.createRigidArea(new Dimension(200, 10));
		Box box_2 = Box.createHorizontalBox();
		Component box_3 = Box.createRigidArea(new Dimension(200, 10));
		Box box_4 = Box.createHorizontalBox();
		Component box_5 = Box.createRigidArea(new Dimension(200, 10));
		Box box_6 = Box.createHorizontalBox();
		Component box_7 = Box.createRigidArea(new Dimension(200, 10));
		Box box_8 = Box.createHorizontalBox();
		Component box_9 = Box.createRigidArea(new Dimension(200, 10));
		Box box_10 = Box.createHorizontalBox();

		box_2.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox2 = new JPanel(new BorderLayout());
		labfname.setPreferredSize(new Dimension(150, 25));
		labfname.setMaximumSize(new Dimension(150, 25));
		txtfname.setPreferredSize(new Dimension(300, 25));
		txtfname.setMaximumSize(new Dimension(300, 25));
		pbox2.setMaximumSize(new Dimension(440, 25));
		pbox2.add(labfname, BorderLayout.WEST);
		pbox2.add(txtfname, BorderLayout.CENTER);
		box_2.add(pbox2);
		box_2.add(Box.createRigidArea(new Dimension(0, 10)));

		box_4.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox4 = new JPanel(new BorderLayout());
		lablname.setPreferredSize(new Dimension(150, 25));
		lablname.setMaximumSize(new Dimension(150, 25));
		txtlname.setPreferredSize(new Dimension(300, 25));
		txtlname.setMaximumSize(new Dimension(300, 25));
		pbox4.setMaximumSize(new Dimension(440, 25));
		pbox4.add(lablname, BorderLayout.WEST);
		pbox4.add(txtlname, BorderLayout.CENTER);
		box_4.add(pbox4);
		box_4.add(Box.createRigidArea(new Dimension(0, 10)));

		box_6.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox6 = new JPanel(new BorderLayout());
		labstreet.setPreferredSize(new Dimension(150, 25));
		labstreet.setMaximumSize(new Dimension(150, 25));
		txtstreet.setPreferredSize(new Dimension(300, 25));
		txtstreet.setMaximumSize(new Dimension(300, 25));
		pbox6.setMaximumSize(new Dimension(440, 25));
		pbox6.add(labstreet, BorderLayout.WEST);
		pbox6.add(txtstreet, BorderLayout.CENTER);
		box_6.add(pbox6);
		box_6.add(Box.createRigidArea(new Dimension(0, 10)));

		box_8.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox8 = new JPanel(new BorderLayout());
		labpost.setPreferredSize(new Dimension(150, 25));
		labpost.setMaximumSize(new Dimension(150, 25));
		txtpost.setPreferredSize(new Dimension(300, 25));
		txtpost.setMaximumSize(new Dimension(300, 25));
		pbox8.setMaximumSize(new Dimension(440, 25));
		pbox8.add(labpost, BorderLayout.WEST);
		pbox8.add(txtpost, BorderLayout.CENTER);
		box_8.add(pbox8);
		box_8.add(Box.createRigidArea(new Dimension(0, 10)));

		box_10.add(Box.createRigidArea(new Dimension(20, 0)));
		JPanel pbox10 = new JPanel(new BorderLayout());

		JLabel label = new JLabel();
		empty.setPreferredSize(new Dimension(150, 25));
		empty.setMaximumSize(new Dimension(150, 25));
		label.setPreferredSize(new Dimension(50, 25));
		label.setMaximumSize(new Dimension(50, 25));
		butsearch.setPreferredSize(new Dimension(150, 25));
		butsearch.setMaximumSize(new Dimension(150, 25));

		butsearch.addActionListener(this);
		
		
		pbox10.setMaximumSize(new Dimension(440, 25));

		pbox10.add(empty, BorderLayout.WEST);
		pbox10.add(label, BorderLayout.CENTER);
		pbox10.add(butsearch, BorderLayout.EAST);

		box_10.add(pbox10);
		box_10.add(Box.createRigidArea(new Dimension(0, 10)));

		northpanel.add(box_1);
		northpanel.add(box_2);
		northpanel.add(box_3);
		northpanel.add(box_4);
		northpanel.add(box_5);
		northpanel.add(box_6);
		northpanel.add(box_7);
		northpanel.add(box_8);
		northpanel.add(box_9);
		northpanel.add(box_10);

		JPanel tabelpanel = new JPanel(new GridLayout());


		tabelpanel.setBorder(BorderFactory.createRaisedBevelBorder());
		tabelpanel.add(new JScrollPane(customertable));

		centerpanel.add(tabelpanel, BorderLayout.CENTER);

		northpanel.setBorder(BorderFactory.createRaisedBevelBorder());
		centerpanel.setBorder(BorderFactory.createRaisedBevelBorder());

		mainpanel.setPreferredSize(new Dimension(500, 400));
		northpanel.setPreferredSize(new Dimension(500, 180));
		centerpanel.setPreferredSize(new Dimension(500, 200));

		mainpanel.add(northpanel, BorderLayout.NORTH);
		mainpanel.add(centerpanel, BorderLayout.CENTER);
	
		customertable.addMouseListener(this);

		this.add(mainpanel);
		this.setSize(500, 400);
		this.setVisible(true);

	}
	public void loaddata(String a,String b,String c,String d)
	{
		try
		{
			
			
			custvector.clear();
			
			
			String url = burl + "query/javacustpopup.php";
			
			HttpClient client = new DefaultHttpClient();
			HttpPost post = new HttpPost(url);
			
			
		//	String[] names = label_.getText().split(" ");
			//String a=names.length >= 0 ? names[0] : "";
			//String b=names.length > 0 ? names[1] : "";
			
			
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
			
			nameValuePairs.add(new BasicNameValuePair("street",a));
			nameValuePairs.add(new BasicNameValuePair("postcode",b));
			nameValuePairs.add(new BasicNameValuePair("firstname",c));
			nameValuePairs.add(new BasicNameValuePair("lastname",d));
			
		
			post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			HttpResponse response = client.execute(post);
			BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));

			StringBuffer buffer1 = new StringBuffer();

			String line = "";
			String ss = "";
			while ((line = rd.readLine()) != null) {
				buffer1.append(line);
				ss = ss + line;
			}

			if (!ss.isEmpty()) {

				String[] namevaluePairs = buffer1.toString().split("\\-\\-");

				for (String namevaluePair : namevaluePairs) {
					if (namevaluePair.contains("|")) {
						String[] pairArray = namevaluePair.split("\\|");
						
						customerentity ce = new customerentity();
					
						ce.setId(pairArray[0]);
						ce.setFname(pairArray[1]);
						ce.setLname(pairArray[2]);
						ce.setDeiails(pairArray[3]);
						ce.setHouseflat(pairArray[4]);
						ce.setStreet(pairArray[5]);
						ce.setTown(pairArray[6]);
						ce.setCity(pairArray[7]);
						ce.setLandline(pairArray[8]);
						ce.setMobile(pairArray[9]);
						ce.setCountrty(pairArray[10]);
						ce.setPostcode(pairArray[11]);
						custvector.add(ce);
				
					}
				}
			}

		} catch (IOException e3) {
			e3.printStackTrace();
		}

		int address = custvector.size();

		Object[][] columnData = new Object[address][13];

		for (int i = 0; i < address; i++) {
			columnData[i] = custvector.get(i).getcustomerdetails();
		}

		if (customermodel == null) {
			customermodel = new DefaultTableModel(columnData, columnNames) {
				@Override
				public boolean isCellEditable(int row, int col1) {
					if (col1 < 12)
						return false;
					return true;
				}

				@Override
				public Class getColumnClass(int c) {
					try {
						return getValueAt(0, c).getClass();
					} catch (Exception exception) {
						return String.class;
					}
				}
			};
		} else {
			customermodel.setDataVector(columnData, columnNames);
		}
		if (customertable == null)
			customertable = new JTable(customermodel);

		customertable.updateUI();
		
 }
	
	public void searchload()
	{
		try
		{
			
			custvector.clear();
			
			String url = burl + "query/javacustpopup.php";
			
			HttpClient client = new DefaultHttpClient();
			HttpPost post = new HttpPost(url);
			
		//	String[] names = label_.getText().split(" ");
			//String a=names.length >= 0 ? names[0] : "";
			//String b=names.length > 0 ? names[1] : "";
			
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
			
			nameValuePairs.add(new BasicNameValuePair("street",txtstreet.getText()));
			nameValuePairs.add(new BasicNameValuePair("postcode",txtpost.getText()));
			nameValuePairs.add(new BasicNameValuePair("firstname",txtfname.getText()));
			nameValuePairs.add(new BasicNameValuePair("lastname",txtlname.getText()));
			
			post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			HttpResponse response = client.execute(post);
			BufferedReader rd = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));
			
			
			StringBuffer buffer1 = new StringBuffer();

			String line = "";
			String ss = "";
			while ((line = rd.readLine()) != null) {
				buffer1.append(line);
				ss = ss + line;
				
			}

			if (!ss.isEmpty()) {

				String[] namevaluePairs = buffer1.toString().split("\\-\\-");

				for (String namevaluePair : namevaluePairs) {
					if (namevaluePair.contains("|")) {
						String[] pairArray = namevaluePair.split("\\|");
						
						customerentity ce = new customerentity();
					

						ce.setId(pairArray[0]);
						ce.setFname(pairArray[1]);
						ce.setLname(pairArray[2]);
						ce.setDeiails(pairArray[3]);
						ce.setHouseflat(pairArray[4]);
						ce.setStreet(pairArray[5]);
						ce.setTown(pairArray[6]);
						ce.setCity(pairArray[7]);
						ce.setLandline(pairArray[8]);
						ce.setMobile(pairArray[9]);
						ce.setCountrty(pairArray[10]);
						ce.setPostcode(pairArray[11]);
				
						custvector.add(ce);
				
					}
				}
			}

		} catch (IOException e3) {
			e3.printStackTrace();
		}

		int address = custvector.size();

		Object[][] columnData = new Object[address][13];

		for (int i = 0; i < address; i++) {
			columnData[i] = custvector.get(i).getcustomerdetails();
		}

		if (customermodel == null) {
			customermodel = new DefaultTableModel(columnData, columnNames) {
				@Override
				public boolean isCellEditable(int row, int col1) {
					if (col1 < 12)
						return false;
					return true;
				}

				@Override
				public Class getColumnClass(int c) {
					try {
						return getValueAt(0, c).getClass();
					} catch (Exception exception) {
						return String.class;
					}
				}
			};
		} else {
			customermodel.setDataVector(columnData, columnNames);
		}
		if (customertable == null)
			customertable = new JTable(customermodel);

		customertable.updateUI();

		}
	
	@Override
	public void actionPerformed(ActionEvent e)
	{
	  if (e.getSource().equals(butsearch))
	  {
		  
		  searchload();
		  
	  }
	}
	@Override
	public void mouseClicked(MouseEvent e)
	{
	
		if(e.getSource().equals(customertable))
		{
			System.out.println("1");
			int selectedRow = customertable.getSelectedRow();

			if (selectedRow > -1) 
			{
				int tableId = 0;
				try 
				{
					if (selectedRow > -1) 
					{
						tableId = (int) Integer.parseInt((customertable.getValueAt(selectedRow, 0)).toString());
						custid = tableId;
						addTicketPanel.setCustomer(custid);
						this.hide();
						

					}
				}
				catch(Exception e1)
				{
					e1.printStackTrace();
				}
			}
			
		}
		
	}
	@Override
	public String toString() {
		return "findcustomerdialog [custid=" + custid + "]";
	}
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}
