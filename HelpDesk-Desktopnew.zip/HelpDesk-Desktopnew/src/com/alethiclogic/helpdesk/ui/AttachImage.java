package com.alethiclogic.helpdesk.ui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.plaf.DimensionUIResource;

import org.apache.http.HttpResponse;
import org.apache.http.HttpVersion;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.ContentBody;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.CoreProtocolPNames;

public class AttachImage extends JDialog implements ActionListener
{
	private JPanel mainpanel=new JPanel(new BorderLayout());
	private JPanel centerpanel=new JPanel(new BorderLayout(5,5));
	private JPanel southpanel=new JPanel(new BorderLayout());
	private JPanel southpanel1=new JPanel(new BorderLayout());
	private JTextField txtimage=new JTextField();
	private JButton butsave=new JButton("Save");
	private JButton butbrowse=new JButton("Browse");
	private JFileChooser dataBrowser = new JFileChooser();
	private String tid;
	private int stat;
	
	private JPanel holderPanel;
	
	public AttachImage(int stat,String tid, JPanel holderPanel)
	{
		this.stat=stat;
		this.tid=tid;
		this.holderPanel = holderPanel;
		
		centerpanel.add(txtimage,BorderLayout.CENTER);
		centerpanel.add(butbrowse,BorderLayout.EAST);
		southpanel1.add(butsave,BorderLayout.EAST);
		
		txtimage.setPreferredSize(new Dimension(150,25));
		butbrowse.setPreferredSize(new Dimension(150,25));
		butsave.setPreferredSize(new Dimension(150,25));
		mainpanel.setPreferredSize(new Dimension(250,250));
		centerpanel.setPreferredSize(new Dimension(150,25));
		southpanel.setPreferredSize(new Dimension(200,25));
		southpanel1.setPreferredSize(new Dimension(200,25));
		
		butbrowse.addActionListener(this);
		butsave.addActionListener(this);
		
		southpanel.add(southpanel1,BorderLayout.NORTH);
		mainpanel.add(centerpanel,BorderLayout.NORTH);
		mainpanel.add(southpanel,BorderLayout.CENTER);
		
		this.add(mainpanel);
		this.setSize(450,90);
		this.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) 
	{
	
		if(e.getSource().equals(butbrowse))
		{
			if (dataBrowser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION)
			{
				txtimage.setText(dataBrowser.getSelectedFile().getAbsolutePath());
			}
		}
		else if(e.getSource().equals(butsave))
		{
			try
			{
					File file = new File(txtimage.getText());
					HttpClient httpclient = new DefaultHttpClient();
				    httpclient.getParams().setParameter(CoreProtocolPNames.PROTOCOL_VERSION, HttpVersion.HTTP_1_1);

				    HttpPost httppost = new HttpPost(UIHelper.base + "query/javainsertimage.php");
				    					    
					MultipartEntity mpEntity = new MultipartEntity();
					ContentBody cbFile = new FileBody(file, "image/png");
					    
					mpEntity.addPart("txtfile", cbFile);
					mpEntity.addPart("txtid", new StringBody(tid));
					mpEntity.addPart("txtuser", new StringBody(UIHelper.getUser()));
					    
					httppost.setEntity(mpEntity);
					    
					HttpResponse response;
					String line = "";
					try 
					{
					response = httpclient.execute(httppost);
					BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
						while ((line = rd.readLine()) != null) 
						{
							System.out.println(line);	
						}
					} 
					catch (ClientProtocolException e1) 
					{
						e1.printStackTrace();
					} 
					catch (IOException e1) 
					{
						e1.printStackTrace();
					}
					catch (Exception e1) 
					{
						e1.printStackTrace();
					}
					this.hide();
					holderPanel.removeAll();
					holderPanel.add(new JScrollPane(UIHelper.getJobDetails(stat, tid, holderPanel)));
					holderPanel.updateUI();
					
			}
			catch (Exception ee) 
			{
				ee.printStackTrace();
			}

		}
		
	}
}
