package com.alethiclogic.helpdesk.ui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.BorderFactory;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;

public class rest  extends JPanel implements MouseListener

{
private JPanel main=new JPanel();
private JPanel south=new JPanel();
private JPanel center=new JPanel();
private JPanel north=new JPanel();
private JLabel label1=new JLabel("layout");
private JComboBox com=new JComboBox();
	public rest()
	{
	main.setPreferredSize(new Dimension(800,600));
	south.setPreferredSize(new Dimension(300,200));
	center.setPreferredSize(new Dimension(300,300));
	north.setPreferredSize(new Dimension(200,100));
	
	
	
	
	south.setBorder(BorderFactory.createRaisedBevelBorder());
	center.setBorder(BorderFactory.createRaisedBevelBorder());
	north.setBorder(BorderFactory.createRaisedBevelBorder());
	
	com.addItem("panel1");
	com.addItem("panel2");
	com.addItem("panel3");
	com.addItem("panel4");
	com.addItem("panel5");
	com.addItem("panel6");
	com.addItem("panel7");
	com.addItem("panel8");
	com.addItem("panel9");
	com.addItem("panel10");
	com.addItem("panel11");
		
	north.add(com);
	
	this.add(main);
	this.setSize(800,600);
	this.setVisible(true);
    	
	}

	public static void main(String[] args)
	{
	rest re=new rest();

	}

	@Override
	public void mouseClicked(MouseEvent e) 
	{
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}
