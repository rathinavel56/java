package com.alethiclogic.helpdesk.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;

import com.alethiclogic.helpdesk.entity.EngineerEntity;

public class CompletedPanel extends JPanel implements MouseListener, ActionListener
{
	
	private Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
	private int width = (int) dimension.getWidth();
	private int height = (int) dimension.getHeight();

	private JButton closedButton;
	
	private JPanel northpanel;
	private JPanel jobDetailHolderPanel;
	private JPanel summaryPanelHolder;
	
	private JobPanel selectedJob;
	
	private Vector<JobPanel> jobs;
	
	public CompletedPanel()
	{
		setLayout(new BorderLayout());
			
		northpanel =UIHelper.getBoxPanel(new BorderLayout(),new Color(52,152,219),Color.white);
		JPanel northpanel1 =UIHelper.getBoxPanel(new BorderLayout(),new Color(52,152,219),Color.white);
		JPanel northpanel1panela =UIHelper.getBoxPanel(null,new Color(52,152,219),Color.white);
		JPanel northpanel1panelb =UIHelper.getBoxPanel(null,new Color(52,152,219),Color.white);
		
		jobDetailHolderPanel =UIHelper.getBoxPanel(new BorderLayout(),null,null);
		summaryPanelHolder = UIHelper.getBoxPanel(new GridLayout(),new Color(52,152,219),Color.white);
		
		
		northpanel1panelb.setLayout(new BoxLayout(northpanel1panelb, BoxLayout.PAGE_AXIS));
	    Component box_1 = Box.createRigidArea(new Dimension(10, 40));
	    Box box_2 = Box.createHorizontalBox();
	    
	    closedButton = new JButton("Close");
	    closedButton.addActionListener(this);

	    box_2.add(Box.createRigidArea(new Dimension(20, 10)));
		JPanel pbox2 = UIHelper.getBoxPanel(new BorderLayout(5, 2),new Color(52,152,219),Color.white);
		pbox2.setMaximumSize(new Dimension(200, 30));
		pbox2.add(closedButton, BorderLayout.CENTER);
		box_2.add(pbox2);
		Font f21=new Font("sans",Font.BOLD,12);
		closedButton.setFont(f21);
		closedButton.setForeground(Color.white);
		closedButton.setForeground(new Color(52,152,219));
		box_2.add(Box.createRigidArea(new Dimension(10, 10)));

		northpanel1panelb.add(box_1);
		northpanel1panelb.add(box_2);
		
		//northpanel1panela.setPreferredSize(new Dimension(200,120));
		//northpanel1panelb.setPreferredSize(new Dimension(200,120));
		//northpanel1.add(northpanel1panela,BorderLayout.WEST);
		northpanel1.add(northpanel1panelb,BorderLayout.CENTER);
		
		jobDetailHolderPanel.setBorder(BorderFactory.createRaisedBevelBorder());
		northpanel.setBorder(BorderFactory.createRaisedBevelBorder());

		northpanel1.setPreferredSize(new Dimension(400,120));
		
		
		
		
		northpanel.add(northpanel1,BorderLayout.WEST);
		northpanel.add(summaryPanelHolder,BorderLayout.CENTER);
		northpanel.setOpaque(true);
		
		jobDetailHolderPanel.setPreferredSize(new Dimension(width - 250,height-120));
		northpanel.setPreferredSize(new Dimension(width,120));
		
	
		loadScreen();
		northpanel.setOpaque(true);
		
		summaryPanelHolder.add(UIHelper.getSummaryPanel());
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		Object object = e.getSource();
		
		if (object instanceof JobPanel)
		{
			selectedJob = (JobPanel)object;
			String jobNo = selectedJob.getJobId();
			
			jobDetailHolderPanel.removeAll();
			jobDetailHolderPanel.add(new JScrollPane(UIHelper.getJobDetails(UIHelper.STATUS_HOME, jobNo, jobDetailHolderPanel)), BorderLayout.CENTER);
			jobDetailHolderPanel.updateUI();
			
			for (JobPanel jobPanel : jobs)
			{
				jobPanel.select(jobPanel.equals(selectedJob));
			}
		}
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		Object object = e.getSource();
		
		if (object.equals(closedButton))
		{
			if (selectedJob == null)
			{
				JOptionPane.showMessageDialog(this, "Please select a job to proceed with closing");
				return;
			}
			
			UIHelper.closeJob(selectedJob.getJobId());
			
			loadScreen();
		}
	}
	
	public void loadScreen()
	{
		if (jobs == null)
		{
			jobs = new Vector<JobPanel>();	
		}
		else
		{
			jobs.clear();
		}
		
		removeAll();
		
		add(northpanel,BorderLayout.NORTH);
		add(jobDetailHolderPanel,BorderLayout.CENTER);
		add(UIHelper.getJobPanel(UIHelper.STATUS_COMPLETED, this),BorderLayout.WEST);
		
		updateUI();
	}
	
	public void addJob(JobPanel jobPanel)
	{
		jobs.add(jobPanel);
	}
}
