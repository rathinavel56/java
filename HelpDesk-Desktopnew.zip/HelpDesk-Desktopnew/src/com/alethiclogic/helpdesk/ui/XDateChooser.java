package com.alethiclogic.helpdesk.ui;

import java.awt.event.MouseListener;
import java.util.Date;

import com.toedter.calendar.JDateChooser;

public class XDateChooser extends JDateChooser
{
	public XDateChooser()
	{
		super();
		setEnabled(false);
	}
	
	public XDateChooser(Date date)
	{
		super(date);
		setEnabled(false);
	}
	
	@Override
	/**
	 * Enable or disable the JDateChooser.
	 * 
	 * @param enabled
	 *            the new enabled value
	 */
	public void setEnabled(boolean enabled) {
		super.setEnabled(enabled);
		if (dateEditor != null) {
			dateEditor.setEnabled(enabled);
			
			if (calendarButton != null)
			{
				calendarButton.setEnabled(true);
			}
		}
	}
	
	public void addMouseListener(MouseListener mouseListener)
	{
		calendarButton.addMouseListener(mouseListener);
	}
}
