package com.alethiclogic.helpdesk.ui;

public class AreaEntity 
{
	private String areaId;
	private String areaName;
	
	public AreaEntity(String areaId, String areaName) {
		super();
		this.areaId = areaId;
		this.areaName= areaName;
	}
	
	public String getArea()
	{
		return areaId;
	}
	
	public String toString()
	{
		return areaName;
	}

	@Override
	public boolean equals(Object obj) {
		
		AreaEntity other = (AreaEntity) obj;
		
		System.out.println(areaName + " " + other.areaName + " " + areaName.equals(other.areaName));
		
		if (areaName.equals(other.areaName))
				return true;
		
		return false;
	}
}
