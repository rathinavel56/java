package com.alethiclogic.helpdesk.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class NotePanel extends JPanel
{
	public NotePanel(String noteDetails)
	{
		setLayout(new BorderLayout());
		
		String[] noteArr = noteDetails.split("\\|");
		
		System.out.println(noteArr.length);
		
		if (noteArr.length >= 4)
		{
			JPanel northPanel = new JPanel(new GridLayout(1, 2));
			
			JLabel userLabel = new JLabel(noteArr[2]);
			JLabel timeLabel = new JLabel(noteArr[3]);
			
			
			JTextArea noteArea = new JTextArea(noteArr.length > 4 ? noteArr[4] : "");
			
			noteArea.setEditable(false);
			
			northPanel.add(userLabel);
			northPanel.add(timeLabel);
			
			add(northPanel, BorderLayout.NORTH);
			add(new JScrollPane(noteArea), BorderLayout.CENTER);
			
			setBackground(Color.white);
			
			setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
			setPreferredSize(new Dimension(250, 125));
		}
	}
}
