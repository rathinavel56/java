package com.alethiclogic.helpdesk.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URI;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

public class HelpDeskMain extends JFrame implements MouseListener {

	private Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
	private int width = (int) dimension.getWidth();
	private int height = (int) dimension.getHeight();

	private JPanel mainpanel = new JPanel(new BorderLayout());
	private JPanel northpanel=new JPanel(new BorderLayout());
	private JTabbedPane jTabbedPane = new JTabbedPane();
	private JLabel loutbutton=new JLabel("Logout");
	private JLabel exportButton=new JLabel("Export to Excel");
	
	private JPanel topPanel=new JPanel(new BorderLayout());
	private JPanel linkPanel=new JPanel(new BorderLayout());
	private JLabel msg=new JLabel("Welcome : ");
	private JLabel uname=new JLabel("Demo");
	
	private AddTicketPanel addpanel;
	private HomePanel homePanel;
	private Assignedpanel assignedpanel;
	private CompletedPanel completedPanel;
	private ClosedPanel closedPanel;
	private Miscpanel miscpanel;

	public HelpDeskMain()
	{
		addpanel =new AddTicketPanel();
		homePanel = new HomePanel();
		assignedpanel = new Assignedpanel();
		completedPanel = new CompletedPanel();
		closedPanel = new ClosedPanel();
		miscpanel =new Miscpanel();
		
		Font f1 = new Font("sans", Font.BOLD, 12);
		loutbutton.setFont(f1);
		exportButton.setFont(f1);
		loutbutton.setForeground(new Color(52,152,219));
		exportButton.setForeground(new Color(52,152,219));
		
		jTabbedPane.add(addpanel, "Add");
		jTabbedPane.add(homePanel, "Home");
		jTabbedPane.add(assignedpanel, "Assigned");
		jTabbedPane.add(completedPanel, "Completed");
		jTabbedPane.add(closedPanel, "Closed");
		jTabbedPane.add(miscpanel,"Misc");
		
		jTabbedPane.addChangeListener(new ChangeListener() {
			
			@Override
			public void stateChanged(ChangeEvent e) {
				switch(jTabbedPane.getSelectedIndex())
				{
				
					case 0:
						addpanel.setBackground(new Color(52,152,219));
						addpanel.loadScreen();
						break;
					case 1:
						homePanel.setBackground(new Color(52,152,219));
						homePanel.loadScreen();
						break;
					case 2:
						assignedpanel.setBackground(new Color(52,152,219));
						assignedpanel.loadScreen();
						break;
					case 3:
						completedPanel.setBackground(new Color(52,152,219));
						completedPanel.loadScreen();
						break;
					case 4:
						closedPanel.setBackground(new Color(52,152,219));
						closedPanel.loadScreen();
						break;
						
					default:
				}
			}
		});
		
		uname.setText(UIHelper.getUser());
		
		loutbutton.setPreferredSize(new Dimension(100,25));
		exportButton.setPreferredSize(new Dimension(100,25));
		
		linkPanel.add(exportButton,BorderLayout.CENTER);
		linkPanel.add(loutbutton,BorderLayout.EAST);
		
		
		
		msg.setForeground(Color.black);
		uname.setForeground(Color.black);
		topPanel.add(msg,BorderLayout.WEST);
		topPanel.add(uname,BorderLayout.CENTER);
		topPanel.add(linkPanel,BorderLayout.EAST);
		topPanel.setPreferredSize(new Dimension(425,30));
		topPanel.setOpaque(false);
		linkPanel.setOpaque(false);
		northpanel.setOpaque(false);
		
		loutbutton.addMouseListener(this);
		exportButton.addMouseListener(this);
		
		mainpanel.setBackground(Color.white);
		northpanel.add(topPanel,BorderLayout.EAST);
		northpanel.setPreferredSize(new Dimension(width,30));
		mainpanel.add(northpanel,BorderLayout.NORTH);
		mainpanel.add(jTabbedPane, BorderLayout.CENTER);

		this.add(mainpanel);
		this.setSize(width, height);
		this.setVisible(true);
		//addpanel.setOpaque(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}

	public static void main(String args[]) {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		new HelpDeskMain();
	}

	@Override
	public void mouseClicked(MouseEvent e) 
	{
		if(e.getSource().equals(loutbutton))
		{
			this.dispose();
			new LoginScreen();
		}
		else if(e.getSource().equals(exportButton))
		{
			try {
				String url = UIHelper.getBase().toString() + "exportExcel.php";
				HttpClient client = new DefaultHttpClient();
				HttpGet request = new HttpGet(url);
				HttpResponse response = client.execute(request);
				BufferedReader rd = new BufferedReader(new InputStreamReader(
						response.getEntity().getContent()));

				StringBuffer stringBuffer = new StringBuffer();
				String line = null;

				while ((line = rd.readLine()) != null) {
					stringBuffer.append(line);
					System.out.println(line);
				}
				String url1 = UIHelper.getBase().toString() + "reports/All_Ticket_report.xls";
				Desktop.getDesktop().browse(new URI(url1));
			} catch (Exception exception) {
				exception.printStackTrace();
			}
		}
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


}
