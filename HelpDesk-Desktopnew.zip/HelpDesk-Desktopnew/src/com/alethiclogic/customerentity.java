package com.alethiclogic;

public class customerentity
{
	
private String id;
private String fname;
private String lname;
private String houseflat;
private String town;
private String countrty;
private String street;
private String landline;
private String city;
private String mobile;
private String postcode;
private String deiails;

public String getFname() {
	return fname;
}


public void setFname(String fname) {
	this.fname = fname;
}


public String getLname() {
	return lname;
}


public void setLname(String lname) {
	this.lname = lname;
}


private boolean bool=false;



public String getId() {
	return id;
}


public void setId(String id) {
	this.id = id;
}


public String getHouseflat() {
	return houseflat;
}


public void setHouseflat(String houseflat) {
	this.houseflat = houseflat;
}


public String getTown() {
	return town;
}


public void setTown(String town) {
	this.town = town;
}


public String getCountrty() {
	return countrty;
}


public void setCountrty(String countrty) {
	this.countrty = countrty;
}


public String getStreet() {
	return street;
}


public void setStreet(String street) {
	this.street = street;
}


public String getLandline() {
	return landline;
}


public void setLandline(String landline) {
	this.landline = landline;
}


public String getCity() {
	return city;
}


public void setCity(String city) {
	this.city = city;
}


public String getMobile() {
	return mobile;
}


public void setMobile(String mobile) {
	this.mobile = mobile;
}


public String getPostcode() {
	return postcode;
}


public void setPostcode(String postcode) {
	this.postcode = postcode;
}


public String getDeiails() {
	return deiails;
}


public void setDeiails(String deiails) {
	this.deiails = deiails;
}
public boolean isBool() {
	return bool;
}


public void setBool(boolean bool) {
	this.bool = bool;
}


public Object[] getcustomerdetails()
{
	Object[] temp=new Object[12];
	
	temp[0]=id;
	temp[1]=fname+lname;
	temp[2]=deiails;
	temp[3]=houseflat;	
	temp[4]=street;	
	temp[5]=town;	
	temp[6]=city;	
	temp[7]=landline;
	temp[8]=mobile;	
	temp[9]=countrty;	
	temp[10]=postcode;	
	temp[11]=bool;
	
	return temp;
}

public String toString()
{
	return "fname"+"lname";
}

}

