package parser;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import com.csvreader.CsvWriter;

public class Csvwriter {
	public static void main(String[] args) {
		String outputFile = "E://users.csv";
		boolean alreadyExists = new File(outputFile).exists();
		
		try {
			CsvWriter csvOutput = new CsvWriter(new FileWriter(outputFile, true), ',');
			if (!alreadyExists){
				csvOutput.write("id");
				csvOutput.write("name");
				csvOutput.endRecord();
			}
			csvOutput.write("1");
			csvOutput.write("Bruce");
			csvOutput.endRecord();
			
			csvOutput.write("2");
			csvOutput.write("John");
			csvOutput.endRecord();
			
			csvOutput.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
