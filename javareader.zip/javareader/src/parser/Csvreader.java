package parser;

import java.io.FileNotFoundException;
import java.io.IOException;

import com.csvreader.CsvReader;

public class Csvreader {
	public static void main(String[] args) {
		try {
			CsvReader products = new CsvReader("E://product.csv");
			products.readHeaders();
			while (products.readRecord()){
				String productID = products.get(0);
				String productName  = products.get(1);
				String supplierID  = products.get(2);
				System.out.println(productID + ":" + productName + ":" + supplierID);
			}
			products.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
			
	}

}
